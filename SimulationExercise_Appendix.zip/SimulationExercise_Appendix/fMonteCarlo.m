% ----------------------------------------------------------------------- %
%             Function that simulates the results in the appendix 
% ----------------------------------------------------------------------- %
function [Out_Bias, Out_Rmse] = fMonteCarlo(cT, iRept, iNrFactors, iNrReturns, ...
    betatargeting, iGarch, strGACB, strDCC, strAR, strBEKK)

    mMatrixRMSE = zeros(iRept, 2);
    mMatrixBias = zeros(iRept, 2);
    for j = 1:iRept
        % --------------------------------------------------- %
        %           Step 1 Simulate the BEKK
        % --------------------------------------------------- %
        [mReturns_Sim, mFactors_Sim, mBeta_True, mBeta_start, mH_FS_start, mH_SS_start, mu_start] ...
            = fSimulate(iGarch, cT, iNrReturns, iNrFactors, strGACB, strDCC, strAR, strBEKK);
        % --------------------------------------------------- %
        %              Estimation step  
        % --------------------------------------------------- %
        % ----------------------- GACB ---------------------- %
        startparam = [];
        [~, ~, ~, ~, mBeta_t_GACB] = fEstimateMC_2...
                    (mReturns_Sim(1:cT,:), mFactors_Sim(1:cT,:), startparam, betatargeting, mBeta_start, mH_FS_start, mH_SS_start, mu_start);
        plot(squeeze((mBeta_t_GACB(1,:,1:end))))
        % ----------------------- GACB NS ------------------- %
        [~, ~, ~, ~, mBeta_t_GACB_NN] = fEstimateMC_NN...
                    (mReturns_Sim(1:cT,:), mFactors_Sim(1:cT,:), startparam, betatargeting, mBeta_start, mH_FS_start, mH_SS_start, mu_start);
        % -------------- DCC ------------------ %
        mUncCorr = corr([mFactors_Sim(1:cT,:) mReturns_Sim(1:cT,:)]);
        FOR_StartVal.H_0 = [];
        FOR_StartVal.Q_0 = [];
        FOR_StartVal.MUf_0 = [];
        FOR_StartVal.MUr_0 = [];   
        [mBeta_t_DCC, ~, ~, ~, ~, ~, ~, ~, ~, ~, ~, ~, ~] ...
             = fEstimateDCC(mReturns_Sim(1:cT,:), mFactors_Sim(1:cT,:), 1, 0, [], 1, mUncCorr, FOR_StartVal);
        % -------------- Calculate the statistics -------------------- %
        mBiasDCC = zeros(iNrReturns, iNrFactors);
        mBiasGACB = zeros(iNrReturns, iNrFactors);
        mBiasGACB_NN = zeros(iNrReturns, iNrFactors);
        mRmseDCC = zeros(iNrReturns, iNrFactors);
        mRmseGACB = zeros(iNrReturns, iNrFactors);
        mRmseGACB_NN = zeros(iNrReturns, iNrFactors);
        for gg = 1:cT
           mBiasDCC = mBiasDCC + 1/cT * (mBeta_True(:, :, gg) -  mBeta_t_DCC(:, :, gg));
           mBiasGACB = mBiasGACB + 1/cT * (mBeta_True(:, :, gg) -  mBeta_t_GACB(:, :, gg));
           mBiasGACB_NN = mBiasGACB_NN + 1/cT * (mBeta_True(:, :, gg) -  mBeta_t_GACB_NN(:, :, gg));
           mRmseDCC = mRmseDCC + 1/cT * (mBeta_True(:, :, gg) -  mBeta_t_DCC(:, :, gg)).^2;
           mRmseGACB = mRmseGACB + 1/cT * (mBeta_True(:, :, gg) -  mBeta_t_GACB(:, :, gg)).^2;
           mRmseGACB_NN = mRmseGACB_NN + 1/cT * (mBeta_True(:, :, gg) -  mBeta_t_GACB_NN(:, :, gg)).^2;
        end
        mMatrixBias(j, 1) = mBiasDCC;
        mMatrixBias(j, 2) = mBiasGACB;
        mMatrixBias(j, 3) = mBiasGACB_NN;
        mMatrixRMSE(j, 1) = sqrt(mRmseDCC);
        mMatrixRMSE(j, 2) = sqrt(mRmseGACB);
        mMatrixRMSE(j, 3) = sqrt(mRmseGACB_NN);
    end
    Out_Bias = mean(mMatrixBias, 1);
    Out_Rmse = mean(mMatrixRMSE, 1);
end