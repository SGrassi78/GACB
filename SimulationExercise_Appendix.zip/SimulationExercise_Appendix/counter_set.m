function counter_set(var,timer)
% lenghtnum = length(num2str(var));
% fprintf(['Progress:\n0%%' repmat('.',1,round(100/round(var/10^(lenghtnum-2)))*floor(var/10^(lenghtnum-2))) ' 100%%\n' repmat(' ',1,7) '\b']);

fprintf(['Progress:\n0%%' repmat(' ',1,22) '25%%' repmat(' ',1,22) '50%%' repmat(' ',1,22) '75%%' repmat(' ',1,24) '100%%\n']);
fprintf(['|' repmat('.',1,24) '|' repmat('.',1,24) '|' repmat('.',1,24) '|' repmat('.',1,25) '| \n' repmat(' ',1,2) '\b']);%fprintf(repmat('\b',1,10));



if timer==1
      tic
end