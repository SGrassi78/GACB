function elapsed_time = counter_close(timer)
if timer==1
      elapsed_time = toc;
      if elapsed_time<=60
            fprintf ( 1, '  This operation took %d seconds to run.\n', floor(elapsed_time) );
      elseif elapsed_time>60 && elapsed_time<=360
            fprintf ( 1, '  This operation took %d minutes and %d seconds to run.\n', floor(elapsed_time/60), elapsed_time-floor(elapsed_time/60)*60 );
      else
            fprintf ( 1, '  This operation took %d hours, %d minutes and %d seconds to run.\n', floor(elapsed_time/3600), floor((elapsed_time-floor(elapsed_time/3600)*3600)/60), elapsed_time-floor(elapsed_time/60)*60);
      end
end
