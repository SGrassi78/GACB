function counter_progress(var,idx)

% lenghtnum = length(num2str(var));
% if (idx/10^(lenghtnum-2))==round(idx/10^(lenghtnum-2))
%       fprintf(['\b' repmat('|',1,round(100/round(var/10^(lenghtnum-2)))) '\n']);
% end


int = [25; 50; 75];
percent = [1:100];
offset = [0; 2; 2];
if sum(find(floor((var/100)*percent)==idx,1)==int)~=0
%        fprintf(['\b' repmat('*',1,1) '\n']);
    fprintf(['\b' repmat('\b',1,offset(find(floor((var/100)*percent)==idx,1)==int)) num2str(int(find(floor((var/100)*percent)==idx,1)==int)) repmat('%%',1,1) '\n']);        
elseif ~isempty(find(floor((var/100)*percent)==idx,1)) 
    fprintf(['\b' repmat('|',1,1) '\n']);
end