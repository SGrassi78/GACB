% ----------------------------------------------------------------------- %
%                Function that estimated the beta MGARCH 
% ----------------------------------------------------------------------- %
function [param, mBeta_Unc, H0, exitflag] ...
       = fEstimate_simultargeting(mReturns, mFactors, vPar0, betatargeting, covtargeting, acf)
        
       % vPar0 -> betaols, cov2step, garch, omg, gma
       % ---------------------------------------------------------------- %
       %                     House keeping 
       % ---------------------------------------------------------------- %
       % -------- Center mFactors --------- %
       mFactors = mFactors - mean(mFactors);
       mReturns = mReturns - mean(mReturns);
       
       nF = size(mFactors, 2);
       nR = size(mReturns, 2);
       % ---------------------------------------------------------------- %
       %                  Maximum likelihood set up
       % ---------------------------------------------------------------- %
       options = optimset('Algorithm','interior-point', 'Display','off', ...
              'MaxFunEvals', 100000,'MaxIter', 100000, 'TolFun', 1e-6, 'TolX', 1e-6,...
                     'LargeScale', 'on', 'UseParallel', true);          
       % ---------------------------------------------------------------- %
       %                      Equartion 5
       % ---------------------------------------------------------------- %
       % ------------------- Bounds ---------------------------------- %
       LB_Mgarch = [0.001; 0.5];
       UB_Mgarch = [0.3; 0.99999];

       LB_BetaUnc = 0 *ones(nR * nF, 1);
       UB_BetaUnc = 1 *ones(nR * nF, 1);
       
       LB_Omega = -0.01 * ones(nF * nR, 1);
       UB_Omega = 0.3 * ones(nF * nR, 1);
      
       LB_Gamma = 0 * ones(nF * nR, 1);
       UB_Gamma = 0.99999 * ones(nF * nR, 1);
          
       % ------------------- Set start param and estimation method ------------------ %
       if betatargeting==1 && covtargeting==0
           startingVals_f = vPar0(nF*nR+1:end);
           LB_Sigma_r_fUnc = startingVals_f(1:nR*(nR+1)/2)/10;
           UB_Sigma_r_fUnc = startingVals_f(1:nR*(nR+1)/2)*2;
           LB_f = [LB_Sigma_r_fUnc; LB_Mgarch; LB_Omega; LB_Gamma];
           UB_f = [UB_Sigma_r_fUnc; UB_Mgarch; UB_Omega; UB_Gamma];
       elseif betatargeting==0 && covtargeting==1
           startingVals_f = [vPar0(1:nF*nR); vPar0(nF*nR+nR*(nR+1)/2+1:end)];
           LB_f = [LB_BetaUnc; LB_Mgarch; LB_Omega; LB_Gamma];
           UB_f = [UB_BetaUnc; UB_Mgarch; UB_Omega; UB_Gamma];
       elseif betatargeting==1 && covtargeting==1
           startingVals_f = [vPar0(nF*nR+nR*(nR+1)/2+1:end)];
           LB_f = [LB_Mgarch; LB_Omega; LB_Gamma];
           UB_f = [UB_Mgarch; UB_Omega; UB_Gamma];
       else
           startingVals_f = vPar0;
           LB_Sigma_r_fUnc = startingVals_f(nF*nR+1:nF*nR+nR*(nR+1)/2)/10;
           UB_Sigma_r_fUnc = startingVals_f(nF*nR+1:nF*nR+nR*(nR+1)/2)*2;
           LB_f = [LB_BetaUnc; LB_Sigma_r_fUnc; LB_Mgarch; LB_Omega; LB_Gamma];
           UB_f = [UB_BetaUnc; UB_Sigma_r_fUnc; UB_Mgarch; UB_Omega; UB_Gamma];
       end
        
       % compute beta targets (boths) to feed in the likelihood
       mBeta_OLS = [];
       if betatargeting==1
           mBeta_OLS = (mFactors\mReturns)';
       end
       
       % compute the autocorrelation of the squared first block
       R = [];
       if covtargeting == 1
            V = zeros(size(mFactors,1),nF^2);
            idx = 1;
            for i = 1:nF
               for j = 1:nF
                  V(:,idx) = mFactors(:,i).*mFactors(:,j);
                  idx = idx+1;
               end
            end
            R = zeros(1,nF^2);
            for i = 1:acf
               R(i,:) = mean(V(acf+1:end,:).*V(acf+1-i:end-i,:),1);
            end
       end
              
       % compute sample estimators of var_eps1 and  var_eps2
       Sig_F = cov(mFactors);
       Sig_R = cov(mReturns);

       % two step estimation (second step only)
       warning off
       [param, ~, exitflag, ~, ~, ~, ~] = fmincon(@beta_garch_likelihood, startingVals_f, [], [],...
               [], [], LB_f, UB_f, [], options, mReturns, mFactors, mBeta_OLS, R, Sig_F, Sig_R, betatargeting, covtargeting, acf);
       
       [~, ~, mBeta_Unc, H0] = beta_garch_likelihood(param, ...
               mReturns, mFactors, mBeta_OLS, R, Sig_F, Sig_R, betatargeting, covtargeting, acf);  
           
       if betatargeting == 1 && covtargeting == 0
           LT = zeros(nR);
           LT((tril(ones(nR)))~=0) = param(1:nR*(nR+1)/2, 1);
           H0 = reshape(tril(LT*LT'),nR^2,1);
           H0(H0==0) = [];
           
           param = [mBeta_OLS(:)' H0' param(nR*(nR+1)/2+1:end)'];
       elseif betatargeting == 0 && covtargeting == 1
           H0 = reshape(tril(H0),nR^2,1);
           H0(H0==0) = [];
           
           param = [param(1:nF*nR)' H0' param(nF*nR+1:end)'];
       elseif betatargeting == 1 && covtargeting == 1
           H0 = reshape(tril(H0),nR^2,1);
           H0(H0==0) = [];
           
           param = [mBeta_OLS(:)' H0' param'];
       else
           LT = zeros(nR);
           LT((tril(ones(nR)))~=0) = param(nF*nR+1:nF*nR+nR*(nR+1)/2, 1);
           H0 = reshape(tril(LT*LT'),nR^2,1);
           H0(H0==0) = [];
           
           param = [param(1:nF*nR)' H0' param(nF*nR+nR*(nR+1)/2+1:end)'];
       end      
end
% ----------------------------------------------------------------------- %
%             Estimation of the conditional beta
% ----------------------------------------------------------------------- %
function [ll, lls, mBeta_Unc, H0] = beta_garch_likelihood(vPar, ...
       mReturns, mFactors, mBeta_Unc, R, Sig_F, Sig_R, betatargeting, covtargeting, acf)
       [cT, nR] = size(mReturns);     
       nF = size(mFactors, 2);
       iIndx__= 0;
       if betatargeting == 1 && covtargeting == 0
              iIndx__= nR*(nR+1)/2;
              LT = zeros(nR);
              LT((tril(ones(nR)))~=0) = vPar(1:iIndx__, 1);
              H0 = LT*LT';
              
              A = vPar(iIndx__ + 1);
              B = vPar(iIndx__ + 2);    
              mOmega = reshape(vPar(iIndx__ + 3:iIndx__ + 3 + nR * nF - 1), nR, nF);
              mGamma = reshape(vPar(iIndx__ + 3 + nR * nF:iIndx__ + 3 + 2 * (nR * nF) - 1), nR, nF);
       elseif betatargeting == 0 && covtargeting == 0
              iIndx__= nR*nF;
              mBeta_Unc = reshape(vPar(1:iIndx__, 1), nR, nF);
              LT = zeros(nR);
              LT((tril(ones(nR)))~=0) = vPar(iIndx__+1:iIndx__+nR*(nR+1)/2, 1);
              H0 = LT*LT';
              
              iIndx__ = iIndx__+nR*(nR+1)/2;
              A = vPar(iIndx__ + 1);
              B = vPar(iIndx__ + 2);    
              mOmega = reshape(vPar(iIndx__ + 3:iIndx__ + 3 + nR * nF - 1), nR, nF);
              mGamma = reshape(vPar(iIndx__ + 3 + nR * nF:iIndx__ + 3 + 2 * (nR * nF) - 1), nR, nF);            
       elseif betatargeting == 1 && covtargeting == 1
              A = vPar(iIndx__ + 1);
              B = vPar(iIndx__ + 2);    
              mOmega = reshape(vPar(iIndx__ + 3:iIndx__ + 3 + nR * nF - 1), nR, nF);
              mGamma = reshape(vPar(iIndx__ + 3 + nR * nF:iIndx__ + 3 + 2 * (nR * nF) - 1), nR, nF);
              
              A_cal_s = zeros(acf,nR^2);
              for i=1:acf
                  mR = reshape(R(i,:),nF,nF);
                  A_s = mOmega.*(mGamma.^(i-1));
                  A_cal_s_tmp = zeros(nR,nR);
                  for s=1:nR
                     for j=1:nR
                         A_cal_s_tmp(s,j) = A_s(s,:)*mR*A_s(j,:)';
                     end
                  end
                  A_cal_s(i,:) = reshape(A_cal_s_tmp,1,nR^2);
              end
              A_cal = ones(nR,nR)+reshape(sum(A_cal_s),nR,nR);
              
              H0 =  (Sig_R - mBeta_Unc*Sig_F*mBeta_Unc')./A_cal; 
   
       elseif betatargeting == 0 && covtargeting == 1
              iIndx__ = nF * nR;
              mBeta_Unc = reshape(vPar(1:iIndx__, 1), nR, nF);
              A = vPar(iIndx__ + 1);
              B = vPar(iIndx__ + 2);    
              mOmega = reshape(vPar(iIndx__ + 3:iIndx__ + 3 + nR * nF - 1), nR, nF);
              mGamma = reshape(vPar(iIndx__ + 3 + nR * nF:iIndx__ + 3 + 2 * (nR * nF) - 1), nR, nF);
              
              A_cal_s = zeros(acf,nR^2);
              for i=1:acf
                  mR = reshape(R(i,:),nF,nF);
                  A_s = mOmega.*(mGamma.^(i-1));
                  A_cal_s_tmp = zeros(nR,nR);
                  for s=1:nR
                     for j=1:nR
                         A_cal_s_tmp(s,j) = A_s(s,:)*mR*A_s(j,:)';
                     end
                  end
                  A_cal_s(i,:) = reshape(A_cal_s_tmp,1,nR^2);
              end
              A_cal = ones(nR,nR)+reshape(sum(A_cal_s),nR,nR);
              
              H0 =  (Sig_R - mBeta_Unc*Sig_F*mBeta_Unc')./A_cal; 
       end
        
       mPsi = mBeta_Unc .*(ones(nR, nF) - mGamma);     
       eps = zeros(1, nR);
       lls = zeros(cT, 1);
       mu = median(mReturns(1:20, :));
       mH = H0;
       mBeta_t = mBeta_Unc;      
       % ---------------------------------------------------------------- %
       %                   Estimation of the beta TV                      %
       % ---------------------------------------------------------------- %
       for i = 2:cT  
           Xi_r = eps';
           Xi_f = mFactors(i - 1, :);
           
           mBeta_t = mPsi + (mOmega .* (Xi_r * Xi_f)) + (mGamma .* mBeta_t);
           
           mH = H0 * (1 - A - B) + A * (eps' * eps) ...
                  + B * mH; 
           
           eps = mReturns(i, :) - ((mBeta_t * mFactors(i, :)'))';
           
           eta2 = eps * (mH\eps');  
           lls(i) = -0.5 * (nR * log(2 * pi) + log(det(mH)) + eta2);      
       end
       ll = -mean(lls(100:end));
       if (isnan(ll) || ~isreal(ll) || isinf(ll))
           ll = 1e7;
       end
end