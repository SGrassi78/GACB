% ----------------------------------------------------------------------- %
% This reproduces the results
% S3: Full QML estimator vs. multistep methods, with Bt updated via de-
% volatilized innovations and beta targeting.
% ----------------------------------------------------------------------- %
clear; clc;
iRept = 5000;
vcT = [850; 1600; 3100]; 
% ----------------------------------------------------------------------- %
%                Simulate the corresponding model 
% ----------------------------------------------------------------------- %
iNrFactors = 3;
iNrReturns = 10;
method = [1; 4; 5];
betatargeting = 1;
% ---------------------------------------------------------------- %
%           Call the simulation function of the model 
% ---------------------------------------------------------------- %
C = clock;
disp([num2str(C(2)) '/' num2str(C(3)) ' - ' num2str(C(4)) ':' num2str(C(5))])

warning off
% ----------------------------------------------------------------------- %
%           Split the simulations in iRep/50 files
% ----------------------------------------------------------------------- %
for ind = 1:(iRept/50)
    fSimulate_2(vcT, method, iRept/50, iNrFactors, iNrReturns, betatargeting, ind);
end
% ----------------------------------------------------------------------- %
%           Produce the tables. 
% ----------------------------------------------------------------------- %
clear all
load Simulation__NrRep_100_BTarget_1_ALLMLEMethods_1.mat
aParSim_tmp = aParSim;
for k=2:100
    load(strcat('Simulation__NrRep_100_BTarget_1_ALLMLEMethods_',num2str(k)))
    for j=1:3
        for i=1:3
            aParSim_tmp{i,j} = [aParSim_tmp{i,j}; aParSim{i,j}(2:end,:)];
        end
    end
end

aParSim = aParSim_tmp;
iRept = length(aParSim{1,1})-1;
bias = [];
rmse = [];
bias_tmp = [];
rmse_tmp = [];
for i=1:3
    for j=1:2
        par = aParSim{i,j};
        vSigma_f = par(:,1:6);
        garchFS = par(:,7:8);
        mBeta_UncOLS = par(:,9:38);
        vSigma_r_f = par(:,39:93);      
        garchSS = par(:,94:95);
        omg = par(:,96:125);
        gma = par(:,126:end);
        
        for k = 2:iRept+1
            LT = zeros(iNrReturns);
            LT((tril(ones(iNrReturns)))~=0) = vSigma_r_f(k,:);
            H0 = LT*LT';
            H0 = reshape(tril(H0)',iNrReturns^2,1);
            idx = reshape(tril(ones(iNrReturns))',iNrReturns^2,1);
            vSigma_r_f(k,:) = H0(logical(idx));
        end
        
        idx_v = vSigma_r_f(1,:)==1;
        idx_c = vSigma_r_f(1,:)==0.5;
        
        bias_tmp(:,j) = [mean(mean(mBeta_UncOLS(2:end,:)-mBeta_UncOLS(1,:))); mean(mean(omg(2:end,:)-omg(1,:))); mean(mean(gma(2:end,:)-gma(1,:)));...
            mean(mean(vSigma_r_f(2:end,idx_v)-vSigma_r_f(1,idx_v))); mean(mean(vSigma_r_f(2:end,idx_c)-vSigma_r_f(1,idx_c)));...
            mean(garchSS(2:end,:)-garchSS(1,:))'];
        
        gma_rmse = 0;
        omg_rmse = 0;
        for k=1:iNrReturns*iNrFactors
            if i==1
                trunc = 0.701;
            elseif i==2
                trunc = 0.701;
            else
                trunc = 0.701;
            end
            gma_rmse =  gma_rmse + (1/(iNrReturns*iNrFactors))*sqrt(mean((gma(gma(:,k)>trunc,k)-gma(1,k)).^2));
            omg_rmse =  omg_rmse + (1/(iNrReturns*iNrFactors))*sqrt(mean((omg(gma(:,k)>trunc,k)-omg(1,k)).^2));
        end
        gma_rmse 
        rmse_tmp(:,j) = [mean(sqrt(mean((mBeta_UncOLS(2:end,:)-mBeta_UncOLS(1,:)).^2))); mean(sqrt(mean((omg(2:end,:)-omg(1,:)).^2))); mean(sqrt(mean((gma(2:end,:)-gma(1,:)).^2)));...
            mean(sqrt(mean((vSigma_r_f(2:end,idx_v)-vSigma_r_f(1,idx_v)).^2))); mean(sqrt(mean((vSigma_r_f(2:end,idx_c)-vSigma_r_f(1,idx_c)).^2)));...
            sqrt(mean((garchSS(2:end,:)-garchSS(1,:)).^2))';omg_rmse;gma_rmse];
    end
%method 5
par = aParSim{i,3};
vSigma_f = par(:,1:6);
garchFS = par(:,7:12);

mBeta_UncOLS = par(1,[13:15 25:27 37:39 49:51 61:63 73:75 85:87 97:99 109:111 121:123]);
mBeta_UncOLS = [mBeta_UncOLS; par(2:end,13:42)];
vSigma_r_f = par(1,[16 28 40 52 64 76 88 100 112 124]);
vSigma_r_f = [vSigma_r_f; par(2:end,[43 52 61 70 79 88 97 106 115 124]).^2];
garchSS = par(1,[17 18 29 30 41 42 53 54 65 66 77 78 89 90 101 102 113 114 125 126]);
garchSS = [garchSS; par(2:end,[44 45 53 54 62 63 71 72 80 81 89 90 98 99 107 108 116 117 125 126])];
omg = par(1,[19:21 31:33 43:45 55:57 67:69 79:81 91:93 103:105 115:117 127:129]);
omg = [omg; par(2:end,[46:48 55:57 64:66 73:75 82:84 91:93 100:102 109:111 118:120 127:129])];
gma = par(1,[22:24 34:36 46:48 58:60 70:72 82:84 94:96 106:108 118:120 130:132]);
gma = [gma; par(2:end,[49:51 58:60 67:69 76:78 85:87 94:96 103:105 112:114 121:123 130:132])];


bias_tmp(:,3) = [mean(mean(mBeta_UncOLS(2:end,:)-mBeta_UncOLS(1,:))); mean(mean(omg(2:end,:)-omg(1,:))); mean(mean(gma(2:end,:)-gma(1,:)));...
    mean(mean(vSigma_r_f(2:end,:)-vSigma_r_f(1,:))); 0;...
    mean(mean(garchSS(2:end,[1:2:end])-garchSS(1,[1:2:end])))'; mean(mean(garchSS(2:end,[2:2:end])-garchSS(1,[2:2:end])))'];

gma_rmse = 0;
omg_rmse = 0;
for k=1:iNrReturns*iNrFactors
    if i==1
        trunc = 0.701;
    elseif i==2
        trunc = 0.701;
    else
        trunc = 0.701;
    end
    gma_rmse =  gma_rmse + (1/(iNrReturns*iNrFactors))*sqrt(mean((gma(gma(:,k)>trunc,k)-gma(1,k)).^2));
    omg_rmse =  omg_rmse + (1/(iNrReturns*iNrFactors))*sqrt(mean((omg(gma(:,k)>trunc,k)-omg(1,k)).^2));
end

gma_rmse

rmse_tmp(:,3) = [mean(sqrt(mean((mBeta_UncOLS(2:end,:)-mBeta_UncOLS(1,:)).^2))); mean(sqrt(mean((omg(2:end,:)-omg(1,:)).^2))); mean(sqrt(mean((gma(2:end,:)-gma(1,:)).^2)));...
    mean(sqrt(mean((vSigma_r_f(2:end,:)-vSigma_r_f(1,:)).^2))); 0;...
    mean(sqrt(mean((garchSS(2:end,[1:2:end])-garchSS(1,[1:2:end])).^2)))'; mean(sqrt(mean((garchSS(2:end,[2:2:end])-garchSS(1,[2:2:end])).^2)))';omg_rmse; gma_rmse];

bias = [bias bias_tmp];
rmse = [rmse rmse_tmp];

end








