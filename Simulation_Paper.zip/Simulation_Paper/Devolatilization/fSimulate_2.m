% ----------------------------------------------------------------------- %
%             Function that simulates the Beta GARCH models
% ----------------------------------------------------------------------- %
function fSimulate_2(vcT, method, iRept, iNrFactors, iNrReturns, betatargeting, ind)

mSigma_f = repmat(0.1,iNrFactors,iNrFactors)+diag(repmat(0.9,iNrFactors,1));
mSigma_r_f = repmat(0.5,iNrReturns,iNrReturns)+diag(repmat(0.5,iNrReturns,1));
mBeta_UncOLS = repmat(0.5,iNrReturns,iNrFactors);
%mSigma_rf = [eye(3) zeros(3,2);mBeta_UncOLS eye(2)]*[mSigma_f zeros(3,2); zeros(2,3) mSigma_r_f]*[eye(3) zeros(3,2);mBeta_UncOLS eye(2)]';

omg = repmat(0.04,iNrReturns,iNrFactors);
gma = repmat(0.93,iNrReturns,iNrFactors);


vSigma_r_f = reshape(chol(mSigma_r_f)',iNrReturns^2,1);
vSigma_r_f = vSigma_r_f(vSigma_r_f~=0);

vPar_EstFS = [0.04; 0.93];
vPar_EstSS = [mBeta_UncOLS(:); vSigma_r_f; vPar_EstFS; omg(:); gma(:)];

vPar0 = [vPar_EstFS; vPar_EstSS];

% -------------------------------------------------------- %
%            Put the parameters and start the sim
% -------------------------------------------------------- %
% ------------ Set the parameters ---------------- %

% -- MGarch parameters 1step-- %
mV0 = mSigma_f(1:iNrFactors, 1:iNrFactors);
A_1 = vPar_EstFS(1);
B_1 = vPar_EstFS(2);

iIdx__ = iNrFactors * iNrReturns + iNrReturns*(iNrReturns+1)/2;

% -- MGarch parameters 2step-- %
C0 = mSigma_r_f(1:iNrReturns, 1:iNrReturns);
A_2 = vPar_EstSS(iIdx__ + 1);
B_2 = vPar_EstSS(iIdx__ + 2);

% -------- Beta parameters ------- %
mBeta_Unc = reshape(vPar_EstSS(1:iNrFactors * iNrReturns, 1), iNrReturns, iNrFactors);
mOmega = reshape(vPar_EstSS(iIdx__ + 3:iIdx__ + 3 + iNrReturns * iNrFactors - 1), iNrReturns, iNrFactors);
mGamma = reshape(vPar_EstSS(iIdx__ + 3 + iNrReturns * iNrFactors:iIdx__+ 3 + (iNrReturns * 2 * iNrFactors) - 1), iNrReturns, iNrFactors);
mPsi = mBeta_Unc .*(ones(iNrReturns, iNrFactors) - mGamma);


dDrop = 100;

% ------------------------------------------------------- %
%                Start the Monte Carlo loop
% ------------------------------------------------------- %
vSigma_f = reshape(tril(mSigma_f), iNrFactors^2,1);
vSigma_f(vSigma_f==0) = [];
vSigma_r_f=reshape(tril(mSigma_r_f)',iNrReturns^2,1);
vSigma_r_f=vSigma_r_f(vSigma_r_f~=0);

mParSim = [];
mMatrixBetaOLS = [];
size_par = zeros(1,size(method,1));
for s = 1:size(vcT, 1)
    for m = 1: size(method,1)
        if method(m)==1 || method(m)==2 || method(m)==3 || method(m)==4
            Par0 = [vSigma_f; vPar_EstFS; mBeta_UncOLS(:); vSigma_r_f(:); vPar_EstFS; omg(:); gma(:)]';
            size_par(m) = size(Par0,2);
            mParSim = [mParSim, [Par0; zeros(iRept, iNrFactors*(iNrFactors+1)/2 + size(vPar_EstFS, 1) +  size(vPar_EstSS, 1))]];
        elseif method(m)==5 %NOTE the order of the parameters is different for betatargeting = 1 and 0
            Par0 = [vSigma_f; repmat(vPar_EstFS,iNrFactors,1)]';
            for i=1:iNrReturns
                Par0 = [Par0, [mBeta_UncOLS(i,:)'; mSigma_r_f(i,i); vPar_EstFS; omg(i,:)'; gma(i,:)']'];
            end
            size_par(m) = size(Par0,2);
            mParSim = [mParSim, [Par0; zeros(iRept, iNrFactors*(iNrFactors+1)/2 + iNrFactors*size(vPar_EstFS, 1) +  3*iNrReturns + 3*iNrFactors * iNrReturns)]];
        end
        mMatrixBetaOLS = [mMatrixBetaOLS, [mBeta_UncOLS(:)';zeros(iRept, iNrReturns * iNrFactors)]];
    end
end

C = clock;
fprintf([num2str(C(2)) '/' num2str(C(3)) ' - ' num2str(C(4)) ':' num2str(C(5)), '\n'])
%fprintf(['Method = ', num2str(method), '\nT = ', num2str(vcT(s)), '\n'])

counter_set(iRept,1);
parfor j = 1:iRept
    counter_progress(iRept,j);
    % --------------------------------------------------- %
    %           Step 1 Simulate the BEKK
    % --------------------------------------------------- %
    cT = max(vcT);
    vOrtInn = zeros(cT + dDrop, iNrFactors);
    mEpsSim = zeros(cT + dDrop, iNrFactors);
    mFactors_Sim = zeros(cT + dDrop, iNrFactors);
    mH_FS = zeros(iNrFactors, iNrFactors, cT + dDrop);
    mH_FS(:, :, 1) = mV0;
    for tt = 2:cT + dDrop
        mH_FS(:, :, tt) = mV0 * (1 - A_1 - B_1) + A_1 * (mEpsSim(tt - 1, :)'...
            * mEpsSim(tt - 1, :)) + B_1 * mH_FS(:, :, tt - 1);
        [ve, va] = eig(mH_FS(:, :, tt));
        mEpsSim(tt, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrFactors, 1))';
        mFactors_Sim(tt, :) = mEpsSim(tt, :);
        vOrtInn(tt, :) = mEpsSim(tt, :)./sqrt(diag(mH_FS(:, :, tt))');
    end
    % --------------------------------------------------- %
    %           Step 2 Simulate the Betas and Returns
    % --------------------------------------------------- %
    mReturns_Sim = zeros(cT + dDrop, iNrReturns);
    mBeta_t = zeros(iNrReturns, iNrFactors, cT + dDrop);
    mH_SS = zeros(iNrReturns, iNrReturns, cT + dDrop);
    mu = zeros(cT + dDrop, iNrReturns);
    mH_SS(:, :, 1) = C0;
    mBeta_t(:, :, 1) = mBeta_Unc;
    mu(1, :) = ((mBeta_t(:, :, 1) * mFactors_Sim(1, :)'))';
    mEpsSim_SS =  zeros(cT + dDrop, iNrReturns);
    for t = 2:cT + dDrop
        mBeta_t(:, :, t) = mPsi + (mOmega .* ((mEpsSim_SS(t - 1,:)'./sqrt(diag(mH_SS(:, :, t-1)))) ...
            * vOrtInn(t-1, :))) + (mGamma .* mBeta_t(:, :, t - 1)); %13, 14 e 15 provare solo con 3 asse
        mH_SS(:, :, t) = C0 * (1 - A_2 - B_2) + A_2 * ...
            (mEpsSim_SS(t - 1, :)' * mEpsSim_SS(t - 1, :)) + B_2 * mH_SS(:, :, t - 1);
        mu(t, :) = ((mBeta_t(:, :, t) * mFactors_Sim(t, :)'))';
        [ve, va] = eig(mH_SS(:, :, t));
        mEpsSim_SS(t, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrReturns, 1))'; % Returns
        mReturns_Sim(t, :) = mu(t, :) + mEpsSim_SS(t, :);
    end
    %-End simulation step-------------------------------------------------------------------------------------------------------------------------------------
    mReturns_Sim = mReturns_Sim(dDrop + 1:end, :);
    mFactors_Sim = mFactors_Sim(dDrop + 1:end, :);
    mBeta_start = mBeta_t(:, :, dDrop + 1);
    mH_FS_start = mH_FS(:,:,dDrop + 1);
    mH_SS_start = mH_SS(:,:,dDrop + 1);
    mu_start = mu(dDrop + 1,:);
    
    %-Estimation step-------------------------------------------------------------------------------------------------------------------------------------
    startparam = vPar0;
    mParSim_tmp = [];
    mMatrixBetaOLS_tmp = [];
    
    for s = 1:size(vcT, 1)
        for m = 1: size(method,1)
            
            [vPar, mBeta_OLS, mSigma_f_est, ~, ~] = fEstimateMC_2...
                (mReturns_Sim(1:vcT(s),:), mFactors_Sim(1:vcT(s),:), method(m), startparam, betatargeting, mBeta_start, mH_FS_start, mH_SS_start, mu_start);
            
            vSigma_f_est = reshape(tril(mSigma_f_est), iNrFactors^2,1);
            vSigma_f_est(vSigma_f_est==0) = [];
            
            if method(m)==1 || method(m)==2 || method(m)==3 || method(m)==4
                if betatargeting == 1
                    mParSim_tmp = [mParSim_tmp; [vSigma_f_est(:); vPar(1:2); mBeta_OLS(:); vPar(3:end)]];
                elseif betatargeting == 0
                    mParSim_tmp = [mParSim_tmp; [vSigma_f_est(:); vPar(1:end)]];
                end
            elseif method(m)==5 %NOTE the order of the parameters is different for betatargeting = 1 and 0
                if betatargeting == 1
                    mParSim_tmp = [mParSim_tmp; [vSigma_f_est(:); vPar(1:2*iNrFactors); mBeta_OLS(:); vPar(2*iNrFactors+1:end)]];
                elseif betatargeting == 0
                    mParSim_tmp = [mParSim_tmp; [vSigma_f_est(:); vPar(1:end)]];
                end
            end
            mMatrixBetaOLS_tmp = [mMatrixBetaOLS_tmp; mBeta_OLS(:)];
        end
    end
    mParSim(j+1,:) = mParSim_tmp';
    mMatrixBetaOLS(j+1,:) = mMatrixBetaOLS_tmp';
end
counter_close(1);

idx__ = 0;
idx___ = 1;
for s = 1:size(vcT, 1)
    for m = 1: size(method,1)
        idx_ = idx__+1;
        idx__ = idx__+size_par(m);
        aParSim{s,m} = mParSim(:,idx_:idx__);      
        aMatrixBetaOLS{s,m} = mMatrixBetaOLS(:,iNrReturns*iNrFactors*(idx___-1)+1:iNrReturns*iNrFactors*idx___);
        idx___ = idx___+1;
    end
end

save(strcat('Simulation_', ...
    '_NrRep_', num2str(iRept), '_BTarget_', num2str(betatargeting),'_ALLMLEMethods_',num2str(ind),'.mat'));
end