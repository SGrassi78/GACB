% ----------------------------------------------------------------------- %
%   This reproduces the results 
% S2: Relative efficiency under $\bB_t$ and $\mathcal{S}_{22,t}$ targeting.
% ----------------------------------------------------------------------- %
clear all;
nF = 3;
nR = 10;
vcT = 3100;  %750 1500 3000
dDrop = 0;
acf = 100;
iRept = 5000;
% set parameters uncond variance and beta
mSigma_f = repmat(0.1,nF,nF)+diag(repmat(0.9,nF,1));
mSigma_r_f = repmat(0.5,nR,nR)+diag(repmat(0.5,nR,1));
mBeta_UncOLS = repmat(0.5,nR,nF);

mSigma_rf = [eye(nF) zeros(nF,nR);mBeta_UncOLS eye(nR)]*[mSigma_f zeros(nF,nR); zeros(nR,nF) mSigma_r_f]*[eye(nF) zeros(nF,nR); mBeta_UncOLS eye(nR)]'; % full unc variance
% vectorization of sqrt of the cov matrices of the two blocks
vCholSigma_r_f=reshape(chol(mSigma_r_f)',nR^2,1);
vCholSigma_r_f=vCholSigma_r_f(vCholSigma_r_f~=0);

% param beta
omg = repmat(0.04,nR,nF);
gma = repmat(0.93,nR,nF);
% param garch first block 
vPar_EstFS = [0.04; 0.93];
% param second block
vPar_EstSS = [mBeta_UncOLS(:); vCholSigma_r_f; vPar_EstFS; omg(:); gma(:)];
% vector of starting values 
vPar0 = vPar_EstSS;
% -------------------------------------------------------- %
%            Put the parameters and start the sim
% -------------------------------------------------------- %
% ------------ Set the parameters ---------------- %

% -- MGarch parameters 1step-- %
mV0 = mSigma_f;
A_1 = vPar_EstFS(1);
B_1 = vPar_EstFS(2);

% -- MGarch parameters 2step-- %
C0 = mSigma_r_f;
iIdx__ = nF * nR + nR*(nR+1)/2;
A_2 = vPar_EstSS(iIdx__ + 1);
B_2 = vPar_EstSS(iIdx__ + 2);

% -------- Beta parameters ------- %
mBeta_Unc = reshape(vPar_EstSS(1:nF * nR, 1), nR, nF);
mOmega = reshape(vPar_EstSS(iIdx__ + 3:iIdx__ + 3 + nR * nF - 1), nR, nF);
mGamma = reshape(vPar_EstSS(iIdx__ + 3 + nR * nF:iIdx__+ 3 + (nR * 2 * nF) - 1), nR, nF);
mPsi = mBeta_Unc .*(ones(nR, nF) - mGamma);
% ------------------------------------------------------- %
%                Start the Monte Carlo loop
% ------------------------------------------------------- %
% matrices to store the results
% vPar0 -> betaols, cov2step, garch, omg, gma
vSigma_r_f=reshape(tril(mSigma_r_f),nR^2,1);
vSigma_r_f=vSigma_r_f(vSigma_r_f~=0);

% set up matrices to collect results
% betatarget=0 covtarget =0
mParSim_00 = [[mBeta_UncOLS(:); vSigma_r_f; vPar_EstFS; omg(:); gma(:); 0]'; zeros(iRept, size(vPar0,1)+1)];
% betatarget=1 covtarget =0
mParSim_10 = mParSim_00;
% betatarget=0 covtarget =1
mParSim_01 = mParSim_00;
% betatarget=1 covtarget =1
mParSim_11 = mParSim_00;

C = clock;
fprintf([num2str(C(2)) '/' num2str(C(3)) ' - ' num2str(C(4)) ':' num2str(C(5)), '\n'])
counter_set(iRept,1);
parfor ns=1:iRept    
    counter_progress(iRept,ns);

    % --------------------------------------------------- %
    %           Step 1 Simulate v1 and v2 Betas and Returns
    % --------------------------------------------------- %
    
    v1 = zeros(vcT + dDrop, nF);
    mH_v1 = mV0;
    
    v2 = zeros(vcT + dDrop, nR);
    mH_v2 = C0;
    
    e2 = zeros(vcT + dDrop, nR);
    mBeta_t = mBeta_Unc;
    mu = ((mBeta_t * v1(1, :)'))';
    
    for tt = 2:vcT + dDrop
        mH_v1 = mV0 * (1 - A_1 - B_1) + A_1 * (v1(tt - 1, :)'...
            * v1(tt - 1, :)) + B_1 * mH_v1 ; 
        [ve, va] = eig(mH_v1);
        v1(tt, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, nF, 1))';
        
        mH_v2 = C0 * (1 - A_2 - B_2) + A_2 * (v2(tt - 1, :)'...
            * v2(tt - 1, :)) + B_2 * mH_v2 ; 
        [ve, va] = eig(mH_v2);
        v2(tt, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, nR, 1))';
    
        mBeta_t = mPsi + (mOmega .* ((v2(tt - 1,:)') ...
            * v1(tt - 1, :))) + (mGamma .* mBeta_t); 
        e2(tt, :) = ((mBeta_t * v1(tt, :)'))' + v2(tt, :);
    end
    
    %-End simulation step-------------------------------------------------------------------------------------------------------------------------------------
    [param, ~, ~, exitflag] = fEstimate_simultargeting(e2, v1, vPar0, 1, 1, acf);
    mParSim_11(ns+1,:) = [param exitflag];
    [param, ~, ~, exitflag] = fEstimate_simultargeting(e2, v1, param', 1, 0, acf);
    mParSim_10(ns+1,:) = [param exitflag];
    
    [param, ~, ~, exitflag] = fEstimate_simultargeting(e2, v1, param', 0, 1, acf);
    mParSim_01(ns+1,:) = [param exitflag];
        
    [param, ~, ~, exitflag] = fEstimate_simultargeting(e2, v1, param', 0, 0, acf);
    mParSim_00(ns+1,:) = [param exitflag];
    
end
C = clock;
fprintf([num2str(C(2)) '/' num2str(C(3)) ' - ' num2str(C(4)) ':' num2str(C(5)), '\n'])
   
% mkdir(strcat('C:/Users/FV/Dropbox/Asset pricing crypto/Coin/All'));  
     save(strcat('W:/FV_Documents/SorgentiFrancesco/MonteCarlo_Simulations/Simul_7_10_2021/Simul_beta_cov_targeting/simul_paper_revision_jbes/T_',...
        num2str(vcT),'_acf_',num2str(acf),'_iRept_',num2str(iRept),'.mat'),'mParSim_00','mParSim_10','mParSim_01','mParSim_11');
   
    
    
    
    
    
    
    
    
    
    
    
    
 samp = [850 1600 3100];%[750,1500,3000];
 rep = [5000];
 summary_b = zeros(8,7);
 summary_r = zeros(8,7);
 for j = 1:3
     load(strcat('simul_paper_revision_jbes\T_',num2str(samp(j)),'_acf_100_iRept_',num2str(rep),'.mat'))
     [sum(mParSim_00(2:end,end)~=2) sum(mParSim_10(2:end,end)~=2) sum(mParSim_01(2:end,end)~=2) sum(mParSim_11(2:end,end)~=2)]

     aParSim = {mParSim_00, mParSim_10, mParSim_01, mParSim_11};
     
     for k=1:4
         idx_v = logical([zeros(1, nR*nF) aParSim{k}(1,nR*nF+1:nR*nF+nR*(nR+1)/2)==1 zeros(1, length(aParSim{k}(1,:))- (nR*nF+nR*(nR+1)/2))]);
         idx_c = logical([zeros(1, nR*nF) aParSim{k}(1,nR*nF+1:nR*nF+nR*(nR+1)/2)==0.5 zeros(1, length(aParSim{k}(1,:))- (nR*nF+nR*(nR+1)/2))]);

         aParSim{k}(logical([0; aParSim{k}(2:end,end)==0]),:) = [];   
         %eliminate when garch beta fails
         aParSim{k}(aParSim{k}(1:end,nR*nF+nR*(nR+1)/2+2)<0.9,:)=[];

         B = aParSim{k}(1:end,1:nR*nF);
         s1 = aParSim{k}(1:end,idx_v);
         s2 = aParSim{k}(1:end,idx_c);
         a = aParSim{k}(1:end,nR*nF+nR*(nR+1)/2+1);
         b = aParSim{k}(1:end,nR*nF+nR*(nR+1)/2+2);
         o = aParSim{k}(1:end,nR*nF+nR*(nR+1)/2+3:2*nR*nF+nR*(nR+1)/2+2);
         g = aParSim{k}(1:end,2*nR*nF+nR*(nR+1)/2+3:3*nR*nF+nR*(nR+1)/2+2);

         summary_b(k+4*(j-1),1) = mean(mean(B-B(1,:)));
         summary_r(k+4*(j-1),1) = mean(sqrt(mean((B-B(1,:)).^2)));
         summary_b(k+4*(j-1),2) = mean(mean(s1-s1(1,:)));
         summary_r(k+4*(j-1),2) = mean(sqrt(mean((s1-s1(1,:)).^2)));
         summary_b(k+4*(j-1),3) = mean(mean(s2-s2(1,:)));
         summary_r(k+4*(j-1),3) = mean(sqrt(mean((s2-s2(1,:)).^2)));

         summary_b(k+4*(j-1),4) = mean(mean(a-a(1,:)));
         summary_r(k+4*(j-1),4) = mean(sqrt(mean((a-a(1,:)).^2)));
         summary_b(k+4*(j-1),5) = mean(mean(b-b(1,:)));
         summary_r(k+4*(j-1),5) = mean(sqrt(mean((b-b(1,:)).^2)));

         for i = 1 : size(g,2)
             idx = logical(g(:,i)>0.65);
             o_tmp_b(i) = mean(o(idx,i)-o(1,i));
             o_tmp_r(i) = sqrt(mean((o(idx,i)-o(1,i)).^2));
             g_tmp_b(i) = mean(g(idx,i)-g(1,i));
             g_tmp_r(i) = sqrt(mean((g(idx,i)-g(1,i)).^2));
         end
         summary_b(k+4*(j-1),6:7) = [mean(o_tmp_b) mean(g_tmp_b)];
         summary_r(k+4*(j-1),6:7) = [mean(o_tmp_r) mean(g_tmp_r)];
      
     end     
     
 end 
     
 rel_rmse = summary_r./(ones(12,1)*[0.5 1 0.5 0.4 0.93 0.4 0.93]);
     
     
%  samp = [850 1600];%[750,1500,3000];
%  rep = [5000];
%  summary_b = zeros(8,7);
%  summary_r = zeros(8,7);
%  for j = 1:2
%      load(strcat('simul_paper_revision_jbes\T_',num2str(samp(j)),'_acf_100_iRept_',num2str(rep),'.mat'))
%      [sum(mParSim_00(2:end,end)~=2) sum(mParSim_10(2:end,end)~=2) sum(mParSim_01(2:end,end)~=2) sum(mParSim_11(2:end,end)~=2)]
%      
%      bias = mean(mParSim_00-mParSim_00(1,:));
%      rmse = sqrt(mean((mParSim_00-mParSim_00(1,:)).^2));
% 
%      mParSim_10(logical([0; mParSim_10(2:end,end)~=2]),:) = [];   
%      bias = [bias; mean(mParSim_10-mParSim_00(1,:))];
%      rmse = [rmse; sqrt(mean((mParSim_10-mParSim_00(1,:)).^2))];
% 
%      mParSim_01(logical([0; mParSim_01(2:end,end)~=2]),:) = [];   
%      bias = [bias; mean(mParSim_01-mParSim_00(1,:))];
%      rmse = [rmse; sqrt(mean((mParSim_01-mParSim_00(1,:)).^2))];
% 
%      mParSim_11(logical([0; mParSim_11(2:end,end)~=2]),:) = [];   
%      bias = [bias; mean(mParSim_11-mParSim_00(1,:))];
%      rmse = [rmse; sqrt(mean((mParSim_11-mParSim_00(1,:)).^2))];
% 
%      idx_v = logical([zeros(1, nR*nF) mParSim_00(1,nR*nF+1:nR*nF+nR*(nR+1)/2)==1 zeros(1, length(mParSim_00(1,:))- (nR*nF+nR*(nR+1)/2))]);
%      idx_c = logical([zeros(1, nR*nF) mParSim_00(1,nR*nF+1:nR*nF+nR*(nR+1)/2)==0.5 zeros(1, length(mParSim_00(1,:))- (nR*nF+nR*(nR+1)/2))]);
%      
%      summary_b = [summary_b; [mean(bias(:,1:nR*nF),2), mean(bias(:,idx_v),2) mean(bias(:,idx_c),2) bias(:,nR*nF+nR*(nR+1)/2+1:nR*nF+nR*(nR+1)/2+2),...
%          mean(bias(:,nR*nF+nR*(nR+1)/2+3:2*nR*nF+nR*(nR+1)/2+2),2), mean(bias(:,2*nR*nF+nR*(nR+1)/2+3:3*nR*nF+nR*(nR+1)/2+2),2)]];
% 
%      summary_r = [summary_r; [mean(rmse(:,1:nR*nF),2),  mean(rmse(:,idx_v),2) mean(rmse(:,idx_c),2) rmse(:,nR*nF+nR*(nR+1)/2+1:nR*nF+nR*(nR+1)/2+2),...
%          mean(rmse(:,nR*nF+nR*(nR+1)/2+3:2*nR*nF+nR*(nR+1)/2+2),2), mean(rmse(:,2*nR*nF+nR*(nR+1)/2+3:3*nR*nF+nR*(nR+1)/2+2),2)]];
% 
%   end
%  
% 
