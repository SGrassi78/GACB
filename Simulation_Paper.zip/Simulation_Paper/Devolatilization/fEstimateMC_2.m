% ----------------------------------------------------------------------- %
%                Function that estimated the beta MGARCH 
% ----------------------------------------------------------------------- %
function [param, mBeta_OLS, mSigma_f, mSigma_r_f, exitflag] ...
       = fEstimateMC_2(mReturns, mFactors, method, startparam, betatargeting, mBeta_start, mH_FS_start, mH_SS_start, mu_start)
       % ---------------------------------------------------------------- %
       %                     House keeping 
       % ---------------------------------------------------------------- %
       iNrFactors = size(mFactors, 2);
       iNrReturns = size(mReturns, 2);
       % ---------------------------------------------------------------- %
       %                  Maximum likelihood set up
       % ---------------------------------------------------------------- %
       options = optimset('Algorithm','interior-point', 'Display','off', ...
              'MaxFunEvals', 100000,'MaxIter', 100000, 'TolFun', 1e-6, 'TolX', 1e-6,...
                     'LargeScale', 'on', 'UseParallel', false);          
       % ---------------------------------------------------------------- %
       %              Calculate S_rf S_f and S_r|f
       % ---------------------------------------------------------------- %
       mSigma_rf = cov([mFactors mReturns]);
       mSigma_f = mSigma_rf(1:iNrFactors, 1:iNrFactors);  
       mSigma_r_f = mSigma_rf(iNrFactors + 1:end, iNrFactors + 1:end) - mSigma_rf(iNrFactors + 1:end, 1:iNrFactors) *...
              inv(mSigma_rf(1:iNrFactors, 1:iNrFactors)) * mSigma_rf(iNrFactors + 1:end, 1:iNrFactors)'; 
       mBeta_OLS = mSigma_rf(iNrFactors + 1:end, 1:iNrFactors)/(mSigma_f);
       
       % ---------------------------------------------------------------- %
       %                      Equartion 5
       % ---------------------------------------------------------------- %
       % ------------------- Mgarch parameters ----------------------- %
       startingVals_Mgarch = [0.04; 0.93];
       LB_Mgarch = [0.0001; 0.8];
       UB_Mgarch = [0.2; 1];
       % ------------------- Beta equation parameters   -------------- %
       startingVals_BetaUnc = mBeta_OLS;
       LB_BetaUnc = 0 *ones(iNrReturns * iNrFactors, 1);
       UB_BetaUnc = 1 *ones(iNrReturns * iNrFactors, 1);
       
       startingVals_Omega = 0.04 .* ones(iNrReturns * iNrFactors, 1);
       LB_Omega = 0 * ones(iNrFactors * iNrReturns, 1);
       UB_Omega = 0.1 * ones(iNrFactors * iNrReturns, 1);
      
       startingVals_Gamma = 0.93.* ones(iNrReturns, iNrFactors);
       mTemp = 0.7 * ones(iNrReturns, iNrFactors);
       LB_Gamma = mTemp(:);
       mTemp = 1 * ones(iNrReturns, iNrFactors);
       UB_Gamma = mTemp(:);

       
       startingVals_Sigma_r_fUnc = startparam(2+iNrReturns*iNrFactors+1:2+iNrReturns*iNrFactors+iNrReturns*(iNrReturns+1)/2);    
       LB_Sigma_r_fUnc = startingVals_Sigma_r_fUnc/10; %0.001 *ones(iNrReturns * (iNrReturns+1)/2, 1);
       UB_Sigma_r_fUnc = startingVals_Sigma_r_fUnc*2; %3 *ones(iNrReturns * (iNrReturns+1)/2, 1);
          
       % ------------------- Set start param and estimation method ------------------ %
       startingVals_f = [startingVals_Mgarch; startingVals_BetaUnc(:); startingVals_Sigma_r_fUnc;...
           startingVals_Mgarch; startingVals_Omega(:); startingVals_Gamma(:)];
       LB_f = [LB_Mgarch; LB_BetaUnc; LB_Sigma_r_fUnc; LB_Mgarch; LB_Omega; LB_Gamma];
       UB_f = [UB_Mgarch; UB_BetaUnc; UB_Sigma_r_fUnc; UB_Mgarch; UB_Omega; UB_Gamma];

       if ~isempty(startparam) && size(startparam,1)==size(startingVals_f,1)
              startingVals_f = startparam;
       end
          
       if betatargeting == 1
              startingVals_f(3:2+iNrFactors*iNrReturns) = [];
              LB_f(3:2+iNrFactors*iNrReturns) = [];
              UB_f(3:2+iNrFactors*iNrReturns) = [];
       end
        
       if method == 1 % joint estimation
           A = [zeros(iNrFactors*iNrReturns,length(startingVals_f)-2*iNrFactors*iNrReturns) eye(iNrFactors*iNrReturns) eye(iNrFactors*iNrReturns)];
           b = 0.999*ones(iNrFactors*iNrReturns,1);
           [param, ~, exitflag, ~, ~, ~, ~] = ...
                  fmincon(@joint_likelihood, startingVals_f, A, b,...
                  [],[], LB_f, UB_f, [], options, mReturns, mFactors, mBeta_OLS, mSigma_f, mSigma_r_f, betatargeting, 0, mBeta_start, mH_FS_start, mH_SS_start, mu_start);
              
       elseif method == 2 % joint estimation no correlation
           sel = reshape((tril(ones(iNrReturns))+eye(iNrReturns)),iNrReturns^2,1);
           sel(sel==0 ) = [];
           sel = (sel==2);
               
           idx = ones(size(startingVals_f,1),1);
           if betatargeting==0
               idx0 = 2 + iNrFactors*iNrReturns+1;
               idx1 = 2 + iNrFactors*iNrReturns + iNrReturns * (iNrReturns+1)/2;               
           elseif betatargeting==1
               idx0 = 3;
               idx1 = 2 + iNrReturns * (iNrReturns+1)/2;               
           end
           idx(idx0:idx1) = sel;
           
           startingVals_f_tmp = startingVals_f(logical(idx));
           A = [zeros(iNrFactors*iNrReturns,length(startingVals_f_tmp)-2*iNrFactors*iNrReturns) eye(iNrFactors*iNrReturns) eye(iNrFactors*iNrReturns)];
           b = 0.999*ones(iNrFactors*iNrReturns,1);
           
           [param, ~, exitflag, ~, ~, ~, ~] = ...
                  fmincon(@joint_likelihood, startingVals_f_tmp, A, b,...
                  [],[], LB_f(logical(idx)), UB_f(logical(idx)), [], options, mReturns, mFactors, mBeta_OLS, mSigma_f, mSigma_r_f, betatargeting, 1, mBeta_start, mH_FS_start, mH_SS_start, mu_start);
           
            param_tmp = zeros(size(idx,1),1);
            param_tmp(logical(idx)) = param;
            param = param_tmp;
           
       elseif method == 3 % two step estimation
           [param_FS, ~, ~, ~, ~, ~, ~] = ...
                  fmincon(@scalar_bekk_likelihood, startingVals_f(1:2), [], [],...
                  [],[], LB_f(1:2), UB_f(1:2), [], options, mFactors, mSigma_f, 0, mH_FS_start);
           
           [~, ~, ~, ~, ~, fOrt_Inn] = scalar_bekk_likelihood(param_FS, mFactors, mSigma_f, 0, mH_FS_start);
           
           A = [zeros(iNrFactors*iNrReturns,length(startingVals_f(3:end))-2*iNrFactors*iNrReturns) eye(iNrFactors*iNrReturns) eye(iNrFactors*iNrReturns)];
           b = 0.999*ones(iNrFactors*iNrReturns,1);
           
           [param_SS, ~, exitflag, ~, ~, ~, ~] = fmincon(@beta_garch_likelihood, startingVals_f(3:end), A, b,...
               [], [], LB_f(3:end), UB_f(3:end), [], options, mReturns, mFactors, fOrt_Inn, mBeta_OLS, mSigma_r_f, betatargeting, 0, mBeta_start, mH_SS_start, mu_start);
           
           param = [param_FS; param_SS];

       elseif method == 4 % two step estimation no correlation
           sel = reshape((tril(ones(iNrReturns))+eye(iNrReturns)),iNrReturns^2,1);
           sel(sel==0 ) = [];
           sel = (sel==2);
               
           idx = ones(size(startingVals_f,1),1);
           if betatargeting==0
               idx0 = 2 + iNrFactors*iNrReturns+1;
               idx1 = 2 + iNrFactors*iNrReturns + iNrReturns * (iNrReturns+1)/2;               
           elseif betatargeting==1
               idx0 = 3;
               idx1 = 2 + iNrReturns * (iNrReturns+1)/2;               
           end
           idx(idx0:idx1) = sel;
           startingVals_f_tmp = startingVals_f(logical(idx));
           LB_f_tmp = LB_f(logical(idx));
           UB_f_tmp = UB_f(logical(idx));
           
           [param_FS, ~, ~, ~, ~, ~, ~] = ...
                  fmincon(@scalar_bekk_likelihood, startingVals_f_tmp(1:2), [], [],...
                  [],[], LB_f_tmp(1:2), UB_f_tmp(1:2), [], options, mFactors, mSigma_f, 1, mH_FS_start);         
           
           [~, ~, ~, ~, ~, fOrt_Inn] = scalar_bekk_likelihood(param_FS, mFactors, mSigma_f, 1, mH_FS_start);
           
           A = [zeros(iNrFactors*iNrReturns,length(startingVals_f_tmp(3:end))-2*iNrFactors*iNrReturns) eye(iNrFactors*iNrReturns) eye(iNrFactors*iNrReturns)];
           b = 0.999*ones(iNrFactors*iNrReturns,1);
           
           [param_SS, ~, exitflag, ~, ~, ~, ~] = fmincon(@beta_garch_likelihood, startingVals_f_tmp(3:end), A, b,... 
               [], [], LB_f_tmp(3:end), UB_f_tmp(3:end), [], options, mReturns, mFactors, fOrt_Inn, mBeta_OLS, mSigma_r_f, betatargeting, 1, mBeta_start, mH_SS_start, mu_start);
   
           param = [param_FS; param_SS];
           
           param_tmp = zeros(size(idx,1),1);
           param_tmp(logical(idx)) = param;
           param = param_tmp;
           

       elseif method == 5 % eq-by-eq estimation no correlation
           sel = reshape((tril(ones(iNrReturns))+eye(iNrReturns)),iNrReturns^2,1);
           sel(sel==0 ) = [];
           sel = (sel==2);
               
           idx = ones(size(startingVals_f,1),1);
           if betatargeting==0
               idx0 = 2 + iNrFactors*iNrReturns+1;
               idx1 = 2 + iNrFactors*iNrReturns + iNrReturns * (iNrReturns+1)/2;               
           elseif betatargeting==1
               idx0 = 3;
               idx1 = 2 + iNrReturns * (iNrReturns+1)/2;               
           end
           idx(idx0:idx1) = sel;
           startingVals_f_tmp = startingVals_f(logical(idx));
           LB_f_tmp = LB_f(logical(idx));
           UB_f_tmp = UB_f(logical(idx));

           param_FS = [];
           fOrt_Inn = [];
           for i = 1:iNrFactors
                [param_FS_i, ~, ~, ~, ~, ~, ~] = ...
                  fmincon(@scalar_bekk_likelihood, startingVals_f_tmp(1:2), [], [],...
                  [],[], LB_f_tmp(1:2), UB_f_tmp(1:2), [], options, mFactors(:,i), mSigma_f(i,i), 0, mH_FS_start(i,i));
                
                param_FS = [param_FS; param_FS_i];
                
                [~, ~, ~, ~, ~, fOrt_Inn_i] = scalar_bekk_likelihood(param_FS_i, mFactors(:,i), mSigma_f(i,i), 0, mH_FS_start(i,i));
                fOrt_Inn = [fOrt_Inn fOrt_Inn_i];
           end
           
           
           param_SS = [];
           for i = 1:iNrReturns
                if betatargeting==0
                    B = reshape(startingVals_f_tmp(3:2+iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    LB = reshape(LB_f_tmp(3:2+iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    UB = reshape(UB_f_tmp(3:2+iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    H = startingVals_f_tmp(3+iNrFactors*iNrReturns:4+iNrReturns+iNrFactors*iNrReturns);
                    LH = LB_f_tmp(3+iNrFactors*iNrReturns:4+iNrReturns+iNrFactors*iNrReturns);
                    UH = UB_f_tmp(3+iNrFactors*iNrReturns:4+iNrReturns+iNrFactors*iNrReturns);
                    O = reshape(startingVals_f_tmp(5+iNrReturns+iNrFactors*iNrReturns:4+iNrReturns+2*iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    LO = reshape(LB_f_tmp(5+iNrReturns+iNrFactors*iNrReturns:4+iNrReturns+2*iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    UO = reshape(UB_f_tmp(5+iNrReturns+iNrFactors*iNrReturns:4+iNrReturns+2*iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    G = reshape(startingVals_f_tmp(5+iNrReturns+2*iNrFactors*iNrReturns:4+iNrReturns+3*iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    LG = reshape(LB_f_tmp(5+iNrReturns+2*iNrFactors*iNrReturns:4+iNrReturns+3*iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    UG = reshape(UB_f_tmp(5+iNrReturns+2*iNrFactors*iNrReturns:4+iNrReturns+3*iNrFactors*iNrReturns), iNrReturns, iNrFactors);
           
                    startingVals_f_i = [B(i,:)'; H(i); H(iNrReturns+1:end); O(i,:)'; G(i,:)'];
                    LB_i = [LB(i,:)'; LH(i); LH(iNrReturns+1:end); LO(i,:)'; LG(i,:)'];
                    UB_i = [UB(i,:)'; UH(i); UH(iNrReturns+1:end); UO(i,:)'; UG(i,:)'];

                    
                elseif betatargeting==1
                    H = startingVals_f_tmp(3:4+iNrReturns);
                    LH = LB_f_tmp(3:4+iNrReturns);
                    UH = UB_f_tmp(3:4+iNrReturns);
                    O = reshape(startingVals_f_tmp(5+iNrReturns:4+iNrReturns+iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    LO = reshape(LB_f_tmp(5+iNrReturns:4+iNrReturns+iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    UO = reshape(UB_f_tmp(5+iNrReturns:4+iNrReturns+iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    G = reshape(startingVals_f_tmp(5+iNrReturns+iNrFactors*iNrReturns:4+iNrReturns+2*iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    LG = reshape(LB_f_tmp(5+iNrReturns+iNrFactors*iNrReturns:4+iNrReturns+2*iNrFactors*iNrReturns), iNrReturns, iNrFactors);
                    UG = reshape(UB_f_tmp(5+iNrReturns+iNrFactors*iNrReturns:4+iNrReturns+2*iNrFactors*iNrReturns), iNrReturns, iNrFactors);
           
                    startingVals_f_i = [H(i); H(iNrReturns+1:end); O(i,:)'; G(i,:)'];
                    LB_i = [LH(i); LH(iNrReturns+1:end); LO(i,:)'; LG(i,:)'];
                    UB_i = [UH(i); UH(iNrReturns+1:end); UO(i,:)'; UG(i,:)'];
                
                end
                
                A = [zeros(iNrFactors,length(startingVals_f_i)-2*iNrFactors) eye(iNrFactors) eye(iNrFactors)];
                b = 0.999*ones(iNrFactors,1);
           
                [param_SS_i, ~, exitflag, ~, ~, ~, ~] = fmincon(@beta_garch_likelihood, startingVals_f_i, [], [],...
                    [], [], LB_i, UB_i, [], options, mReturns(:,i), mFactors, fOrt_Inn, mBeta_OLS(i,:), mSigma_r_f(i,i), betatargeting, 0, mBeta_start(i,:), mH_SS_start(i,i), mu_start(:,i));
                param_SS = [param_SS; param_SS_i];
           end
           
           param = [param_FS; param_SS];
           
       end
       
end



function [ll, lls, mu_FS, mH_FS, eps_FS, fOrt_Inn, mu_SS, mH_SS, eps_SS, eta2_SS, mBeta_t] = joint_likelihood(vPar, ...
       mReturns, mFactors, mBeta_Unc, mSigma_f, mSigma_r_f, betatargeting, diag_H, mBeta_start, mH_FS_start, mH_SS_start, mu_start)


    [ll_FS, lls_FS, mu_FS, mH_FS, eps_FS, fOrt_Inn] = scalar_bekk_likelihood(vPar(1:2), mFactors, mSigma_f, diag_H, mH_FS_start);

    [ll_SS, lls_SS, mu_SS, mH_SS, eps_SS, eta2_SS, mBeta_t] = beta_garch_likelihood(vPar(3:end), ...
           mReturns, mFactors, fOrt_Inn, mBeta_Unc, mSigma_r_f, betatargeting, diag_H, mBeta_start, mH_SS_start, mu_start);

    ll = ll_FS + ll_SS;
    lls = lls_FS + lls_SS;

end

% ----------------------------------------------------------------------- %
%     Estimate the scalar BEKK for the factors  S_f,t in the paper 
% ----------------------------------------------------------------------- %
function [ll, lls, mu, mH, eps, devol] = scalar_bekk_likelihood(vPar, mReturns, mSigma_f, diag_H, mH_FS_start)
       [cT, iNrReturns] = size(mReturns);
       A = vPar(1);
       B = vPar(2);
       %filtered time series
       mu = repmat(mean(mReturns), cT + 1, 1);
       mH(:, :, 1) = mH_FS_start; %mSigma_f;
       mH(:, :, cT + 1) = mH_FS_start; %mSigma_f;
       eta2 = zeros(cT, 1);
       eps = mReturns - mean(mReturns);
       devol = zeros(cT, iNrReturns); 
       lls = zeros(cT, 1);
       for i = 2:cT + 1
           mH(:, :, i) = mSigma_f * (1 - A - B) + A * (eps(i - 1, :)' * eps(i - 1, :)) + B * mH(:, :, i - 1);
           if i == cT + 1 % this is to have the last iteration as 1-step forecast
               break;
           end
           devol(i, :) = eps(i, :)./sqrt(diag(mH(:, :, i)))';
           if diag_H == 1
               eta2(i) = devol(i, :)*devol(i, :)';
               lls(i) = -0.5 * (iNrReturns * log(2 * pi) + sum(log(diag(mH(:, :, i)))) + eta2(i));
           else    
               eta2(i) = eps(i, :) * (mH(:, :, i)\eps(i, :)');  %full
               lls(i) = -0.5 * (iNrReturns * log(2 * pi) + log(det(mH(:, :, i))) + eta2(i));
           end
       end
       ll = - mean(lls(100:end));
       if (isnan(ll) || ~isreal(ll) || isinf(ll))
           ll = 1e7;
       end
end
% ----------------------------------------------------------------------- %
%             Estimation of the conditional beta
% ----------------------------------------------------------------------- %
function [ll, lls, mu, mH, eps, eta2, mBeta_t] = beta_garch_likelihood(vPar, ...
       mReturns, mFactors, fOrt_Inn, mBeta_Unc, mSigma_r_f, betatargeting, diag_H, mBeta_start, mH_SS_start, mu_start)

       [cT, iNrReturns] = size(mReturns);     
       iNrFactors = size(mFactors, 2);
       
       % -------- Center mFactors --------- %
       mFactors = mFactors - mean(mFactors);
       mReturns = mReturns - mean(mReturns);
       
       eta2 = zeros(cT, 1);
       eps = zeros(cT, iNrReturns);
       lls = zeros(cT, 1);
       %mu = repmat(median(mReturns(1:20, :)), cT + 1, 1);
       mu = repmat(mu_start, cT + 1, 1);
       %mH(:, :, 1) = mSigma_r_f;
       mH(:, :, 1) = mH_SS_start;
       mH(:, :, cT + 1) = mSigma_r_f;
       %eps(1, :) = mReturns(1, :) - mean(mReturns);
       eps(1, :) = mReturns(1, :) - mu(1, :);
       devol = zeros(cT, iNrReturns); 
        
       % ---------------------------------------------------------------- %
       %  B_t =\Psi+(\Omega.*\Xi_r_t-1*\Xi_f_t-1)+(\Gamma.*B_t-1) Eq 13
       % ---------------------------------------------------------------- %
       % -- Unconditional beta Parameters -- %
       iIndx__= 0;
       if betatargeting == 1 && diag_H == 0
              iIndx__= iNrReturns*(iNrReturns+1)/2;
              LT = zeros(iNrReturns);
              LT((tril(ones(iNrReturns)))~=0) = vPar(1:iIndx__, 1);
              H0 = LT*LT';
       elseif betatargeting == 1 && diag_H == 1
              iIndx__= iNrReturns;
              LT = zeros(iNrReturns);
              LT((eye(iNrReturns))~=0) = vPar(1:iIndx__, 1);
              H0 = LT*LT';           
       elseif betatargeting == 0 && diag_H == 0
              iIndx0__ = iNrFactors * iNrReturns;
              mBeta_Unc = reshape(vPar(1:iIndx0__, 1), iNrReturns, iNrFactors);
              iIndx__ = iNrFactors * iNrReturns + iNrReturns*(iNrReturns+1)/2;
              LT = zeros(iNrReturns);
              LT((tril(ones(iNrReturns)))~=0) = vPar(iIndx0__+1:iIndx__, 1);
              H0 = LT*LT';
       elseif betatargeting == 0 && diag_H == 1
              iIndx0__ = iNrFactors * iNrReturns;
              mBeta_Unc = reshape(vPar(1:iIndx0__, 1), iNrReturns, iNrFactors);
              iIndx__ = iNrFactors * iNrReturns + iNrReturns;
              LT = zeros(iNrReturns);
              LT((eye(iNrReturns))~=0) = vPar(iIndx0__+1:iIndx__, 1);
              H0 = LT*LT';
       end
          % -- MGarch parameters -- %
       A = vPar(iIndx__ + 1);
       B = vPar(iIndx__ + 2);    
       % -------- mOmega ------- % 
       mOmega = reshape(vPar(iIndx__ + 3:iIndx__ + 3 + iNrReturns * iNrFactors - 1), iNrReturns, iNrFactors);
       % -------- mGamma ------- %
       mGamma = reshape(vPar(iIndx__ + 3 + iNrReturns * iNrFactors:iIndx__ + 3 + (iNrReturns * 2 * iNrFactors) - 1), iNrReturns, iNrFactors);
       
       mPsi = mBeta_Unc .*(ones(iNrReturns, iNrFactors) - mGamma);
       mBeta_t(:, :, 1) = mBeta_start;
       mBeta_t(:, :, cT + 1) = mBeta_Unc; 
       % ---------------------------------------------------------------- %
       %                   Estimation of the beta TV                      %
       % ---------------------------------------------------------------- %
       for i = 2:cT + 1
        % ------------------------------------------------------------- %
        %B_t=B.*[e_n*(e_k-\gamma_k)]+e_n w_k.*(\Xi_r_t*\Xi_f_t)+e\gamma.*B_t-1
        % ------------------------------------------------------------- %
           Xi_r = (eps(i - 1, :)'./sqrt(diag(mH(:, :, i - 1))));
           Xi_f = fOrt_Inn(i - 1, :);
           mBeta_t(:, :, i) = fBetas(Xi_r, Xi_f, mBeta_t(:, :, i - 1), mPsi, mOmega, mGamma);
           % ------------------------------------------------------------ %
           % S_r|f,t = S_r|f(1-a-v) + a * (S^1/2*eta*eta*S^1/2) + vSr|f,t-1
           % ------------------------------------------------------------ %
           mH(:, :, i) = H0 * (1 - A - B) + A * (eps(i - 1, :)' * eps(i - 1, :)) ...
                  + B * mH(:, :, i - 1); 
           if i == cT + 1 % this is to have the last iteration as 1-step forecast
               break;
           end
           
           mu(i, :) = ((mBeta_t(:, :, i) * mFactors(i, :)'))';      
           eps(i, :) = mReturns(i, :) - mu(i, :);
           
           devol(i, :) = eps(i, :)./sqrt(diag(mH(:, :, i)))';
           if diag_H == 1
               eta2(i) = devol(i, :)*devol(i, :)';
               lls(i) = -0.5 * (iNrReturns * log(2 * pi) + sum(log(diag(mH(:, :, i)))) + eta2(i));
           else    
               eta2(i) = eps(i, :) * (mH(:, :, i)\eps(i, :)');  %full
               lls(i) = -0.5 * (iNrReturns * log(2 * pi) + log(det(mH(:, :, i))) + eta2(i));
           end
       end
       ll = -mean(lls(100:end));
       if (isnan(ll) || ~isreal(ll) || isinf(ll))
           ll = 1e7;
       end
end
% ----------------------------------------------------------------------- %
%             Function that calculate different TV Betas
% ----------------------------------------------------------------------- %
function [mBeta_t] = fBetas(Xi_r, Xi_f, Beta_t1, mPsi, mOmega, mGamma)
   % -------------------------------------------------------------------- %
   %    B_t= \Gamma + (\Omega .*(\Xi_r_t*\Xi_f_t))+ (\Gamma.*B_t-1) Eq 13
   % -------------------------------------------------------------------- %
       mBeta_t = mPsi + (mOmega .* (Xi_r * Xi_f)) + (mGamma .* Beta_t1); 
end
%-------------------------------------------------------------------------

function [VCV]=robustvcv(fun, param, varargin)

       k=length(param);
       h=max(abs(param*eps^(1/3)),1e-8);
       h=diag(h);
       [~,like,~]=feval(fun,param,varargin{:});
       t=length(like);
       LLFp=zeros(k,1);
       LLFm=zeros(k,1);
       likep=zeros(t,k);
       likem=zeros(t,k);
       for i=1:k
           thetaph=param+h(:,i);
           [LLFp(i),likep(:,i)]=feval(fun,thetaph,varargin{:});
           thetamh=param-h(:,i);
           [LLFm(i),likem(:,i)]=feval(fun,thetamh,varargin{:});
       end
       scores=zeros(t,k);
       gross_scores=zeros(k,1);
       h=diag(h);
       for i=1:k
           scores(:,i)=(likep(:,i)-likem(:,i))./(2*h(i)); 
           gross_scores(i)=(LLFp(i)-LLFm(i))./(2*h(i));
       end
        hess=myhessian(fun,param,varargin{:});

       A=hess;      %likelihood computed as avg so no need to divide by t (divide if llf is the sum)
       Ainv=A^(-1);
       B=cov(scores);
       VCV=(Ainv*B*Ainv)/t;
       end
       %-------------------------------------------------------------------------
function H = hessian_2sided(f,x,varargin)

       n = size(x,1);
       if size(x,2)~=1
           error('X must be a column vector.')
       end
       try
           feval(f,x,varargin{:});
       catch FE
           errtxt=['There was an error evaluating the function.  Please check the arguements.  The specific error was:' FE.message];
           error(errtxt);
       end
       fx = feval(f,x,varargin{:});

       % Compute the stepsize (h)
       h = eps.^(1/3)*max(abs(x),1e-8);
       xh = x+h;
       h = xh-x;
       ee = sparse(1:n,1:n,h,n,n);

       % Compute forward and backward steps
       gp = zeros(n,1);
       gm = zeros(n,1);
       for i=1:n
           gp(i) = feval(f,x+ee(:,i),varargin{:});
           gm(i) = feval(f,x-ee(:,i),varargin{:});
       end

       hh=h*h';
       Hm=NaN*ones(n);
       Hp=NaN*ones(n);
       % Compute "double" forward and backward steps
       for i=1:n
           for j=i:n
               Hp(i,j) = feval(f,x+ee(:,i)+ee(:,j),varargin{:});
               Hp(j,i)=Hp(i,j);
               Hm(i,j) = feval(f,x-ee(:,i)-ee(:,j),varargin{:});
               Hm(j,i)=Hm(i,j);
           end
       end
%Compute the hessian
       H = zeros(n);
       for i=1:n
           for j=i:n
               H(i,j) = (Hp(i,j)-gp(i)-gp(j)+fx+fx-gm(i)-gm(j)+Hm(i,j))/hh(i,j)/2;
               H(j,i) = H(i,j);
           end
       end
end
function h = myhessian(fun,c,varargin)
       del = 1e-6;
       h = zeros(numel(c));

       for i=1:numel(c)
           h_tmp = ones(1,numel(c));
           parfor j=1:i
           ca = c; ca(i) = ca(i)+del; ca(j) = ca(j)+del;
           cb = c; cb(i) = cb(i)-del; cb(j) = cb(j)+del;
           cc = c; cc(i) = cc(i)+del; cc(j) = cc(j)-del;
           cd = c; cd(i) = cd(i)-del; cd(j) = cd(j)-del;

           h_tmp(j) = (feval(fun,ca,varargin{:})+feval(fun,cd,varargin{:})-feval(fun,cb,varargin{:})-feval(fun,cc,varargin{:}))/(4*del^2);

           end
           h(i,:)=h_tmp;

       end
       h = h .* ((ones(numel(c))-eye(numel(c))).*h'+eye(numel(c)));
end
function hf = myhessian2(f,x0,varargin)
       %%variables

       epsilon = 1e-5; % delta
       l_x0=length(x0); % length of x0;

       for i=1:l_x0
           x1 = x0;
           x1(i) = x0(i) - epsilon ;
           df1 = NumJacob(f, x1,varargin{:});

           x2 = x0;
           x2(i) = x0(i) + epsilon ;
           df2 = NumJacob(f, x2,varargin{:});

           d2f = (df2-df1) / (2*epsilon );

           hf(i,:) = d2f';
       end
end