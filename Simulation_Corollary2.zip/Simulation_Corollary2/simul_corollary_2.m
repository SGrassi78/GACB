% ----------------------------------------------------------------------- %
%           This reproduces simulations 
% S1: Truncation in the 2$^{\text{nd}}$ block covariance targeting estimator.
% ----------------------------------------------------------------------- %
vcT = 100000;
nsim = 1;
method = 1;
iRept = 1;
iNrFactors = 1;
iNrReturns = 2;
betatargeting = 0;
acf=250;

mSigma_f = [1];
mSigma_r_f = [1 0.5; 0.5 1];
mBeta_UncOLS = [0.5; 0.5];
mSigma_rf = [eye(iNrFactors) zeros(iNrFactors,iNrReturns);mBeta_UncOLS eye(iNrReturns)]*[mSigma_f zeros(iNrFactors,iNrReturns);...
    zeros(iNrReturns,iNrFactors) mSigma_r_f]*[eye(iNrFactors) zeros(iNrFactors,iNrReturns);mBeta_UncOLS eye(iNrReturns)]';

omg = [0.04; 0.04];
gma = [0.93; 0.93];

vSigma_r_f=reshape(chol(mSigma_r_f)',iNrReturns^2,1);
vSigma_r_f=vSigma_r_f(vSigma_r_f~=0);

vPar_EstFS = [0.04; 0.93];
vPar_EstSS = [mBeta_UncOLS(:); vSigma_r_f; vPar_EstFS; omg(:); gma(:)];

vPar0 = [vPar_EstFS; vPar_EstSS];
% -------------------------------------------------------- %
%            Put the parameters and start the sim
% -------------------------------------------------------- %
% ------------ Set the parameters ---------------- %
% -- MGarch parameters 1step-- %
mV0 = mSigma_f(1:iNrFactors, 1:iNrFactors);
A_1 = vPar_EstFS(1);
B_1 = vPar_EstFS(2);

iIdx__ = iNrFactors * iNrReturns + iNrReturns*(iNrReturns+1)/2;

% -- MGarch parameters 2step-- %
C0 = mSigma_r_f(1:iNrReturns, 1:iNrReturns);
A_2 = vPar_EstSS(iIdx__ + 1);
B_2 = vPar_EstSS(iIdx__ + 2);
% -------- Beta parameters ------- %
mBeta_Unc = reshape(vPar_EstSS(1:iNrFactors * iNrReturns, 1), iNrReturns, iNrFactors);
mOmega = reshape(vPar_EstSS(iIdx__ + 3:iIdx__ + 3 + iNrReturns * iNrFactors - 1), iNrReturns, iNrFactors);
mGamma = reshape(vPar_EstSS(iIdx__ + 3 + iNrReturns * iNrFactors:iIdx__+ 3 + (iNrReturns * 2 * iNrFactors) - 1), iNrReturns, iNrFactors);
mPsi = mBeta_Unc .*(ones(iNrReturns, iNrFactors) - mGamma);
dDrop = 0;
% ------------------------------------------------------- %
%                Start the Monte Carlo loop
% ------------------------------------------------------- %
C = clock;
fprintf([num2str(C(2)) '/' num2str(C(3)) ' - ' num2str(C(4)) ':' num2str(C(5)), '\n'])
results = zeros(nsim,20);    
counter_set(nsim,1);
A = zeros(nsim,iNrReturns^2);
ns=1;
    counter_progress(nsim,ns);
        
    cT = max(vcT);
    v1 = zeros(cT + dDrop, iNrFactors);
    mH_v1 = mV0;
    eta1 = zeros(cT + dDrop, iNrFactors);
    
    v2 = zeros(cT + dDrop, iNrReturns);
    mH_v2 = C0;
    eta2 = zeros(cT + dDrop, iNrReturns);
    
    e2 = zeros(cT + dDrop, iNrReturns);
    mBeta_t = mBeta_Unc;
    mu = ((mBeta_t * v1(1, :)'))';
    
    bt = zeros(cT + dDrop, iNrReturns*iNrFactors);
    bt(1,:) = reshape(mBeta_t, 1, iNrReturns*iNrFactors);
   
    for tt = 2:cT + dDrop
        
        mH_v1 = mV0 * (1 - A_1 - B_1) + A_1 * (v1(tt - 1, :)'...
            * v1(tt - 1, :)) + B_1 * mH_v1 ; 
        [ve, va] = eig(mH_v1);
        v1(tt, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrFactors, 1))';
        eta1(tt, :) = v1(tt, :)./sqrt(diag(mH_v1)');  
        
        mH_v2 = C0 * (1 - A_2 - B_2) + A_2 * (v2(tt - 1, :)'...
            * v2(tt - 1, :)) + B_2 * mH_v2 ; 
        [ve, va] = eig(mH_v2);
        v2(tt, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrReturns, 1))';
        eta2(tt, :) = v2(tt, :)./sqrt(diag(mH_v2)');  
            
        mBeta_t = mPsi + (mOmega .* ((eta2(tt - 1,:)') ...
            * eta1(tt - 1, :))) + (mGamma .* mBeta_t); 

        e2(tt, :) = ((mBeta_t * v1(tt, :)'))' + v2(tt, :);
        bt(tt,:) = reshape(mBeta_t, 1, iNrReturns*iNrFactors);
    end
   
   %-----------------------------------------------------------------------
   n=2; k=1;
   
    V = zeros(size(v1,1),iNrFactors^2);
    E = zeros(size(v1,1),iNrFactors^2);
    E2 = zeros(size(v1,1),iNrReturns^2);
    idx = 1;
    for i = 1:iNrFactors
       for j = 1:iNrFactors
          V(:,idx) = v1(:,i).*v1(:,j);
          E(:,idx) = eta1(:,i).*eta1(:,j);
          idx = idx+1;
       end
    end
    
    idx = 1;
    for i = 1:iNrReturns
       for j = 1:iNrReturns
          E2(:,idx) = eta2(:,i).*eta2(:,j);
          idx = idx+1;
       end
    end
    
    R = zeros(1,iNrFactors^2);
    RE = zeros(1,iNrFactors^2);
    for i = 1:acf
       R(i,:) = mean(V(acf+1:end,:).*V(acf+1-i:end-i,:),1);
       RE(i,:) = mean(V(acf+1:end,:).*E(acf+1-i:end-i,:),1);
    end   
   
    
    A_cal_s = zeros(acf,iNrReturns^2);
      for i=1:acf
          mR = reshape(R(i,:),iNrFactors,iNrFactors);
          A_s = mOmega.*(mGamma.^(i-1));
          A_cal_s_tmp = zeros(iNrReturns,iNrReturns);
          for s=1:iNrReturns
             for j=1:iNrReturns
                 A_cal_s_tmp(s,j) = A_s(s,:)*mR*A_s(j,:)';
             end
          end
          A_cal_s(i,:) = reshape(A_cal_s_tmp,1,iNrReturns^2);
      end
      A_cal = ones(iNrReturns,iNrReturns)+reshape(sum(A_cal_s),iNrReturns,iNrReturns);    
      A(ns,:) = A_cal(:)';
      
%check      
mBeta_UncOLS*mSigma_f*mBeta_UncOLS'+A_cal.*C0
cov(e2)      

      %this is for beta driven by xi
      A2_cal_s = zeros(acf,iNrReturns^2);
      for i=1:acf
          mRE = reshape(RE(i,:),iNrFactors,iNrFactors);
          A2_s = mOmega.*(mGamma.^(i-1));
          A2_cal_s_tmp = zeros(iNrReturns,iNrReturns);
          for s=1:iNrReturns
             for j=1:iNrReturns
                 A2_cal_s_tmp(s,j) = A2_s(s,:)*mRE*A2_s(j,:)';
             end
          end
          A2_cal_s(i,:) = reshape(A2_cal_s_tmp,1,iNrReturns^2);
      end
      
%check      
C0+mBeta_UncOLS*mSigma_f*mBeta_UncOLS'+reshape(sum(A2_cal_s),2,2).*reshape(mean(E2),2,2)
cov(e2)        

%end
counter_close(1);

e4 = 3*(0.05^2*(1-0.05-0.9)+2*0.05*(0.05*0.9+0.05*0.05))/(0.05*(1-0.9^2-3*0.05^2-2*0.05*0.9));
sig_eta = (e4-0.05^2/0.05^2)*(1-0.95^2)/(1-2*0.95*0.9+0.9^2);
k = (1-2*0.05*0.9-0.9^2)/(1-0.95^2)-0.9/0.95;

R_new = 0;
As_new =0;
for i=1:250
    R_new(i,1) = 0.95^i*sig_eta*k+1;
    As_new(i,1) = R_new(i,1)*0.05^2.*(0.9.^(2*(i-1)));
end

%%%%%%%%%%%%%%%%%%%%%%% THIS IS THE EXAMPLE IN THE PAPER %%%%%%%%%%%%%%%%%
omega = [0.04 0.02 0.01];
gamma = [0.93 0.96 0.985];
tau = omega;
delta = gamma;
A_cal_new = zeros(1,3);
R_new = zeros(250,3);
As_new = zeros(250,3);
A_sum = zeros(250,3);

for j=1:3
    mu2=1;
    mu4=3*mu2^2*(1-(tau(j)+delta(j))^2)/(1-delta(j)^2-3*tau(j)^2-2*tau(j)*delta(j));
    kappa=tau(j)*(1-delta(j)*(tau(j)+delta(j)))/((1-2*tau(j)*delta(j)-delta(j)^2)*(tau(j)+delta(j)));

    for i=1:250
        R_new(i,j) = ((tau(j)+delta(j))^i)*(mu4-mu2^2)*kappa+mu2^2;
        As_new(i,j) = R_new(i,j)*omega(j)^2.*(gamma(j).^(2*(i-1)));
    end    

    A_cal_new(1,j) = 1+omega(j)^2*(((tau(j)+delta(j))*(mu4-mu2^2)*kappa)/(1-gamma(j)^2*(tau(j)+delta(j)))+mu2/(1-gamma(j)^2));

    Amat = lagmatrix(As_new(:,j),0:249);
    Amat(isnan(Amat)) = 0;
    A_sum(:,j) = 1+sum(Amat,2);
end

%1+sum(As_new)
figure(1)
plot(R_new)
figure(2)
plot(As_new)
figure(3)
plot([A_sum ones(250,1)*A_cal_new])