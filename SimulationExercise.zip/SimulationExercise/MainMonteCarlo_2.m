% ----------------------------------------------------------------------- %
%                 Main file of the simulation 
% ----------------------------------------------------------------------- %
clear; clc;
iRept = 1;
vT = [6000]; %, 3000];
% sc = RandStream('CombRecursive', 'NormalTransform','Inversion','Seed', 999);
% RandStream.setGlobalStream(sc)
% 
% sc = RandStream('CombRecursive', 'NormalTransform','Inversion','Seed', 1234);
% RandStream.setGlobalStream(sc)
% ----------------------------------------------------------------------- %
%                 Setting the parameters
% ----------------------------------------------------------------------- %
iNrFactors = 1;
iNrReturns = 1;
betatargeting = 1;
% ---------------------------------------------------------------- %
%           Call the simulation function of the model 
% ---------------------------------------------------------------- %
warning off
iT = size(vT, 2);
mMatrixBias = zeros(iT, 7, 3);
mMatrixMSE = zeros(iT, 7, 3);
iDesign_AR = 1;
for t = 1:iT
    iIdx = 1;
    t
    % ------------------------------------------------------------------- %
    %               Simulate the GACB with three different design 
    % ------------------------------------------------------------------- %
    iGarch = 1;
     for iDesign_GACB = 1:3
       [strGACB, strDCC, strAR, strBEKK] = fMonteCarloSettings(iDesign_GACB, iDesign_AR, iNrReturns, iNrFactors);
       [Out_Bias, Out_Rmse] = fMonteCarlo(vT(t), iRept, iNrFactors, iNrReturns, betatargeting, iGarch, strGACB, strDCC, strAR, strBEKK);
       mMatrixBias(t, iIdx, :) = Out_Bias;
       mMatrixMSE(t, iIdx, :) = Out_Rmse;
        iIdx = iIdx + 1;
     end
    % ------------------------------------------------------------------- %
    %                              Simulate DCC 
    % ------------------------------------------------------------------- %
    iGarch = 2;
    % [strGACB, strDCC, strAR, strBEKK] = fMonteCarloSettings(iDesign_GACB, iDesign_AR, iNrReturns, iNrFactors);
    % [Out_Bias, Out_Rmse] = fMonteCarlo(vT(t), iRept, iNrFactors, iNrReturns, betatargeting, iGarch, strGACB, strDCC, strAR, strBEKK);
    % mMatrixBias(t, iIdx, :) = Out_Bias;
    % mMatrixMSE(t, iIdx, :) = Out_Rmse;
    iIdx = iIdx + 1;
    % ------------------------------------------------------------------- %
    %                     Simulate AR with two settings 
    % ------------------------------------------------------------------- %
    iGarch = 3;
    % for iDesign_AR =1:1
    %     [strGACB, strDCC, strAR, strBEKK] = fMonteCarloSettings(iDesign_GACB, iDesign_AR, iNrReturns, iNrFactors);
    %     [Out_Bias, Out_Rmse] = fMonteCarlo(vT(t), iRept, iNrFactors, iNrReturns, ...
    %         betatargeting, iGarch, strGACB, strDCC, strAR, strBEKK);
    %     mMatrixBias(t, iIdx, :) = Out_Bias;
    %     mMatrixMSE(t, iIdx, :) = Out_Rmse;
    %     iIdx = iIdx + 1;
    % end
    % ------------------------------------------------------------------- %
    %                             Simulate BEKK 
    % ------------------------------------------------------------------- %
    iGarch = 4;
    [strGACB, strDCC, strAR, strBEKK] = fMonteCarloSettings(iDesign_GACB, iDesign_AR, iNrReturns, iNrFactors);
    [Out_Bias, Out_Rmse] = fMonteCarlo(vT(t), iRept, iNrFactors, iNrReturns, ...
        betatargeting, iGarch, strGACB, strDCC, strAR, strBEKK);
    mMatrixBias(t, end, :) = Out_Bias;
    mMatrixMSE(t, end, :) = Out_Rmse;
    save Results_200.mat
end
save Results_250.mat
% ----------------------------------------------------------------------- %
%                        Analyzing the results 
% ----------------------------------------------------------------------- %
mBias_t = zeros(iT, 7);
mMSE_t = zeros(iT, 7);
for t = 1:iT
    temp = real(squeeze(mMatrixBias(t, :, :)));
    mBias_t(t, :) = temp(:, 2)./temp(:, 1);
    temp_ = real(squeeze(mMatrixMSE(t, :, :)));
    mMSE_t(t, :) = temp_(:, 2)./temp_(:, 1); 
    display('  ');
    display('=======================================================');
    display('** Results of the models DCC/GACB  **');
    headings      = [{'GACB1'}, {'GACB2'}, {'GACB3'}, {'DCC'}, {'AR_1'}, {'AR_2'}, {'BEKK'}];              
    out = [headings; num2cell(mBias_t(t, :)); num2cell(mMSE_t(t, :))];
    disp(out)
    display('  ');
    display('=======================================================');
end

% ----------------------------------------------------------------------- %
%                        Print the results 
% ----------------------------------------------------------------------- %
mBias_t = zeros(iT, 7, 3);
mMSE_t = zeros(iT, 7, 3);
for t = 3:3
    temp = real(squeeze(mMatrixBias(t, :, :)));
    mBias_t(t, :, 1) = temp(:, 1);
    mBias_t(t, :, 2) = temp(:, 2);
    mBias_t(t, :, 3) = temp(:, 3);
    temp_ = real(squeeze(mMatrixMSE(t, :, :)));
    mMSE_t(t, :, 1) = temp_(:, 1);
    mMSE_t(t, :, 2) = temp_(:, 2);
    mMSE_t(t, :, 3) = temp_(:, 3);

    display('  ');
    display('=======================================================');
    display('** Results of the models DCC/GACB  **');
    headings      = [{'GACB1'}, {'GACB2'}, {'GACB3'}, {'DCC'}, {'AR_1'}, {'AR_2'}, {'BEKK'}];              
    out = [headings; num2cell(squeeze(mBias_t(t, :, 1))); num2cell(squeeze(mBias_t(t, :, 2)));...
        num2cell(squeeze(mBias_t(t, :, 3)));
        num2cell(squeeze(mMSE_t(t, :, 1))); num2cell(squeeze(mMSE_t(t, :, 2))); num2cell(squeeze(mMSE_t(t, :, 3)))];
    disp(out)
    display('  ');
    display('=======================================================');

end













