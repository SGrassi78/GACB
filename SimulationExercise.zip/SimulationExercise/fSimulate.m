% ----------------------------------------------------------------------- %
%               File for simulateing MGARCH  
% ----------------------------------------------------------------------- %
function [mReturns_Sim, mFactors_Sim,  mBeta_True, mBeta_start, mH_FS_start, mH_SS_start, mu_start] ...
    = fSimulate(iGarch, cT, iNrReturns, iNrFactors, strGACB, strDCC, strAR, strBEKK)
   
    dDrop = 100;
    % ------------------------------------------------------------------- %
    %                          Simulate the GACB                          %
    % ------------------------------------------------------------------- %
    if iGarch == 1
        % -- MGarch parameters 1step-- %
        mV0 = strGACB.mV0;
        A_1 = strGACB.A_1;
        B_1 = strGACB.B_1;
        C0 = strGACB.C0;
        A_2 = strGACB.A_2;
        B_2 = strGACB.B_2;
        % -------- Beta parameters ------- %
        mBeta_Unc = strGACB.mBeta_Unc;
        mOmega = strGACB.mOmega;
        mGamma = strGACB.mGamma; 
        mPsi = strGACB.mPsi; 
        vOrtInn = zeros(cT + dDrop, iNrFactors);
        mEpsSim = zeros(cT + dDrop, iNrFactors);
        Factors_Sim = zeros(cT + dDrop, iNrFactors);
        mH_FS = zeros(iNrFactors, iNrFactors, cT + dDrop);
        mH_FS(:, :, 1) = mV0;
        for tt = 2:cT + dDrop
            mH_FS(:, :, tt) = mV0 * (1 - A_1 - B_1) + A_1 * (mEpsSim(tt - 1, :)'...
                 * mEpsSim(tt - 1, :)) + B_1 * mH_FS(:, :, tt - 1);
            [ve, va] = eig(mH_FS(:, :, tt));
            mEpsSim(tt, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrFactors, 1))';
            mFactors_Sim(tt, :) = mEpsSim(tt, :);
            vOrtInn(tt, :) = mEpsSim(tt, :);%./sqrt(diag(mH_FS(:, :, tt))');
        end
        % --------------------------------------------------- %
        %           Step 2 Simulate the Betas and Returns
        % --------------------------------------------------- %
        mReturns_Sim = zeros(cT + dDrop, iNrReturns);
        mBeta_t = zeros(iNrReturns, iNrFactors, cT + dDrop);
        mH_SS = zeros(iNrReturns, iNrReturns, cT + dDrop);
        mu = zeros(cT + dDrop, iNrReturns);
        mH_SS(:, :, 1) = C0;
        mBeta_t(:, :, 1) = mBeta_Unc;
        mu(1, :) = ((mBeta_t(:, :, 1) * mFactors_Sim(1, :)'))';
        mEpsSim_SS =  zeros(cT + dDrop, iNrReturns);
        for t = 2:cT + dDrop
            %mBeta_t(:, :, t) = mPsi + (mOmega .* ((mEpsSim_SS(t - 1,:)'./sqrt(diag(mH_SS(:, :, t-1)))) ...
            %      * vOrtInn(t-1, :))) + (mGamma .* mBeta_t(:, :, t - 1)); %13, 14 e 15 provare solo con 3 asse
            mBeta_t(:, :, t) = mPsi + (mOmega .* ((mEpsSim_SS(t - 1,:)') ...
                  * vOrtInn(t-1, :))) + (mGamma .* mBeta_t(:, :, t - 1)); %13, 14 e 15 provare solo con 3 asse

            mH_SS(:, :, t) = C0 * (1 - A_2 - B_2) + A_2 * ...
                 (mEpsSim_SS(t - 1, :)' * mEpsSim_SS(t - 1, :)) + B_2 * mH_SS(:, :, t - 1);
            mu(t, :) = ((mBeta_t(:, :, t) * mFactors_Sim(t, :)'))';
            [ve, va] = eig(mH_SS(:, :, t));
            mEpsSim_SS(t, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrReturns, 1))'; % Returns
            mReturns_Sim(t, :) = mu(t, :) + mEpsSim_SS(t, :);
        end
         mH_FS_start = mH_FS(:,:,dDrop + 1);
         mH_SS_start = mH_SS(:,:,dDrop + 1);
    % ------------------------------------------------------------------- %
    %                          Simulate the DCC                           %
    % ------------------------------------------------------------------- %
    elseif iGarch == 2
       alpha = strDCC.alpha;
       beta = strDCC.beta;
       A = strDCC.A;
       B = strDCC.B;
       mSigma_f = strDCC.mSigma_f;
       mSigma_r_f = strDCC.mSigma_r_f; 
       mBeta_UncOLS = strDCC.mBeta_UncOLS; 
       mTemp = [eye(iNrFactors), zeros(iNrFactors, iNrReturns); mBeta_UncOLS, eye(iNrReturns)];
       mUncVar = mTemp * blkdiag(mSigma_f, mSigma_r_f) * mTemp';
       mUncCorr = diag(sqrt(diag(mUncVar)))^-1 * mUncVar * diag(sqrt(diag(mUncVar)))^-1;
   
       mEpsSim = zeros(cT + dDrop, iNrFactors + iNrReturns);
       mFactors_Sim = zeros(cT + dDrop, iNrFactors);
       mH = zeros(iNrFactors+iNrReturns, iNrFactors+iNrReturns, cT + dDrop);
       mBeta_t = zeros(iNrReturns, iNrFactors, cT + dDrop);
       mS = zeros(iNrFactors+iNrReturns, iNrFactors+iNrReturns, cT + dDrop);
       mu = zeros(cT + dDrop, iNrReturns);
       mBeta_t(:, :, 1) = mBeta_UncOLS;
       mH(:, :, 1) = diag(diag(mUncVar));
       mS(:, :, 1) = mUncVar;
       mR(:, :, 1) = mUncCorr;
       mQ(:, :, 1) = mUncCorr;
       for tt = 2:cT + dDrop
           % --------------- Simulate de GARCEE ------------- %
           mH(:, :, tt) = diag((diag(mUncVar).* (1 - alpha - beta)) + alpha .* (mEpsSim(tt - 1, :)'...
                 .* mEpsSim(tt - 1, :)') + beta .* diag(mH(:, :, tt - 1)));
           % --------------- Simulate DCC   ----------------- %
           mQ(:, :, tt) = mUncCorr * (1 - A - B) + A * ...
               (1./(sqrt(diag(mH(:, :, tt - 1)))) .* mEpsSim(tt - 1, :)') * ...
               (1./(sqrt(diag(mH(:, :, tt - 1)))) .* mEpsSim(tt - 1, :)')'+ ...
               B * mQ(:, :, tt - 1);
           mR(:, :, tt) = diag(sqrt(diag(mQ(:, :, tt))))^-1 * mQ(:, :, tt) *  diag(sqrt(diag(mQ(:, :, tt))))^-1;
           mS(:, :, tt) = diag(sqrt(diag(mH(:, :, tt)))) * mR(:, :, tt) * diag(sqrt(diag(mH(:, :, tt))));
           [ve, va] = eig(mS(:, :, tt));
           mEpsSim(tt, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrFactors + iNrReturns, 1))';
           mFactors_Sim(tt, :) = mEpsSim(tt, 1:iNrFactors);
           mReturns_Sim(tt, :) = mEpsSim(tt, iNrFactors + 1:end);
           mBeta_t(:, :, tt) = mS(iNrFactors + 1:end, 1:iNrFactors, tt) * (inv(mS(1:iNrFactors, 1:iNrFactors, tt))); 
           mu(tt, :) = ((mBeta_t(:, :, tt) * mFactors_Sim(tt, :)'))';
       end
       mH_FS_start = mS(1:iNrFactors, 1:iNrFactors, dDrop + 1);
       mH_SS_start = mS(iNrFactors + 1:end,iNrFactors + 1:end, dDrop + 1) - mBeta_t(:,:, tt) * inv(mH_FS_start) * mBeta_t(:,:, tt)';
    % ------------------------------------------------------------------- %
    %                      Misspecified model                             % 
    % ------------------------------------------------------------------- %
    elseif iGarch == 3
        % -- MGarch parameters 1step-- %
        mV0 = strAR.mSigma_f;
        A_1 = strAR.A_1;
        B_1 = strAR.B_1;
        C0 = strAR.mSigma_r_f;
        A_2 = strAR.A_2;
        B_2 = strAR.B_2;
        % -------- Beta parameters ------- %
        mPsi = strAR.mBeta_UncOLS;   
        mPhi = strAR.Phi;
        mS = strAR.S; 
        mEpsSim = zeros(cT + dDrop, iNrFactors);
        mFactors_Sim = zeros(cT + dDrop, iNrFactors);
        mH_FS = zeros(iNrFactors, iNrFactors, cT + dDrop);
        mH_FS(:, :, 1) = mV0;
        for tt = 2:cT + dDrop
            mH_FS(:, :, tt) = mV0 * (1 - A_1 - B_1) + A_1 * (mEpsSim(tt - 1, :)'...
                 * mEpsSim(tt - 1, :)) + B_1 * mH_FS(:, :, tt - 1);
            [ve, va] = eig(mH_FS(:, :, tt));
            mEpsSim(tt, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrFactors, 1))';
            mFactors_Sim(tt, :) = mEpsSim(tt, :);
        end
        % --------------------------------------------------- %
        %           Step 2 Simulate the Betas and Returns
        % --------------------------------------------------- %
        mReturns_Sim = zeros(cT + dDrop, iNrReturns);
        mBeta_t = zeros(iNrReturns, iNrFactors, cT + dDrop);
        mH_SS = zeros(iNrReturns, iNrReturns, cT + dDrop);
        mu = zeros(cT + dDrop, iNrReturns);
        mH_SS(:, :, 1) = C0;
        mBeta_t(:, :, 1) = mPsi;
        mu(1, :) = ((mBeta_t(:, :, 1) * mFactors_Sim(1, :)'))';
        mEpsSim_SS =  zeros(cT + dDrop, iNrReturns);
        for t = 2:cT + dDrop
            mBeta_t(:, :, t) = mPsi .* (1 - mPhi) + mPhi .*  mBeta_t(:, :, t - 1) + (mS.*normrnd(0, 1, iNrReturns, iNrFactors));
            mu(t, :) = (( (mPsi .* (1 - mPhi) + mPhi .*  mBeta_t(:, :, t - 1) ) * mFactors_Sim(t, :)'))';          
            mH_SS(:, :, t) = C0 * (1 - A_2 - B_2) + A_2 * (mEpsSim_SS(t - 1, :)' * mEpsSim_SS(t - 1, :)) + B_2 * mH_SS(:, :, t - 1);
            [ve, va] = eig(mH_SS(:, :, t));
            mEpsSim_SS(t, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrReturns, 1))'; % Returns
            mReturns_Sim(t, :) = mu(t, :) + mEpsSim_SS(t, :);
        end
        mH_FS_start = mH_FS(:,:,dDrop + 1);
        mH_SS_start = mH_SS(:,:,dDrop + 1);
    % ------------------------------------------------------------------- %
    %                       BEKK model 
    % ------------------------------------------------------------------- %
    else
       alpha = strBEKK.alpha;
       beta = strBEKK.beta;
       mSigma_f = strBEKK.mSigma_f;
       mSigma_r_f = strBEKK.mSigma_r_f; 
       mBeta_UncOLS = strBEKK.mBeta_UncOLS; 
       mTemp = [eye(iNrFactors), zeros(iNrFactors, iNrReturns); mBeta_UncOLS, eye(iNrReturns)];
       mUncVar = mTemp * blkdiag(mSigma_f, mSigma_r_f) * mTemp';
       
       mEpsSim = zeros(cT + dDrop, iNrFactors + iNrReturns);
       mFactors_Sim = zeros(cT + dDrop, iNrFactors);
       mH = zeros(iNrFactors + iNrReturns, iNrFactors + iNrReturns, cT + dDrop);
       mBeta_t = zeros(iNrReturns, iNrFactors, cT + dDrop);
       mu = zeros(cT + dDrop, iNrReturns);
       mBeta_t(:, :, 1) = mBeta_UncOLS;
       mH(:, :, 1) = mUncVar;
  
       for tt = 2:cT + dDrop
           % ------------------- Simulate de GARCEE ------------------ %
           mH(:, :, tt) = ((mUncVar).* (1 - (alpha) - (beta))) + ((alpha ) .* (mEpsSim(tt - 1, :)'...
                 * mEpsSim(tt - 1, :))) + ((beta) .* (mH(:, :, tt - 1)));
           [ve, va] = eig(mH(:, :, tt));
           mEpsSim(tt, :) = ((ve * sqrt(va) * ve') * normrnd(0, 1, iNrFactors + iNrReturns, 1))';
           mFactors_Sim(tt, :) = mEpsSim(tt, 1:iNrFactors);
           mReturns_Sim(tt, :) = mEpsSim(tt, iNrFactors + 1:end);
           mBeta_t(:, :, tt) = mH(iNrFactors + 1:end, 1:iNrFactors, tt) * (inv(mH(1:iNrFactors, 1:iNrFactors, tt))); 
           mu(tt, :) = ((mBeta_t(:, :, tt) * mFactors_Sim(tt, :)'))';
       end
       mH_FS_start = mH(1:iNrFactors, 1:iNrFactors, dDrop + 1);
       mH_SS_start = mH(iNrFactors + 1:end,iNrFactors + 1:end, dDrop + 1) - mBeta_t(:,:, tt) * inv(mH_FS_start) * mBeta_t(:,:, tt)';
    end
    % ---  End simulation step --------------------------------------
    mReturns_Sim = mReturns_Sim(dDrop + 1:end, :);
    mFactors_Sim = mFactors_Sim(dDrop + 1:end, :);
    mBeta_start = mBeta_t(:, :, dDrop + 1);
    mBeta_True = mBeta_t(:, :, dDrop + 1:end);
    mu_start = mu(dDrop + 1,:);
end
