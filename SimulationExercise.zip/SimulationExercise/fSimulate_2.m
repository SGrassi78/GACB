% ----------------------------------------------------------------------- %
%             Function that simulates the Beta GARCH models
% ----------------------------------------------------------------------- %
function fSimulate_2(vcT, method, iRept, iNrFactors, iNrReturns, betatargeting, ind)

    mSigma_f = repmat(0.1,iNrFactors,iNrFactors)+diag(repmat(0.9,iNrFactors,1));
    mSigma_r_f = repmat(0.1,iNrReturns,iNrReturns)+diag(repmat(0.5,iNrReturns,1));
    mBeta_UncOLS = repmat(0.5,iNrReturns,iNrFactors);
    
    %omg = repmat(0.04,iNrReturns,iNrFactors);
    %gma = repmat(0.93,iNrReturns,iNrFactors);
    omg = repmat(0.005,iNrReturns,iNrFactors);
    gma = repmat(0.99,iNrReturns,iNrFactors);
    
    
    vSigma_r_f = reshape(chol(mSigma_r_f)',iNrReturns^2,1);
    vSigma_r_f = vSigma_r_f(vSigma_r_f~=0);
    
    vPar_EstFS = [0.04; 0.93];
    vPar_EstSS = [mBeta_UncOLS(:); vSigma_r_f; vPar_EstFS; omg(:); gma(:)];
    
    vPar0 = [vPar_EstFS; vPar_EstSS];
    
    % -------------------------------------------------------- %
    %            Put the parameters and start the sim
    % -------------------------------------------------------- %
    % ------------ Set the parameters ---------------- %
    
    % -- MGarch parameters 1step-- %
    mV0 = mSigma_f(1:iNrFactors, 1:iNrFactors);
    A_1 = vPar_EstFS(1);
    B_1 = vPar_EstFS(2);
    
    iIdx__ = iNrFactors * iNrReturns + iNrReturns*(iNrReturns+1)/2;
    
    % -- MGarch parameters 2step-- %
    C0 = mSigma_r_f(1:iNrReturns, 1:iNrReturns);
    A_2 = vPar_EstSS(iIdx__ + 1);
    B_2 = vPar_EstSS(iIdx__ + 2);
    
    % -------- Beta parameters ------- %
    mBeta_Unc = reshape(vPar_EstSS(1:iNrFactors * iNrReturns, 1), iNrReturns, iNrFactors);
    mOmega = reshape(vPar_EstSS(iIdx__ + 3:iIdx__ + 3 + iNrReturns * iNrFactors - 1), iNrReturns, iNrFactors);
    mGamma = reshape(vPar_EstSS(iIdx__ + 3 + iNrReturns * iNrFactors:iIdx__+ 3 + (iNrReturns * 2 * iNrFactors) - 1), iNrReturns, iNrFactors);
    mPsi = mBeta_Unc .*(ones(iNrReturns, iNrFactors) - mGamma); 
    % ------------------------------------------------------- %
    %                Start the Monte Carlo loop
    % ------------------------------------------------------- %
    vSigma_f = reshape(tril(mSigma_f), iNrFactors^2,1);
    vSigma_f(vSigma_f==0) = [];
    vSigma_r_f=reshape(tril(mSigma_r_f)',iNrReturns^2,1);
    vSigma_r_f=vSigma_r_f(vSigma_r_f~=0);
    
    mParSim = [];
    mMatrixBetaOLS = [];
    size_par = zeros(1,size(method,1));
    Par0 = [vSigma_f; vPar_EstFS; mBeta_UncOLS(:); vSigma_r_f(:); vPar_EstFS; omg(:); gma(:)]';
    size_par = size(Par0,2);
    mParSim = [mParSim, [Par0; zeros(iRept, iNrFactors*(iNrFactors+1)/2 + size(vPar_EstFS, 1) +  size(vPar_EstSS, 1))]];
    mMatrixBetaOLS = [mMatrixBetaOLS, [mBeta_UncOLS(:)';zeros(iRept, iNrReturns * iNrFactors)]];
    
    for j = 1:iRept
        % --------------------------------------------------- %
        %           Step 1 Simulate the BEKK
        % --------------------------------------------------- %
        cT = max(vcT);
        [mY, mReturns_Sim, mFactors_Sim] = fSimulate(iGarch);
        % --------------------------------------------------- %
        %              Estimation step  
        % --------------------------------------------------- %
        % ---------------- GACB -------------- %
        startparam = vPar0;
        mParSim_tmp = [];
        mMatrixBetaOLS_tmp = [];
        [vPar, mBeta_OLS, mSigma_f_est, ~, mBeta_t_GACB] = fEstimateMC_2...
                    (mReturns_Sim(1:vcT,:), mFactors_Sim(1:vcT,:), method, startparam, betatargeting, mBeta_start, mH_FS_start, mH_SS_start, mu_start);

        plot(squeeze(mBeta_t(1,:,120:end)))
        hold on
        plot(squeeze(mBeta_t_GACB(1,:,20:end)))
        
        % -------------- DCC ------------------ %
        mUncCorr = corr([mFactors_Sim(1:vcT,:) mReturns_Sim(1:vcT,:)]);
        FOR_StartVal.H_0 = [];
        FOR_StartVal.Q_0 = [];
        FOR_StartVal.MUf_0 = [];
        FOR_StartVal.MUr_0 = [];   
         [mBeta_t_DCC, S_22, H, Q, xi, fval, exitflag, Mx, My, eps, eta2, table, VCV] ...
            = fEstimateDCC(mReturns_Sim(1:vcT,:), mFactors_Sim(1:vcT,:), 1, 0, [], 1, mUncCorr, FOR_StartVal);
         plot(squeeze(mBeta_t_DCC(1,:,120:end)))

        vSigma_f_est = reshape(tril(mSigma_f_est), iNrFactors^2,1);
        vSigma_f_est(vSigma_f_est==0) = [];
                
        if betatargeting == 1
           mParSim_tmp = [mParSim_tmp; [vSigma_f_est(:); vPar(1:2); mBeta_OLS(:); vPar(3:end)]];
        elseif betatargeting == 0
           mParSim_tmp = [mParSim_tmp; [vSigma_f_est(:); vPar(1:end)]];
        end
        mMatrixBetaOLS_tmp = [mMatrixBetaOLS_tmp; mBeta_OLS(:)];
    end
    mParSim(j+1,:) = mParSim_tmp';
    mMatrixBetaOLS(j+1,:) = mMatrixBetaOLS_tmp';
   
    idx__ = 0;
    idx___ = 1;
    for s = 1:size(vcT, 1)
        for m = 1: size(method,1)
            idx_ = idx__+1;
            idx__ = idx__+size_par(m);
            aParSim{s,m} = mParSim(:,idx_:idx__);      
            aMatrixBetaOLS{s,m} = mMatrixBetaOLS(:,iNrReturns*iNrFactors*(idx___-1)+1:iNrReturns*iNrFactors*idx___);
            idx___ = idx___+1;
        end
    end
    
%    save(strcat('W:\FV_Documents\SorgentiFrancesco\MonteCarlo_Simulations\Simul_7_10_2021\Simul_methods_devolinno\simul_paper_revision_jbes\Simulation_', ...
%        '_NrRep_', num2str(iRept), '_BTarget_', num2str(betatargeting),'_ALLMLEMethods_',num2str(ind),'.mat'));
end