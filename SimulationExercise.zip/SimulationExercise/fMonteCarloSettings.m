% ----------------------------------------------------------------------- %
%           Setting the monte carlo 
% ----------------------------------------------------------------------- %
function [strGACB, strDCC, strAR, strBEKK] = fMonteCarloSettings(iDesign_GACB, iDesign_AR, iNrReturns, iNrFactors)

     
     if iDesign_GACB == 1 % Piatto
        strGACB.mOmega = repmat(0.003, iNrReturns, iNrFactors);
        strGACB.mGamma = repmat(0.995, iNrReturns, iNrFactors);
     elseif iDesign_GACB == 2  % Medio 
        strGACB.mOmega = repmat(0.01, iNrReturns, iNrFactors);
        strGACB.mGamma = repmat(0.98, iNrReturns, iNrFactors);
     elseif iDesign_GACB == 3 % Variabile
        strGACB.mOmega = repmat(0.03, iNrReturns, iNrFactors);
        strGACB.mGamma = repmat(0.96, iNrReturns, iNrFactors);
     end
     mSigma_f = repmat(0.1, iNrFactors, iNrFactors) + diag(repmat(0.9,iNrFactors,1));
     mSigma_r_f = repmat(0.1,iNrReturns,iNrReturns) + diag(repmat(0.5,iNrReturns,1));
     mBeta_UncOLS = repmat(0.5, iNrReturns, iNrFactors);
     % -------------------------------------------------------- %
     %            Put the parameters and start the sim
     % -------------------------------------------------------- %
     % ------------ Set the parameters for GACB ---------------- %
     % -- MGarch parameters 1step-- %
     strGACB.mV0 = mSigma_f(1:iNrFactors, 1:iNrFactors);
     strGACB.A_1 = 0.04;
     strGACB.B_1 = 0.93;
     % -- MGarch parameters 2step-- %
     strGACB.C0 = mSigma_r_f(1:iNrReturns, 1:iNrReturns);
     strGACB.A_2 = 0.04;
     strGACB.B_2 = 0.93;
     % -------- Beta parameters ------- %
     strGACB.mBeta_Unc = mBeta_UncOLS;
     strGACB.mPsi = strGACB.mBeta_Unc .*(ones(iNrReturns, iNrFactors) - strGACB.mGamma); 
     % ------------------------------------------------------------------ %
     %                    Set the parameters for DCC                      %
     % ------------------------------------------------------------------ %
     strDCC.alpha = repmat(0.04, iNrReturns + iNrFactors, 1);
     strDCC.beta =  repmat(0.93, iNrReturns + iNrFactors, 1);
     strDCC.A = 0.04;
     strDCC.B = 0.93;
     strDCC.mSigma_f = repmat(0.1, iNrFactors, iNrFactors)+diag(repmat(0.9,iNrFactors,1));
     strDCC.mSigma_r_f = repmat(0.1, iNrReturns, iNrReturns)+diag(repmat(0.5,iNrReturns,1));
     strDCC.mBeta_UncOLS = repmat(0.5, iNrReturns, iNrFactors);
     % ------------------------------------------------------------------ %
     %                      Set the AR simulation 
     % ------------------------------------------------------------------ %
     strAR.Phi = repmat(0.98, iNrReturns, iNrFactors);  
     strAR.A_1 = 0.04;
     strAR.B_1 = 0.93;
     strAR.A_2 = 0.04;
     strAR.B_2 = 0.93;
     strAR.mSigma_f = repmat(0.1, iNrFactors, iNrFactors)+diag(repmat(0.9,iNrFactors,1));
     strAR.mSigma_r_f = repmat(0.1, iNrReturns, iNrReturns)+diag(repmat(0.5,iNrReturns,1));
     strAR.mBeta_UncOLS = repmat(0.5, iNrReturns, iNrFactors);
     if (iDesign_AR  == 1)
        strAR.S = repmat(0.002, iNrReturns, iNrFactors); 
     else
        strAR.S = repmat(0.05, iNrReturns, iNrFactors);  
     end
     % ------------------------------------------------------------------ %
     %                     BEKK simulation
     % ------------------------------------------------------------------ %
     strBEKK.alpha = repmat((0.04), iNrReturns + iNrFactors, 1);
     strBEKK.beta =  repmat((0.93), iNrReturns + iNrFactors, 1);
     strBEKK.mSigma_f = repmat(0.1, iNrFactors, iNrFactors) + diag(repmat(0.9,iNrFactors,1));
     strBEKK.mSigma_r_f = repmat(0.1, iNrReturns, iNrReturns) + diag(repmat(0.5,iNrReturns,1));
     strBEKK.mBeta_UncOLS = repmat(0.5, iNrReturns, iNrFactors);
end