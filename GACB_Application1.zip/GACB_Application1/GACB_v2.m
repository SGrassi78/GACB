% ----------------------------------------------------------------------- %
%  Program that estimates and forecast the: OLS-GARCH, H-GACB, R-GACB
%                                           F-GACB and S-GACB   
%  where the Beta process is driven by nondevolatilized innovations
%                               or  by devolatilized innovations
% this program requires the mfe-toolbox-main of Kevin Sheppard available
% at https://www.mathworks.com/matlabcentral/fileexchange/170381-mfe-toolbox-kevin-sheppard
% ----------------------------------------------------------------------- %
clear all;
clc;
% ----------------------------------------------------------------------- %
%      Load here the data for your experiment 
%      The data used in the paper are available at 
%      https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html)
% ----------------------------------------------------------------------- %
mFactors = []; % Here load your factors
mReturns = []; % Here load your returns 
% ----------------------------------------------------------------------- %
%                      Management of the program 
% ----------------------------------------------------------------------- %
iSel = 4; % This is the model speciation 0 OLS 1) H-GACB 2) R-GACB not in paper
          % 3) F-GACB 4) S-GACB
stdized = 0; % 0) Nondevolatilized innovations 1) Devolatilized innovations
beta_tgt = 1; % 1) To impose Beta targeting 
cstr_gamma = 0; % 1) To constrain smoothing parameters to be common for all betas 
one_by_one = 0; % 1) To estimate the model equation by equation (only for iSel = 0 and iSel = 1)
[cT, cN] = size(mReturns);
cK = 3;   % Number of factors 
gap = 22; % Interval between estimation 
t1 = 20254; % Start date of the out of sample forecast
iEstimationSize = 6000; % Size of the estimation sample
t0 = t1 - iEstimationSize + 1; % Start date of the estimation sample
% ----------------------------------------------------------------------- %
iStep = length(t1:gap:cT - gap);
Hedge = zeros(iStep, gap, cN+1);
TrackErr = zeros(iStep, gap, cN+1);
Bfor = zeros(iStep, gap, cN*cK+1);
Hfor = zeros(iStep, gap, cN, cN);
vExit = zeros(iStep, 1); 
T_ = 1;
count = 0;
for t_1 = t1:gap:cT - gap
    fprintf(['iter: '  num2str(T_) ' [\n'])
    mR = mReturns(t0:t_1 + gap, :);
    mF = mFactors(t0:t_1+gap, 1:cK);
    % --------------------------------------------------------------- %
    %                      Estimation part
    % --------------------------------------------------------------- %
    if one_by_one == 1 && (iSel == 1 || iSel == 0)
        Beta_FOR = zeros(cN, cK, gap);
        for k = 1:cN
            fprintf(['\b' 'series: ' num2str(k) '\n'])
            if T_ == 1
                [Beta_t, ~, ~, H2nd_t, ~, ~, exitflag, ~, ~, table, ~] ...
                    = fEstimateGACB_2(mR(:, k), mF, iSel, stdized, 0, [], beta_tgt, cstr_gamma, gap);
            else
                [Beta_t, ~, ~, H2nd_t, ~, ~, exitflag, ~, ~, table, ~] ...
                    = fEstimateGACB_2(mR(:, k), mF, iSel, stdized, 0, startparam(k,:,T_-1), beta_tgt, cstr_gamma, gap);
            end
            startparam(k,:,T_) = table;
            Beta_FOR(k, :, :) = Beta_t(:, :, end-gap+1:end);
            H_2ndFOR(k, k, :) = H2nd_t(:, :, end-gap+1:end);
        end
    else
        if T_ == 1
              [Beta_t, ~, ~, H2nd_t, ~, ~, exitflag, ~, ~, table, ~] ...
                    = fEstimateGACB_2(mR, mF, iSel, stdized, 0, [], beta_tgt, cstr_gamma, gap);
        else
              [Beta_t, ~, ~, H2nd_t, ~, ~, exitflag, ~, ~, table, ~] ...
                    = fEstimateGACB_2(mR, mF, iSel, stdized, 0, [], beta_tgt, cstr_gamma, gap);
        end
        if max(max(max(abs(Beta_t(:,:, end-gap+1:end)))))>2
            disp([strcat('forecast explodes -> cst beta. Max beta = ', ...
                num2str(max(max(max(abs(Beta_t(:,:,end-gap+1:end)))))))])
            [Beta_t, ~, ~, H2nd_t, ~, ~, exitflag, ~, ~, table, ~] ...
                    = fEstimateGACB_2(mR, mF, 0, stdized, 0, [], beta_tgt, cstr_gamma, gap);
            table = [table; zeros(120, 1)];
        end
        startparam(T_, :) = table;      
        Beta_FOR = Beta_t(: , :, end-gap+1:end);
        H_2ndFOR = H2nd_t(:, :, end-gap+1:end);
    end

    mDateFOR = Date(t_1 + 1:t_1 + gap, 1);
    mFactorsFOR = mF(end - gap + 1:end, :);
    mReturnsFOR = mR(end - gap + 1:end, :);
    for k = 1:gap
        Hedge(T_, k, :) = [mDateFOR(k, :) (Beta_FOR(:,:,k) * mFactorsFOR(k,:)')'];
        TrackErr(T_, k, :) = [mDateFOR(k, :) mReturnsFOR(k,:) - squeeze(Hedge(T_, k, 2:end))'];
        Bfor(T_, k, :) = [mDateFOR(k, :) reshape(Beta_FOR(:,:,k), size(Beta_FOR, 1) * size(Beta_FOR, 2), 1)'];
        Hfor(T_, k, :, :) = [H_2ndFOR(:, :, k)];
    end
    t0 = t0 + gap;
    T_ = T_ + 1;   
end
% --------------------------------------------- %
%           Print and save your results here 
% --------------------------------------------- %
