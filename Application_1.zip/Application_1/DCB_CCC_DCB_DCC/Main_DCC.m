% ----------------------------------------------------------------------- %
%  Program that estimates and forecast the DCB-DCC and DCB-CCC 
% this program requires the mfe-toolbox-main of Kevin Sheppard available
% at https://www.mathworks.com/matlabcentral/fileexchange/170381-mfe-toolbox-kevin-sheppard
% ----------------------------------------------------------------------- %
clear all;
clc;
% ----------------------------------------------------------------------- %
%      Load here the data for your experiment 
%      The data used in the paper are available at 
%      https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html)
% ----------------------------------------------------------------------- %
mFactors = []; % Here load your factors
mReturns = []; % Here load your returns 
% ----------------------------------------------------------------------- %
%                      Management of the program 
% ----------------------------------------------------------------------- %
iSel = 0; % 0) DCB-CCC 1) DCB-DCC 
corrtargeting = 0;
[cT, cN] = size(mReturns);
gap = 22; % Interval between estimation 
t1 = 20254;  % Start date of the out of sample forecast
[~, iStep] = size(t1:gap:cT - gap);
mHedge = zeros(cN, iStep,  gap, 2);
mTrackError = zeros(cN, iStep, gap, 2);
mBfor = zeros(cN, iStep, gap, 4);
mHFor = zeros(cN, iStep, gap, 2);
mexitflag = zeros(cN, iStep, 4);
iEstimationSize = 6000; % Size of the estimation sample
t0 = t1 - iEstimationSize + 1; % Start date of the estimation sample
Hedge = zeros(iStep, gap, 6);
TrackErr = zeros(iStep, gap, 6);
Bfor = zeros(iStep, gap,16);
Hfor = zeros(iStep, gap, 5, 5);
vExit = zeros(iStep, 4);
T_ = 1;
if iSel==0
    startparam = zeros(249,60);
else
    startparam = zeros(249,62);
end
for t_1 = t1:gap:cT - gap 
    T_
    mR = mReturns(t0:t_1+gap, :);
    mF = mFactors(t0:t_1+gap, 1:3);
    mUncCorr = corr([mF(1:end-gap, :) mR(1:end-gap, :)]);
    [mBeta_t, S_22, H, Q, xi, fval, exitflag, firstorderopt, Mx, My, eps, eta2, table, ~] ...
               = fEstimateDCC_Forecast(mR, mF, ...
              iSel, [],  corrtargeting, mUncCorr, gap);

    Beta_FOR = mBeta_t(: , :, end-gap+1:end);
    S_22FOR = S_22(:, :, end-gap+1:end);
    startparam(T_, :) = table;                
     
     mDateFOR = Date(t_1 + 1:t_1 + gap, 1); 
     mFactorsFOR = mF(end - gap + 1:end, :);
     mReturnsFOR = mR(end - gap + 1:end, :);
     for k = 1:gap
         Hedge(T_, k, :) = [mDateFOR(k, :) (Beta_FOR(:,:,k) * mFactorsFOR(k,:)')'];
         TrackErr(T_, k, :) = [mDateFOR(k, :) mReturnsFOR(k,:) - squeeze(Hedge(T_, k, 2:end))'];
         Bfor(T_, k, :) = [mDateFOR(k, :) reshape(Beta_FOR(:,:,k), size(Beta_FOR, 1) * size(Beta_FOR, 2), 1)'];
         Hfor(T_, k, :, :) = [S_22FOR(:, :, k)];
     end
     % shift dates
     t0 = t0 + gap;
     T_ = T_ + 1;
end