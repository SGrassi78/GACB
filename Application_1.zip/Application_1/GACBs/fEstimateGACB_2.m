% ----------------------------------------------------------------------- %
%                Function that estimated the beta MGARCH
% ----------------------------------------------------------------------- %
function [mB, mu_R, mu_F, H_R, H_F, fval, exitflag, eps_1st_step, eps_2nd_step, table, mB_OLS] ...
    = fEstimateGACB_2(mR, mF, iSel, stdized, iFilter, user_param, beta_tgt, constr_gamma, gap)
    % ---------------------------------------------------------------- %
    %                        House keeping
    % ---------------------------------------------------------------- %
    options = optimset('Algorithm','interior-point', 'Display','off', ...
        'MaxFunEvals', 50000,'MaxIter', 50000, 'TolFun', 1e-5, 'TolX', 1e-6,...
        'LargeScale', 'on', 'UseParallel', true);
    
    warning off;

    cK = size(mF, 2); % number of factors  
    cN = size(mR, 2); % number of regressors
    cT = size(mR, 1) - gap; % lenght of the estimation sample
    % ---------------------------------------------------------------- %
    %              In sample unconditional S_rf, S_f, S_r|f and B
    % ---------------------------------------------------------------- %
    mSig_rf = cov([mF(1:cT,:) mR(1:cT,:)]); % in-sample covariance factors~returns
    mSig_f = mSig_rf(1:cK, 1:cK);  % in-sample variance of the factors
    mSig_r_f = mSig_rf(cK + 1:end, cK + 1:end) - ...
        mSig_rf(cK + 1:end, 1:cK) * (mSig_rf(1:cK, 1:cK)\mSig_rf(cK + 1:end, 1:cK)'); % in-sample variance of the returns conditional on the factors
    mB_OLS = mSig_rf(cK + 1:end, 1:cK)/(mSig_f); % in-sample OLS betas
    
    [startVals_1st_step, LB_1st_step, UB_1st_step, startVals_2nd_step, LB_2nd_step, UB_2nd_step] ...
        = set_default_parameters(iSel, mSig_r_f, mB_OLS, cN, cK, beta_tgt, constr_gamma);

    if ~isempty(user_param) && length(user_param) == size(startVals_2nd_step,1)+2
        if isrow(user_param)
            user_param = user_param'; % user provided parameters must be a column vecotor. Must include 1st step parameters even if stdized = 0 
        end
        startVals_1st_step  = user_param(1:2); 
        startVals_2nd_step = user_param(3:end);
    end
    % -------------------------- Estimation ------------------------------- %    
    if iFilter == 0
        % ------------------- 1st step estimation ------------------------- %
        if stdized == 1
            A = [1 1];
            b = 0.9999;
            [param_1st_step, ~, ~, ~, ~, ~, ~] = ...
                    fmincon(@scalar_bekk_likelihood, startVals_1st_step, A, b,...
                    [],[], LB_1st_step, UB_1st_step, [], options, mF, mSig_f, gap);
            [~, ~, mu_F, H_F, eps_1st_step, Res_1st_step] = scalar_bekk_likelihood(param_1st_step, mF, mSig_f, gap);
        elseif stdized == 0
            param_1st_step = zeros(2,1);
            H_F = mSig_f;
            mu_F = mean(mF(1:cT,:));
            eps_1st_step = mF - mean(mF(1:cT,:));
            Res_1st_step = mF - mean(mF(1:cT,:));
        end
        options = optimset('Algorithm','interior-point', 'Display','off', ...
        'MaxFunEvals', 50000,'MaxIter', 50000, 'TolFun', 1e-3, 'TolX', 1e-6,...
        'LargeScale', 'on', 'UseParallel', true);
        % -------------------- 2nd step estimation ----------------------- %
        if beta_tgt == 1
            A = [zeros(1, cN) 1 1 zeros(1, length(startVals_2nd_step) - cN - 2)];
        elseif beta_tgt == 0
            A = [zeros(1, cN * cK) zeros(1, cN) 1 1 zeros(1,length(startVals_2nd_step) - 2 - cK *cN - cN)];
        end
        b = 0.9999;
        [param_2nd_step, ~, exitflag, output, ~, ~, ~] = fmincon(@beta_garch_likelihood,...
                startVals_2nd_step, A, b, [], [], LB_2nd_step, UB_2nd_step, [], options, ...
                mR, mF, Res_1st_step, mB_OLS, mSig_r_f, iSel, stdized, beta_tgt, constr_gamma, gap);
        
        [fval, ~, mu_R, H_R, eps_2nd_step, mB] = beta_garch_likelihood(param_2nd_step, ...
                mR, mF, Res_1st_step, mB_OLS, mSig_r_f, iSel, stdized, beta_tgt, constr_gamma, gap);
       
        if output.firstorderopt>options.TolFun
           exitflag = output.firstorderopt;
        end
        table = [param_1st_step; param_2nd_step];
    
    % -------------------------- Filtering ------------------------------- %    
    elseif iFilter == 1
        % ------------------- 1st step filtering ------------------------- %
        if stdized == 1
            [~, ~, mu_F, H_F, eps_1st_step, Res_1st_step] = scalar_bekk_likelihood(startVals_1st_step, mF, mSig_f, gap);
        elseif stdized == 0
            H_F = mSig_f;
            mu_F = mean(mF(1:cT,:));
            eps_1st_step = mF - mean(mF(1:cT,:));
            Res_1st_step = mF - mean(mF(1:cT,:)); % center around the estimation sample mean
        end
        % ------------------- 2nd step filtering ------------------------- %
        [fval, ~, mu_R, H_R, eps_2nd_step, mB] = beta_garch_likelihood(startVals_2nd_step, ...
                mR, mF, Res_1st_step, mB_OLS, mSig_r_f, iSel, stdized, beta_tgt, constr_gamma);
        table = user_param;
        exitflag = -999;
    end     
end

% ------------------------------------------------------------------------- %

% ------------- Scalar BEKK likelihood for the factors  S_f --------------- %
function [ll, lls, mu_F, mH, eps, devol] = scalar_bekk_likelihood(vPar, mF, mSig_f, gap)
    
    cK = size(mF, 2); % number of factors  
    cT = size(mF, 1) - gap; % lenght of the estimation sample
    
    A = vPar(1);
    B = vPar(2);

    eps = zeros(cT + gap, cK);
    devol = zeros(cT + gap, cK);

    mH = repmat(mSig_f,[1,1,cT + gap]);
    mu_F = repmat(mean(mF(1:cT,:)), cT + gap, 1);
    eps(1, :) = mF(1, :) - mu_F(1, :);
    
    lls = zeros(cT+gap, 1);
    
    for i = 2:cT + gap
        mH(:, :, i) = mSig_f * (1 - A - B) + A * (eps(i - 1, :)' * eps(i - 1, :)) + B * mH(:, :, i - 1);
        eps(i, :) = mF(i, :) - mu_F(i, :);
        devol(i, :) = eps(i, :)./sqrt(diag(mH(:, :, i)))';
        lls(i) = -0.5 * (cK * log(2 * pi) + sum(log(diag(mH(:, :, i))) + (eps(i, :)'.^2)./ (diag(mH(:, :, i)))));
    end
    ll = -mean(lls(20:cT));
    if (isnan(ll) || ~isreal(ll) || isinf(ll))
        ll = 1e7;
    end
end
% ----------------------------------------------------------------------- %

function [ll, lls, mu_R, mH, eps, mB] = beta_garch_likelihood(vPar, ...
    mR, mF, Res_1st_step, mB_Unc, mSig_r_f, iSel, stdized, beta_tgt, constr_gamma, gap)

    cK = size(mF, 2); % number of factors  
    cN = size(mR, 2); % number of regressors
    cT = size(mR, 1) - gap; % lenght of the estimation sample
    [H0, cA, cB, mB_bar, mOmega, mGamma] = split_parameters_beta(vPar, mB_Unc, iSel, beta_tgt, constr_gamma, cN, cK);
    mH = repmat(mSig_r_f,[1, 1, cT + gap]);
    mB = repmat(mB_Unc, [1, 1, cT + gap]);
    mu_R = repmat(mean(mR(1:20, :)), cT + gap, 1);
    eps = repmat(mR(1, :) - mu_R(1,:), cT + gap, 1);
    lls = zeros(cT + gap, 1);
    % ---------------------------------------------------------------- %
    for i = 2:cT + gap
        if stdized == 1
            Xi_r = (eps(i - 1, :)' ./ sqrt(diag(mH(:, :, i - 1))));
            Xi_f = Res_1st_step(i - 1, :);   
        elseif stdized == 0
            Xi_r = eps(i - 1, :)';
            Xi_f = mF(i - 1, :) - mean(mF(1:cT,:));
        end
        mB(:, :, i) = fBetas(Xi_r, Xi_f, mB(:, :, i - 1), ...
                mB_bar .* (ones(cN, cK) - mGamma), mOmega, mGamma, cN, cK, iSel);
        
        mH(:, :, i) = H0 + cA * (eps(i - 1, :)' * eps(i - 1, :)) ...
                  + cB * mH(:, :, i - 1); 
           
        mu_R(i, :) = mean(mR(1:cT,:)) + (mF(i, :) - mean(mF(1:cT,:))) * mB(:, :, i)';
        eps(i, :) = mR(i, :) - mu_R(i, :);
        
        lls(i) = -0.5 * (cN * log(2 * pi) + sum(log(diag(mH(:, :, i))) + (eps(i, :)'.^2) ./ (diag(mH(:, :, i)))));
     end
     ll = -mean(lls(20:cT)); 
     if (isnan(ll) || ~isreal(ll) || isinf(ll))
         ll = 1e7;
     end
end
% ----------------------------------------------------------------------- %
%             Function that calculate different TV Betas
% ----------------------------------------------------------------------- %
function [mBeta_t] = fBetas(Xi_r, Xi_f, Beta_t1, mPsi, mOmega, mGamma, iNrReturs, iNrFactors, iSel)
   % -------------------------------------------------------------------- %
   %    B_t= \Gamma + (\Omega .*(\Xi_r_t*\Xi_f_t))+ (\Gamma.*B_t-1) Eq 13
   % -------------------------------------------------------------------- %
   if iSel == 0
       mBeta_t = mPsi;
   elseif iSel == 1   
       mBeta_t = mPsi + (mOmega .* (Xi_r * Xi_f)) + (mGamma .* Beta_t1);  
   % -------------------------------------------------------------------- %
   % B_t= \Psi + vec^-1[\Omega .*(\Xi_r_t Kron \Xi_f_t)+ \Gamma* Vec(B_t-1)
   % -------------------------------------------------------------------- %
   elseif iSel == 2 || iSel == 4 
       mBeta_t = mPsi + reshape(mOmega * kron(Xi_r, Xi_f'), iNrFactors, iNrReturs)' + (mGamma .* Beta_t1);
   % -------------------------------------------------------------------- %
   % B_t= \Psi + vec^-1[\Omega .*(\Xi_r_t Kron \Xi_f_t)+ \Gamma* Vec(B_t-1)]
   % -------------------------------------------------------------------- %       
   elseif iSel == 3
       mBeta_t = mPsi + reshape(mOmega * kron(Xi_f', Xi_r), iNrReturs, iNrFactors) + (mGamma .* Beta_t1);
   % -------------------------------------------------------------------- %
   % B_t= \Psi + vec^-1[\Omega .*(\Xi_f_t Kron \Xi_r_t)+ \Gamma* Vec(B_t-1)]'
   % -------------------------------------------------------------------- %              
   end
end
% ------------------------ Set starting values ---------------------------- %
function [startVals_1st_step, LB_1st_step, UB_1st_step, startVals_2nd_step, LB_2nd_step, UB_2nd_step] ...
    = set_default_parameters(iSel, mSig_r_f, mB_OLS, cN, cK, beta_tgt, constr_gamma)
    
    startVals_B_Unc = mB_OLS;
    LB_B_Unc = -10 * ones(cN * cK, 1);
    UB_B_Unc =  10 * ones(cN * cK, 1);
    
    startVals_Sig_r_f_Unc = diag(mSig_r_f)*0.001;
    LB_Sig_r_f_Unc = zeros(cN, 1); 
    UB_Sig_r_f_Unc = diag(mSig_r_f)*0.01; %10 * ones(cN, 1);   

    startVals_Mgarch = [0.04; 0.94];
    LB_Mgarch = [0; 0.8];
    UB_Mgarch = [0.1; 1];
   
    if iSel==0
        startVals_Omega = [];
        LB_Omega = [];
        UB_Omega = [];
    elseif iSel == 1
        startVals_Omega = 0.1.* ones(cN * cK, 1);
        LB_Omega =-0.9* ones(cK * cN, 1);
        UB_Omega = 0.9 * ones(cK * cN, 1);  
    elseif iSel == 2
        LB_Omega = [];
        UB_Omega = [];
        mTemp_LB = -1.0* ones(cK);
        mTemp_LB(logical(eye(size(mTemp_LB)))) = -0.5;
        mTemp_UB = 1.0* ones(cK);
        mTemp_UB(logical(eye(size(mTemp_LB)))) = 0.5;
        startVals_Omega = 0.01 .* ones(cN * cK^2, 1);
        for i = 1:cN
            LB_Omega = [LB_Omega; mTemp_LB(:)];
            UB_Omega = [UB_Omega; mTemp_UB(:)];
        end
        startVals_Omega = startVals_Omega .* (LB_Omega>=0);
    elseif iSel == 3
        LB_Omega = [];
        UB_Omega = [];
        mTemp_LB = -1.0 * ones(cN);
        mTemp_LB(logical(eye(size(mTemp_LB)))) = 0.0002;
        mTemp_UB = 1.0* ones(cN);
        mTemp_UB(logical(eye(size(mTemp_LB)))) = 0.5;
        startVals_Omega = 0.01 .* ones(cN^2 * cK, 1);
        for i = 1:cK
            LB_Omega = [LB_Omega; mTemp_LB(:)];
            UB_Omega = [UB_Omega; mTemp_UB(:)];
        end
        startVals_Omega = startVals_Omega .* (LB_Omega>=0);
    elseif iSel == 4    
        mTemp_LB = 0.01 *(-kron(eye(cN),ones(cK)) - kron(ones(cN),eye(cK))+eye(cK*cN));
        mTemp_LB(logical(eye(size(mTemp_LB)))) = -0.9; 
        mTemp_UB = 0.01 *(kron(eye(cN),ones(cK)) + kron(ones(cN),eye(cK))-eye(cK*cN));
        mTemp_UB(logical(eye(size(mTemp_LB)))) = 0.9;
        mTemp_idx = find(mTemp_UB~=0);
        LB_Omega = mTemp_LB(mTemp_idx);
        UB_Omega = mTemp_UB(mTemp_idx);
        startVals_Omega = 0.01 .* ones(size(mTemp_idx,1), 1);    
        startVals_Omega = startVals_Omega .* (UB_Omega==max(UB_Omega));   
    end
    if iSel==0
        startingVals_Gamma = [];
        LB_Gamma = [];
        UB_Gamma = [];
    else
        startingVals_Gamma = 0.985.* ones(cN, cK);
        mTemp = 0.980*ones(cN, cK);
        LB_Gamma = mTemp(:);
        mTemp = 0.9999.*ones(cN, cK);
        UB_Gamma = mTemp(:);    
        if constr_gamma==1
            startingVals_Gamma = 0.985;
            LB_Gamma = 0.985;
            UB_Gamma = 0.9999;
        end
    end

    startVals_1st_step = startVals_Mgarch;
    LB_1st_step = LB_Mgarch;
    UB_1st_step = UB_Mgarch;

    startVals_2nd_step = [startVals_B_Unc(:); startVals_Sig_r_f_Unc; startVals_Mgarch; ...
        startVals_Omega(:); startingVals_Gamma(:)];
    LB_2nd_step = [LB_B_Unc; LB_Sig_r_f_Unc; LB_Mgarch; LB_Omega; LB_Gamma];
    UB_2nd_step = [UB_B_Unc; UB_Sig_r_f_Unc; UB_Mgarch; UB_Omega; UB_Gamma];
    
    if beta_tgt == 1
        startVals_2nd_step(1:cK*cN) = [];
        LB_2nd_step(1:cK*cN) = [];
        UB_2nd_step(1:cK*cN) = [];
    end
end

function [H0, cA, cB, mB_bar, mOmega, mGamma] = split_parameters_beta(vPar, mB_Unc, iSel, beta_tgt, constr_gamma, cN, cK)
    % -- Unconditional beta and variance Parameters -- %
    iIdx__= 0;
    if beta_tgt == 1
        mB_bar = mB_Unc;
        iIdx__= cN;
        H0 = diag(vPar(1:iIdx__, 1));
    elseif beta_tgt == 0
        iIndx0__ = cK * cN;
        mB_bar = reshape(vPar(1:iIndx0__, 1), cN, cK);
        iIdx__ = cK * cN + cN; 
        H0 = diag(vPar(iIndx0__+1:iIdx__, 1));
    end
    % -- MGarch parameters -- %
    cA = vPar(iIdx__ + 1);
    cB = vPar(iIdx__ + 2);
    % -- Beta parameters -- %
    if iSel == 0
        mOmega = 0;
        mGamma = 0;
    else
        if iSel == 1
            % -------- mOmega ------- %
            iIdx_ = iIdx__ +  3;
            iIdx__ = iIdx__ + 3 + cN * cK - 1;
            mOmega = reshape(vPar(iIdx_:iIdx__ ), cN, cK);
        elseif iSel == 2
            mOmega = [];
            for i = 1:cN
                iIdx_ = (iIdx__ +  3 + (i - 1) * cK^2);
                iIdx___ = (iIdx__ + 3 + i * cK^2 - 1);
                mTemp = reshape(vPar(iIdx_:iIdx___), cK, cK);
                mOmega =  blkdiag(mOmega, mTemp);
            end
            iIdx__ = iIdx___;
        elseif iSel == 3
            mOmega = [];
            for i = 1:cK
                iIdx_ = (iIdx__ + 3 + (i - 1) * cN^2);
                iIdx___ = (iIdx__ + 3 + i * cN^2 - 1);
                mTemp = reshape(vPar(iIdx_:iIdx___), cN, cN);
                mOmega =  blkdiag(mOmega, mTemp);
            end
            iIdx__ = iIdx___;
        elseif iSel == 4    
            iIdx_ = iIdx__ +  3;
            iIdx___ = iIdx__ +  3 + (cK^2+cK*(cN-1))*cN - 1;
            mOmega = kron(eye(cN),ones(cK)) + kron(ones(cN), eye(cK))-eye(cK*cN);
            mOmega(mOmega==1) = vPar(iIdx_:iIdx___);             
            iIdx__ = iIdx___;
        end
        % -------- mGamma ------- %
        if constr_gamma==1
            iIdx__  = iIdx__  + 1;
            mGamma = repmat(vPar(iIdx__), cN, cK);
        else
            iIdx__  = iIdx__  + 1;
            iIdx___ = iIdx__ + cN*cK - 1;
            mGamma = reshape(vPar(iIdx__: iIdx___), cN, cK);
        end
    end
end