clear all;
clc;
% ----------------------------------------------------------------------- %
%                    Load the data 
% ----------------------------------------------------------------------- %
tf = ispc;
if tf == 1
   path('C:\Users\Stefano\Dropbox\Crypto_Stefano\DynCondBeta\Revision_JBES\Source\mfe-toolbox-main',path);
   path('C:\Users\Stefano\Dropbox\Crypto_Stefano\DynCondBeta\RevisionSecondRound_JBES\SourceRevision2\VecchioDataset\Dataset',path);
else
   path('/home/allunando/Dropbox/Crypto_Stefano/DynCondBeta/Revision_JBES/Source/mfe-toolbox-main',path);
   path('/home/allunando/Dropbox/Crypto_Stefano/DynCondBeta/Revision_JBES/Source',path);
   path('/home/allunando/Dropbox/Crypto_Stefano/DynCondBeta/Revision_JBES/Source/Dataset',path);
   path(['C:/Users/f.violante/Dropbox/Crypto_Stefano/DynCondBeta/RevisionSecondRound_JBES/SourceRevision2/NuovoDataset/Dataset'],path);
end
%sc = RandStream('CombRecursive', 'NormalTransform','Inversion','Seed', 999);
%RandStream.setGlobalStream(sc)
% ----------------------------------------------------------------------- %
%                   Manage the dataset
% ----------------------------------------------------------------------- %
load 'Factors.mat';
FFFactors = FFResearchDataFactorsdaily;
load '5_Portfolio.mat'; 
FFind = IndustryPortfoliosDaily;
FFsorts = FFind(:, 2:6); 
mFactors = FFFactors; 
mReturns = FFsorts - (mFactors(:, 4)); % Excess return we take out the risk free rate
load 'Date.mat'

mHedge = [];
mTrack = [];
mBfor = [];
[cT, cN] = size(mReturns);
gap = 22; %22
t1 = 20254;  % c-p 8000 ok 
t0 = t1-6000+1;
startparam = [];
[~, iStep] = size(t1:gap:cT - gap);
Hedge = zeros(iStep, gap, 6);
TrackErr = zeros(iStep, gap, 6);
Bfor = zeros(iStep, gap, 16);
T_ = 1;
count = 0;

startparam(cN,:,:) = zeros(27,1);

for t_1 = t1:gap:cT - gap 
    T_ 
   % count = count + 1;
   % disp(['Iter: ' num2str(count) ' - Period: ' num2str(mFactors(t0,1)) ' - ' num2str(mFactors(t1,1))]);
    mR = mReturns(t0:t_1 + gap, :);
    mF = mFactors(t0:t_1+gap, 1:3);
    for k = 1:3
        threshold=sort(abs(mF(:,k)),'descend');
        threshold=threshold(floor(size(mF(:,k),1)*0.005)+1);
        mF(logical((mF(:,k)<-threshold)),k) = -threshold; 
        mF(logical((mF(:,k)>threshold)),k) = threshold; 
    end
    % ------------------------------------------------------------------- %
    %                           Estimation part 
    % ------------------------------------------------------------------- %
    %iFilter = 0;
    BetaFOR = [];
    for k = 1:cN

        disp([strcat('series: ', num2str(k))])

    FOR_StartValChar.H_0 = [];
    FOR_StartValChar.MUX_0 = [];
    FOR_StartValChar.MUY_0 = [];
    FOR_StartValChar.B_0 = [];
    cst_beta = 0; % this is to estimate with constant betas

    [mBeta_t, mu, H, fval, exitflag, Mx, My, eps, ~, table] ...
            = fEstimateCHAR(mR(1:end - gap, k), mF(1:end - gap, :), 0, [], FOR_StartValChar, cst_beta);
    
    if exitflag == 1 || exitflag == 2 || (t_1==t1)
    % if T_ ~= 72 && T_ ~= 114 && T_ ~= 202     
        startparam(k,:,:) = table;
    else
         % filter with old parameters 
         [mBeta_t, ~, H, ~, ~, Mx, My, eps, ~, ~] ...
            = fEstimateCHAR(mR(1:end - gap, k), ...
                       mF(1:end - gap, :), 1, startparam(k,:,:), FOR_StartValChar, cst_beta);
         
         % % filter with constant beta
         % count = count + 1;
         % cst_beta = 1; 
         % [mBeta_t, ~, H, ~, ~, Mx, My, eps, ~, table] ...
         %    = fEstimateCHAR(mR(1:end - gap, 1:cN), ...
         %               mF(1:end - gap, :), 0, [], FOR_StartValChar, cst_beta);
         % startparam = table;

        disp([strcat('optimality sucks: estimating constant beta. exitflag = ',num2str(exitflag))]) 
        
    end  
    % forecast
    %iFilter = 1;
    FOR_StartValChar.H_0 = H(end,:);
    FOR_StartValChar.MUX_0 = Mx;
    FOR_StartValChar.MUY_0 = My;
    FOR_StartValChar.B_0 = mBeta_t(end,:);
    mDateFOR = Date(t_1 + 1:t_1 + gap, 1);
    mFactorsFOR = mFactors(t_1 + 1:t_1 + gap, 1:3);
    mReturnsFOR = mReturns(t_1 + 1:t_1 + gap, :);
    [BetaFOR_tmp, muFOR, HFOR, ~, ~, MxFOR, MyFOR, epsFOR, ~, table]...
            = fEstimateCHAR(mReturnsFOR(1:end-1, k), ...
                       mFactorsFOR(1:end-1, :), 1, startparam(k,:,:), FOR_StartValChar, cst_beta);
    BetaFOR = [BetaFOR, BetaFOR_tmp];
    end

    for k = 1:gap
       Hedge(T_, k, :) = [mDateFOR(k,:) (reshape(BetaFOR(k,:),3,5)' * mFactorsFOR(k,:)')'];
       TrackErr(T_, k, :) = [mDateFOR(k,:) mReturnsFOR(k,:) - squeeze(Hedge(T_, k, 2:end))'];
       Bfor(T_, k, :) = [mDateFOR(k,:) BetaFOR(k,:)];
    end
    t0 = t0 + gap;
    T_ = T_ + 1;

    % disp(['substituted constant betas these many times:'])
    % disp(count)
end
save Results_CHAR_1by1.mat

