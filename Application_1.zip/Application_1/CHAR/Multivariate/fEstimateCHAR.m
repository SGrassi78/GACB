% ----------------------------------------------------------------------- %
%                Function that estimated the beta MGARCH
% ----------------------------------------------------------------------- %
function [mBeta_t, mu, H, fval, exitflag, Mx, My, epsX, eta2, table] ...
    = fEstimateCHAR(Returns, Factors, iFilter, startparam, FOR_StartVal,cst_beta)
    % ---------------------------------------------------------------- %
    %                     House keeping
    % ---------------------------------------------------------------- %
    % Y dep var; X regressors
    
    iNrX = size(Factors, 2);
    iNrY = size(Returns, 2);
    
    H_0 = FOR_StartVal.H_0;
    MUX_0 = FOR_StartVal.MUX_0;
    MUY_0 = FOR_StartVal.MUY_0;
    B_0 = FOR_StartVal.B_0;
    
    % ---------------------------------------------------------------- %
    %                  Maximum likelihood set up
    % ---------------------------------------------------------------- %
    options = optimset('Algorithm','interior-point', 'Display','off', ...
        'MaxFunEvals', 10000,'MaxIter', 50000, 'TolFun', 1e-3, 'TolX', 1e-4,...
        'LargeScale', 'off', 'UseParallel', true);
    
    warning off;
    
    par0 = []; LB_f = []; UB_f = [];
    if ~isempty(startparam) && size(startparam,2)==((iNrX+iNrY-1)*((iNrX+iNrY-1)+1)/2)*3+(iNrX+iNrY-1)*3
        Mat = [Factors-mean(Factors) Returns-mean(Returns)];
        s0 = 1; s1 = 6;
        for i=1:iNrX+iNrY-1
            b = Mat(:,1:i)\Mat(:,i+1);
            s_e = var(Mat(:,i+1)-Mat(:,1:i)*b);
            [par0_tmp, LB_tmp, UB_tmp] = startval(i+1, startparam(s0:s1), b, s_e, cst_beta);
            par0 = [par0; par0_tmp];
            LB_f = [LB_f; LB_tmp];
            UB_f = [UB_f; UB_tmp];
    
            s0 = s1+1;
            s1 = s1+3*(i+2);
        end
    else
        Mat = [Factors-mean(Factors) Returns-mean(Returns)];
        s0 = 1; s1 = 6;
        for i=1:iNrX+iNrY-1
            b = Mat(:,1:i)\Mat(:,i+1);
            s_e = var(Mat(:,i+1)-Mat(:,1:i)*b);
            [par0_tmp, LB_tmp, UB_tmp] = startval(i+1, [], b, s_e, cst_beta);
            par0 = [par0; par0_tmp];
            LB_f = [LB_f; LB_tmp];
            UB_f = [UB_f; UB_tmp];
        
            s0 = s1+1;
            s1 = s1+3*(i+2);
        end
    end
    
    estpar = [];
       
    if isempty(MUX_0)
        Mx = mean(Factors);
        My = mean(Returns);
    else
        Mx = MUX_0;
        My = MUY_0;
    end
    
    exitflag = 0;
    fval = 0;
    if iFilter==0
        
        X = Factors - Mx;
        Y = Returns - My;
        
        Mat = [X Y];
    
        epsX = Mat(:,1);
        s0 = 1;
        s1 = 6;
        H = [];
        mBeta_t = [];
        
        for i = 2:iNrX+iNrY
            Bols = (Mat(:, 1:i-1)\Mat(:,i))';  
            %Bols = mean((Mat(:,i)*ones(1,i-1)) .* Mat(:, 1:i-1)) / cov(Mat(:, 1:i-1));
            A = [zeros(1,length(par0(s0:s1))-2) 1 1];
            b = 0.9999;
            [param, ~, exitflag_tmp, output, ~, ~, ~] = fmincon(@char_likelihood,...
                par0(s0:s1), A, b, [], [], LB_f(s0:s1), UB_f(s0:s1), [], options, ...
                Mat(:,i), Mat(:, 1:i-1), epsX(:, 1:i-1), Bols, H_0, B_0);
            estpar = [estpar; param];
            [fval_tmp, ~, mu, H_tmp, eps, eta2, mBeta_tmp] = char_likelihood(param, ...
                Mat(:,i), Mat(:, 1:i-1), epsX(:, 1:i-1), Bols, H_0, B_0);
            % if output.firstorderopt>1e-3
            %     exitflag_tmp = 999;
            % end
            if (exitflag_tmp ~= 1 && exitflag_tmp ~= 2)
                exitflag_tmp = 999;
            end
            exitflag = max(exitflag,exitflag_tmp);
            fval = max(fval,fval_tmp);
            epsX = [epsX eps];
            H = [H H_tmp];
            mBeta_t = [mBeta_t mBeta_tmp];
            s0 = s1+1;
            s1 = s1 + (i+1)*3;
        end
    else
        X = Factors - Mx;
        Y = Returns - My;
        Mat = [X Y];
        epsX = Mat(:,1);
        s0 = 1;
        s1 = 6;
        k0 = 1;
        k1 = 1;
        H = [];
        mBeta_t = [];
        for i = 2:iNrX+iNrY
            Bols = (Mat(:, 1:i-1)\Mat(:,i))';
            if isempty(H_0)
                [fval, ~, mu, H_tmp, eps, eta2, mBeta_tmp] = char_likelihood(par0(s0:s1), ...
                Mat(:,i), Mat(:, 1:i-1), epsX(:, 1:i-1), Bols, H_0, B_0);
                H = [H H_tmp];
                mBeta_t = [mBeta_t mBeta_tmp];
            else
                [fval, ~, mu, H_tmp, eps, eta2, mBeta_tmp] = char_likelihood(par0(s0:s1), ...
                Mat(:,i), Mat(:, 1:i-1), epsX(:, 1:i-1), Bols, H_0(i-1), B_0(k0:k1));
            
                if i>= iNrX+1
                    mBeta_t = [mBeta_t mBeta_tmp];
                    H = [H H_tmp];
                end
            end
            epsX = [epsX eps];
            estpar = [estpar; par0(s0:s1)];
            s0 = s1+1;
            s1 = s1 + (i+1)*3;
            k0 = k1+1;
            k1 = k1 + i;
        end
end


% ---------------------------------------------------------------- %
%         Compute variance covariance of the parameters
% ---------------------------------------------------------------- %

%VCV = [];
table = estpar;

% if iFilter==0
%     disp('estimating parameters covariance');
%     VCV_bekk = robustvcv(@scalar_bekk_likelihood, param_bekk, Factors, mSigma_f, H1_0, MU_0);
%     VCV_beta = robustvcv(@beta_garch_likelihood, param, Returns, Factors, ...
%         fOrt_Inn, mBeta_Unc, mSigma_r_f, iSel, betatargeting, H2_0, B_0);
%     VCV = blkdiag(VCV_bekk, VCV_beta);
% 
%     table = [[param_bekk; param] sqrt(diag(VCV)) [param_bekk; param]./sqrt(diag(VCV))];
%     table = [table 2*(1-normcdf(abs(table(:,3))))]; 
%     table(end+1,1) = -fval*size(Factors,1); 
% end

end

%--------------------------------------------------------------------------
function [c,ceq] = garchconstr(x)
    % Nonlinear inequality constraints
    c = x(end) + x(end-1) - 0.9999;
    % Nonlinear equality constraints
    ceq = [];
end
%--------------------------------------------------------------------------

function [startingVals_f, LB_f, UB_f] = startval(nVar, startparam ,b, s_e, cst_beta)
    % npar = nVar*3 : beta + garch
    
    startingVals_Beta = reshape([b repmat([0.05, 0.985], nVar-1, 1)]', 1, 3 * (nVar - 1))';
    LB_Beta = repmat([-5; -0.99; -0.9999], nVar - 1, 1);
    UB_Beta = repmat([5; 0.99; 0.9999], nVar - 1, 1);
    
    if cst_beta==1
        LB_Beta = repmat([-5; 0; 0], nVar - 1, 1);
        UB_Beta = repmat([5; 0; 0], nVar - 1, 1);
    end

    startingVals_garch = [s_e; 0.04; 0.94];
    LB_garch = [0.0001; 0.001; 0.01];
    UB_garch = [10; 0.99; 0.9999];
    
    startingVals_f = [startingVals_Beta; startingVals_garch];
    LB_f = [LB_Beta; LB_garch];
    UB_f = [UB_Beta; UB_garch];
        
    if ~isempty(startparam) && size(startparam,1)==size(startingVals_f,1)
        startingVals_f = startparam;
    end
end

% ----------------------------------------------------------------------- %
%             Estimation of the conditional beta
% ----------------------------------------------------------------------- %
function [ll, lls, mu, mH, eps, eta2, mBeta_t] = char_likelihood(vPar, ...
    Y, X, epsX, Bols, H_0, B_0)

       [cT, ~] = size(Y);
       iNrX = size(X, 2);
        
       eta2 = zeros(cT, 1);
       eps = zeros(cT, 1);
       mu = zeros(cT, 1);
       lls = zeros(cT, 1);
       
       Par_Beta = reshape(vPar(1:iNrX*3), 3, iNrX)';
       Par_garch = vPar(iNrX*3+1:end);
       
       if isempty(B_0)
          mH(1, 1) = var(Y);
          mH(cT + 1, 1) = var(Y);
          mBeta_t(1, :) = Bols;
          mBeta_t(cT + 1,:) = Bols;
          mu(:,1) = mBeta_t(1, :) * X(1, :)';
          eps(1, :) = Y(1, :) - mean(Y);
       else
          mH(1, 1) = H_0;
          mH(cT + 1, 1) = H_0;
          mBeta_t(1, :) = B_0;
          mBeta_t(cT + 1, :) = B_0;
          mu(1, :) = mBeta_t(1, :) * X(1, :)';
          eps(1, :) = Y(1, :) - mu(1, :);
       end    
       % ---------------------------------------------------------------- %
       %                   Estimation of the beta TV                      %
       % ---------------------------------------------------------------- %
       for i = 2:cT + 1

           mBeta_t(i,:) = (Par_Beta(:,1).*(1-Par_Beta(:,3))+Par_Beta(:,2).*(epsX(i-1,:)'*eps(i-1))+Par_Beta(:,3).*mBeta_t(i-1,:)')';
           
           mH(i, 1) =  Par_garch(1)*(1-Par_garch(2)-Par_garch(3)) + Par_garch(2) * eps(i - 1, 1)^2 + Par_garch(3) * mH(i - 1, 1); 

           if i == cT + 1 % this is to have the last iteration as 1-step forecast
               break;
           end
           
           mu(i, 1) = mBeta_t(i, :) * X(i, :)';
           eps(i, :) = Y(i, :) - mu(i, :);

           eta2(i) = eps(i, :)^2/mH(i, 1);  %full
           lls(i) = -0.5 * (log(2 * pi) + log(mH(i, 1)) + eta2(i));
           
       end
       ll = -mean(lls(20:end));
       if (isnan(ll) || ~isreal(ll) || isinf(ll))
           ll = 1e7;
       end
end
