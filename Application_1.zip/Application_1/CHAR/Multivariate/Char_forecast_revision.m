clear all;
clc;
% ----------------------------------------------------------------------- %
%                    Load the data 
% ----------------------------------------------------------------------- %
tf = ispc;
if tf == 1
   path('C:\Users\Stefano\Dropbox\Crypto_Stefano\DynCondBeta\Revision_JBES\Source\mfe-toolbox-main',path);
   path('C:\Users\Stefano\Dropbox\Crypto_Stefano\DynCondBeta\RevisionSecondRound_JBES\SourceRevision2\VecchioDataset\Dataset',path);
else
   path('/home/stefano/Dropbox/Crypto_Stefano/DynCondBeta/Revision_JBES/Source/mfe-toolbox-main',path);
   path('/home/stefano/Dropbox/Crypto_Stefano/DynCondBeta/Revision_JBES/Source',path);
   path('/home/stefano/Dropbox/Crypto_Stefano/DynCondBeta/Revision_JBES/Source/Dataset',path);
end
% ----------------------------------------------------------------------- %
%                   Manage the dataset
% ----------------------------------------------------------------------- %
load 'Factors.mat';
FFFactors = FFResearchDataFactorsdaily2023;
load '5_Portfolio.mat'; 
FFind = IndustryPortfoliosDaily;
FFsorts = FFind(:, 2:6); 
mFactors = FFFactors; 
mReturns = FFsorts - (mFactors(:, 4)); % Excess return we take out the risk free rate
load 'Date.mat'

mHedge = [];
mTrack = [];
mBfor = [];
[cT, cN] = size(mReturns);
gap = 22; %22
t1 = 20254;  % c-p 8000 ok 
t0 = t1-6000+1;
startparam = [];
[~, iStep] = size(t1:gap:cT - gap);
Hedge = zeros(iStep, gap, 6);
TrackErr = zeros(iStep, gap, 6);
Bfor = zeros(iStep, gap, 26);
T_ = 1;
count = 0;
for t_1 = t1:gap:cT - gap 
    T_ 
    mR = mReturns(t0:t_1 + gap, :);
    threshold = sort(abs(mR),'descend');
    threshold = threshold(floor(size(mR,1)*0.005)+1);
    mR(logical((mR<-threshold))) = -threshold; 
    mR(logical((mR>threshold))) = threshold; 
    mF = mFactors(t0:t_1+gap, 1:3);
    for k = 1:3
        threshold=sort(abs(mF(:,k)),'descend');
        threshold=threshold(floor(size(mF(:,k),1)*0.005)+1);
        mF(logical((mF(:,k)<-threshold)),k) = -threshold; 
        mF(logical((mF(:,k)>threshold)),k) = threshold; 
    end
    % ------------------------------------------------------------------- %
    %                           Estimation part 
    % ------------------------------------------------------------------- %
    %iFilter = 0;
    startparam = [];
    FOR_StartValChar.H_0 = [];
    FOR_StartValChar.MUX_0 = [];
    FOR_StartValChar.MUY_0 = [];
    FOR_StartValChar.B_0 = [];
    cst_beta = 0; % this is to estimate with constant betas

    [mBeta_t, mu, H, fval, exitflag, Mx, My, eps, ~, table] ...
            = fEstimateCHAR(mR(1:end - gap, 1:cN), mF(1:end - gap, :), 0, startparam, FOR_StartValChar, cst_beta);
    exitflag
    % if exitflag == 1 || exitflag == 2 || (t_1==t1)
    if T_ ~= 72 && T_ ~= 114 && T_ ~= 202     
        startparam = table;
        startparam_TEMP = startparam;
    else
         % filter with constant beta
         count = count + 1;
         cst_beta = 1; 
         [mBeta_t, ~, H, ~, ~, Mx, My, eps, ~, table] ...
            = fEstimateCHAR(mR(1:end - gap, 1:cN), ...
                       mF(1:end - gap, :), 0, [], FOR_StartValChar, cst_beta);
         startparam = table;

        disp(['optimality sucks: estimating constant beta. exitflag = ']) 
        disp(exitflag)
        
    end  
    FOR_StartValChar.H_0 = H(end,:);
    FOR_StartValChar.MUX_0 = Mx;
    FOR_StartValChar.MUY_0 = My;
    FOR_StartValChar.B_0 = mBeta_t(end,:);
    mDateFOR = Date(t_1 + 1:t_1 + gap, 1);
    mFactorsFOR = mFactors(t_1 + 1:t_1 + gap, 1:3);
    mReturnsFOR = mReturns(t_1 + 1:t_1 + gap, :);
    [BetaFOR, muFOR, HFOR, ~, ~, MxFOR, MyFOR, epsFOR, ~, table]...
            = fEstimateCHAR(mReturnsFOR(1:end-1, :), ...
                       mFactorsFOR(1:end-1, :), 1, startparam, FOR_StartValChar, cst_beta);
    vSel = [1,2,3,4,5,6,8,9,10,13,14,15,19,20,21]; 
    for k = 1:gap
       Hedge(T_, k, :) = [mDateFOR(k,:) (reshape(BetaFOR(k,vSel),3,5)' * mFactorsFOR(k,:)')'];
       TrackErr(T_, k, :) = [mDateFOR(k,:) mReturnsFOR(k,:) - squeeze(Hedge(T_, k, 2:end))'];
       Bfor(T_, k, :) = [mDateFOR(k,:) BetaFOR(k,:)];
    end
    t0 = t0 + gap;
    T_ = T_ + 1;
    disp(['substituted constant betas these many times:'])
    disp(count)
end

mB_r = [];
for z = 2:16
    mB_r = [mB_r, reshape(squeeze(Bfor(:, :, z))', 236*22, 1)];
end 


Bfor(72, :, 2:16)=repmat(Bfor(72, 1, 2:16),22,1);
TrackErr(72, :, 2:16)=repmat(TrackErr(72, 1, 2:16),22,1);


Bfor(202, 18:22, 2:16)=repmat(Bfor(202, 17, 2:16),5,1);
