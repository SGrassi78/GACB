clear all;
clc;
% ----------------------------------------------------------------------- %
%                    Load the data 
% ----------------------------------------------------------------------- %
path('C:\Users\f.violante\Dropbox\Crypto_Stefano\DynCondBeta\RevisionSecondRound_JBES\SourceRevision2\NuovoDataset\Dataset',path);
load 'Factors_April2024.mat';
FFFactors = FFResearchDataFactorsdailyApril2024;
load '5_Portfolio_April2024.mat'; 
FFind = IndustryPortfoliosDaily;
FFsorts = FFind(:, 2:6); 
mFactors = FFFactors; 
mReturns = FFsorts - (mFactors(:, 4)); % Excess return we take out the risk free rate
load 'Date_April2024.mat'
[cT, cN] = size(mReturns);
gap = 22; %22
t1 = 20254;  % c-p 8000 ok 
t0 = t1-6000+1;
[~, iStep] = size(t1:gap:cT - gap);
Hedge = zeros(iStep, gap, cN+1);
TrackErr = zeros(iStep, gap, cN+1);
Bfor = zeros(iStep, gap, cN*3+1);
T_ = 1;
count = 0;
startparam(cN,:,:) = zeros(3*(4*3/2+3),iStep); %27
for t_1 = t1:gap:cT - gap %t1
    disp(['iter: ',  num2str(T_), '=> ']) 
    mR = mReturns(t0:t_1 + gap, :);
    mF = mFactors(t0:t_1+gap, 1:3);
    % ------------------------------------------------------------------- %
    %                           Estimation part 
    % ------------------------------------------------------------------- %
    BetaFOR = zeros(gap,cN*3);
    for k = 1:cN
        disp([strcat('series: ', num2str(k))])
        FOR_StartValChar.H_0 = [];
        FOR_StartValChar.MUX_0 = [];
        FOR_StartValChar.MUY_0 = [];
        FOR_StartValChar.B_0 = [];
        cst_beta = 0; % this is to estimate with constant betas

        if T_==1
            [mBeta_t, mu, H, fval, exitflag, Mx, My, eps, ~, table] ...
                = fEstimateCHAR(mR(1:end-1, k), mF(1:end-1, :), 0, [], FOR_StartValChar, cst_beta);
        else
            [mBeta_t, mu, H, fval, exitflag, Mx, My, eps, ~, table] ...
                = fEstimateCHAR(mR(1:end - 1, k), mF(1:end - 1, :), 0, startparam(k,:,T_ - 1), FOR_StartValChar, cst_beta);
        end

        if max(max(abs(mBeta_t(end-gap+1:end,end-2:end))))>4
            disp([strcat('forecast explodes -> cst beta. Max beta = ', num2str(max(max(abs(mBeta_t(end-gap+1:end,end-2:end))))))])
            cst_beta = 1;
            [mBeta_t, ~, H, ~, ~, Mx, My, eps, ~, table] ...
                = fEstimateCHAR(mR(1:end - 1, k), ...
                          mF(1:end - 1, :), 0, [], FOR_StartValChar, cst_beta);
        end
        BetaFOR(:,3*k-2:3*k) = mBeta_t(end-gap+1:end,end-2:end);
        startparam(k,:,T_) = table;
    end
    mDateFOR = Date(t_1 + 1:t_1 + gap, 1);
    mFactorsFOR = mF(end - gap + 1:end, 1:3);
    mReturnsFOR = mR(end - gap + 1:end, :);

    for k = 1:gap
       Hedge(T_, k, :) = [mDateFOR(k,:) (reshape(BetaFOR(k,:),3,cN)' * mFactorsFOR(k,:)')'];
       TrackErr(T_, k, :) = [mDateFOR(k,:) mReturnsFOR(k,:) - squeeze(Hedge(T_, k, 2:end))'];
       Bfor(T_, k, :) = [mDateFOR(k,:) BetaFOR(k,:)];
    end
    t0 = t0 + gap;
    T_ = T_ + 1;
end

mB_r = [];
for z = 1:16
    mB_r = [mB_r, reshape(squeeze(Bfor(:, :, z))', 247*22, 1)];
end
plot(mB_r(1:100,4))
hold on
plot(mB_r(1:100,4))
squeeze(startparam(2,:,:))';