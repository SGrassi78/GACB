% ----------------------------------------------------------------------- %
%  Program that estimates and forecast the DCB-CCC for Application 2
% this program requires the mfe-toolbox-main of Kevin Sheppard available
% at https://www.mathworks.com/matlabcentral/fileexchange/170381-mfe-toolbox-kevin-sheppard
% ----------------------------------------------------------------------- 
clear all;
clc;
% ----------------------------------------------------------------------- %
%                    Load the data 
% ----------------------------------------------------------------------- %
% ----------------------------------------------------------------------- %
%      Load here the data for your experiment 
%      The data used in the paper are available at 
%      https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html)
% ----------------------------------------------------------------------- %
mFactors = []; % Here load your factors
mReturns = []; % Here load your returns 
% ----------------------------------------------------------------------- %
%                      Management of the program 
% ----------------------------------------------------------------------- %
[cT, cN] = size(mReturns);
gap = 22; % Interval between estimation 

t1 = 20254;% Start date of the out of sample forecast
iEstimationSize = 3000; % Size of the estimation sample
t0 = t1 - iEstimationSize + 1; % Start date of the estimation sample

[~, iStep] = size(t1:gap:cT - gap);
mHedge = zeros(cN, iStep,  gap, 2);
mTrackError = zeros(cN, iStep, gap, 2);
mBfor = zeros(cN, iStep, gap, 4);
mHFor = zeros(cN, iStep, gap, 2);
mexitflag = zeros(cN, iStep, 4);
mParameters = zeros(cN, iStep, 27);

parfor i = 1:cN
    mReturns__ = mReturns(:, i); % Excess return we take out the risk free rate
    startparam = [];
    Hedge = zeros(iStep, gap, 2);
    TrackErr = zeros(iStep, gap, 2);
    Bfor = zeros(iStep, gap, 4);
    Hfor = zeros(iStep, gap, 2);
    vExit = zeros(iStep, 4);
    vParameters = zeros(iStep, 27);
    swap_to_filter = 0;
    for s = 1:iStep
        disp(['stock ' num2str(i) ' Step ' num2str(s)])
        rng(1);
        mR = mReturns__(t0+gap*(s-1):t1+gap*s, :); 
        mF = mFactors(t0+gap*(s-1):t1+gap*s, 2:4);
        H_0 = [];
        MUX_0 = [];
        MUY_0 = [];
        B_0 = [];       
        [mBeta_t, mu, H, fval, exitflag, firstorderopt, Mx, My, eps, ~, table] ...
            = fEstimateCHAR_Forecast_Parallel(mR(1:end-gap, :), mF(1:end-gap, :), startparam, 0, H_0, MUX_0, MUY_0, B_0);
        vExit(s, :) = [exitflag firstorderopt  mFactors(t0+gap*(s-1), 1) mFactors(t1+gap*s, 1)];
        startparam = table(1:end, 1);
        vParameters(s, :) = table';
        H_0 = H(end,:);
        MUX_0 = Mx;
        MUY_0 = My;
        B_0 = mBeta_t(end,:);
        [BetaFOR, muFOR, HFOR, ~, ~, ~, MxFOR, MyFOR, ~, ~, ~] ...
            = fEstimateCHAR_Forecast_Parallel(mR(end-gap:end-1), mF(end-gap:end-1,:), startparam, 1, H_0, MUX_0, MUY_0, B_0);
            
        mDateFOR = mFactors(t1+gap*(s-1)+1:t1+gap*s, 1); 
        mFactorsFOR = mFactors(t1+gap*(s-1)+1:t1+gap*s, 2:4);
        mReturnsFOR = mReturns__(t1+gap*(s-1)+1:t1+gap*s, :);
        for k=1:gap
            Hedge(s, k, :) = [mDateFOR(k,:) BetaFOR(k, 4:end) * mFactorsFOR(k,:)'];
            TrackErr(s, k, :) = [mDateFOR(k,:) mReturnsFOR(k,:) - Hedge(s, k, 2:end)];
            Bfor(s, k, :) = [mDateFOR(k,:) BetaFOR(k, 4:end)];
            Hfor(s, k,:) = [mDateFOR(k,:) HFOR(k,end)];
        end
    end
    mexitflag(i, :, :) = exitflag;
    mHedge(i, :, :, :) = Hedge;
    mTrackError(i, :,  :, :) = TrackErr;
    mBfor(i, :, :, :) = Bfor;
    mHFor(i, :, :, :) = Hfor;
    mParameters(i, :, :) = vParameters;
end
% --------------------------------------------- %
%           Print and save your results here 
% --------------------------------------------- %