% ----------------------------------------------------------------------- %
%                Function that estimated the beta MGARCH
% ----------------------------------------------------------------------- %
function [mBeta_t, S_22, H, Q, xi, fval, exitflag, Mx, My, eps, eta2, table, VCV] ...
    = fFilterDCC_Forecast(mReturns, mFactors, iSel, startparam, corrtargeting, ...
    mUncCorr, H_0, Q_0, MUf_0, MUr_0)
    % ---------------------------------------------------------------- %
    %                     House keeping
    % ---------------------------------------------------------------- %
    iNrFactors = size(mFactors, 2);
    iNrReturns = size(mReturns, 2);
    % ------------------- Risk premia parameters ------------------ %
    startingVals_Garch = repmat([0.5; 0.04; 0.94],iNrFactors + iNrReturns, 1);
    LB_Garch = repmat([0.0; 0.0; 0.8],iNrFactors + iNrReturns, 1);
    UB_Garch = repmat([Inf; 0.5; 1.0],iNrFactors + iNrReturns, 1);
    % ------------------- Garch parameters ----------------------- %
    vCholCorr = reshape(chol(mUncCorr)',(iNrFactors + iNrReturns)^2,1);
    startingVals_C = vCholCorr(vCholCorr~=0);
    LB_C = -5 *ones((iNrFactors + iNrReturns) * (iNrFactors + iNrReturns+1)/2, 1);
    UB_C = 5 *ones((iNrFactors + iNrReturns) * (iNrFactors + iNrReturns+1)/2, 1);
    if corrtargeting == 1
        startingVals_C = [];
        LB_C = [];
        UB_C = [];
    end
    if iSel==0  % CCC
        startingVals_DCC = [];
        LB_DCC = [];
        UB_DCC = [];
    elseif iSel == 1 % DCC
        startingVals_DCC = [0.025; 0.97];
        LB_DCC = [0.0; 0.8];
        UB_DCC = [0.15; 1.0];
    end
    startingVals_f = [startingVals_Garch; startingVals_C; startingVals_DCC];
    LB_f = [LB_Garch; LB_C; LB_DCC];
    UB_f = [UB_Garch; UB_C; UB_DCC];
    if ~isempty(startparam) && size(startparam,1)==size(startingVals_f,1)
        startingVals_f = startparam(1:end);
    end
    Mat = [mFactors mReturns];
    Mx = mean(mFactors);
    My = mean(mReturns);
    fval = [];
    exitflag = [];
    estpar = startparam;
    Mat = Mat - [MUf_0 MUr_0];
    H = [];
    xi = [];
    for i = 1:(iNrFactors + iNrReturns)
        [~, ~, H_tmp, ~, xi_tmp] = garch_likelihood(startparam(3*(i-1)+1:3*i), Mat(:,i), H_0(i));
        H = [H H_tmp];
        xi = [xi xi_tmp];            
    end
    eps = xi;
    eta2 = [];
    if iSel == 0 && corrtargeting == 1
        for i = 1:size(Mat,1)+1
            R(:,:,i) = mUncCorr;
        end
        Q = R;
    else
        [~, ~, R, Q, eps, eta2] = DCC_likelihood(startparam(3*(iNrFactors + iNrReturns)+1:end), xi, iSel, corrtargeting, mUncCorr, Q_0);
    end
    
    for i = 1:size(Mat,1)+1
        Sigma = sqrt(diag(H(i,:)))*R(:,:,i)*sqrt(diag(H(i,:)));
        mBeta_t(:,:,i) = Sigma(iNrFactors + 1:end, 1:iNrFactors)*inv(Sigma(1:iNrFactors, 1:iNrFactors));
        S_22(:,:,i) = Sigma(iNrFactors + 1:end, iNrFactors + 1:end) - Sigma(iNrFactors + 1:end, 1:iNrFactors) *...
        inv(Sigma(1:iNrFactors, 1:iNrFactors)) * Sigma(iNrFactors + 1:end, 1:iNrFactors)';
    end
    % ---------------------------------------------------------------- %
    %         Compute variance covariance of the parameters
    % ---------------------------------------------------------------- %
    VCV = [];
    table = [estpar];
end
% ----------------------------------------------------------------------- %

function [ll, lls, mH, eps, devol] = garch_likelihood(vPar, Y, H_0)

    [cT, ~] = size(Y);
    C = vPar(1);
    A = vPar(2);
    B = vPar(3);
    %filtered time series
    eta2 = zeros(cT, 1);
    eps = zeros(cT, 1);
    devol = zeros(cT, 1);    
    if isempty(H_0)
        mH = repmat(var(Y), cT + 1, 1);
        eps(1, :) = Y(1, :);
        devol(1, :) = eps(1, :)./sqrt(mH(1,:))';
    else
        mH = repmat(H_0, cT+1, 1);
        eps(1, :) = Y(1, :);
        devol(1, :) = eps(1, :)./sqrt(mH(1,:))';
    end
    lls = zeros(cT, 1);
    for i = 2:cT + 1
        %variance
        mH(i,:) = C + A * eps(i - 1, :)^2 + B * mH(i - 1,:);
        if i == cT + 1 % this is to have the last iteration as 1-step forecast
            break;
        end
        eps(i, :) = Y(i, :);
        devol(i, :) = eps(i, :)./sqrt(mH(i,:))';
        eta2(i) = eps(i, :)^2/mH(i,:);  %full
        lls(i) = -0.5 * (log(2 * pi) + log(mH(i,:)) + eta2(i));
    end
    ll = - mean(lls(10:end));
    if (isnan(ll) || ~isreal(ll) || isinf(ll))
        ll = 1e7;
    end
end

%-----------------------------------------------------------------------

function [ll, lls, mR, mQ, eps, eta2] = DCC_likelihood(vPar, xi, iSel, corrtargeting, mUncCorr, Q_0)

[cT, cN] = size(xi);

if corrtargeting == 1    
    if iSel == 0
        C = mUncCorr;
        A = 0;
        B = 0;
    elseif iSel ==1
        C = mUncCorr;
        A = vPar(1);
        B = vPar(2);
    end
else
    if iSel == 0
        LT = zeros(cN);
        LT((tril(ones(cN)))~=0) = vPar(1:cN*(cN+1)/2, 1);
        C = LT*LT';
        A = 0;
        B = 0;
    elseif iSel ==1
        LT = zeros(cN);
        LT((tril(ones(cN)))~=0) = vPar(1:cN*(cN+1)/2, 1);
        C = LT*LT';
        A = vPar(cN*(cN+1)/2+1);
        B = vPar(cN*(cN+1)/2+2);
    end
end
%filtered time series
eta2 = zeros(cT, 1);
eps = zeros(cT, cN);

if isempty(Q_0)
    mR(:,:,1) = corr(xi);
    mR(:,:,cT+1) = corr(xi);
    mQ(:,:,1) = corr(xi);
    mQ(:,:,cT+1) = corr(xi);
    eps(1, :) = xi(1, :);
else
    mR(:,:,1) = diag(sqrt(diag(Q_0)))^(-1)*Q_0*diag(sqrt(diag(Q_0)))^(-1);
    mR(:,:,cT+1) = mR(:,:,1);
    mQ(:,:,1) = Q_0;
    mQ(:,:,cT+1) = Q_0;
    eps(1, :) = xi(1, :);
end

lls = zeros(cT, 1);
for i = 2:cT + 1
    %variance
    mQ(:, :, i) = C * (1 - A - B) + A * (xi(i - 1, :)' * xi(i - 1, :)) + B * mQ(:, :, i - 1);
    mR(:, :, i) = diag(sqrt(diag(mQ(:, :, i))))^(-1)*mQ(:,:,i)*diag(sqrt(diag(mQ(:, :, i))))^(-1);
    if i == cT + 1 % this is to have the last iteration as 1-step forecast
        break;
    end
    eps(i, :) = xi(i, :);
    eta2(i) = xi(i, :) * (mR(:, :, i)\xi(i, :)');  %full
    lls(i) = -0.5 * (log(det(mR(:, :, i))) + eta2(i) - (xi(i - 1, :) * xi(i - 1, :)'));
end
ll = - mean(lls(10:end));
if (isnan(ll) || ~isreal(ll) || isinf(ll))
    ll = 1e7;
end
end

       
       
       
%-------------------------------------------------------------------------
function [VCV]=robustvcv(fun, param, varargin)
       k=length(param);
       h=max(abs(param*eps^(1/3)),1e-8);
       h=diag(h);
       [~,like,~]=feval(fun,param,varargin{:});
       t=length(like);
       LLFp=zeros(k,1);
       LLFm=zeros(k,1);
       likep=zeros(t,k);
       likem=zeros(t,k);
       for i=1:k
           thetaph=param+h(:,i);
           [LLFp(i),likep(:,i)]=feval(fun,thetaph,varargin{:});
           thetamh=param-h(:,i);
           [LLFm(i),likem(:,i)]=feval(fun,thetamh,varargin{:});
       end
       scores=zeros(t,k);
       gross_scores=zeros(k,1);
       h=diag(h);
       for i=1:k
           scores(:,i)=(likep(:,i)-likem(:,i))./(2*h(i)); 
           gross_scores(i)=(LLFp(i)-LLFm(i))./(2*h(i));
       end
        hess=myhessian(fun,param,varargin{:});

       A=hess;      %likelihood computed as avg so no need to divide by t (divide if llf is the sum)
       Ainv=A^(-1);

       B=cov(scores);
       VCV=(Ainv*B*Ainv)/t;
       end
       %-------------------------------------------------------------------------
       function H = hessian_2sided(f,x,varargin)

       n = size(x,1);
       if size(x,2)~=1
           error('X must be a column vector.')
       end
       try
           feval(f,x,varargin{:});
       catch FE
           errtxt=['There was an error evaluating the function.  Please check the arguements.  The specific error was:' FE.message];
           error(errtxt);
       end
       fx = feval(f,x,varargin{:});

       % Compute the stepsize (h)
       h = eps.^(1/3)*max(abs(x),1e-8);
       xh = x+h;
       h = xh-x;
       ee = sparse(1:n,1:n,h,n,n);

       % Compute forward and backward steps
       gp = zeros(n,1);
       gm = zeros(n,1);
       for i=1:n
           gp(i) = feval(f,x+ee(:,i),varargin{:});
           gm(i) = feval(f,x-ee(:,i),varargin{:});
       end

       hh=h*h';
       Hm=NaN*ones(n);
       Hp=NaN*ones(n);
       % Compute "double" forward and backward steps
       for i=1:n
           for j=i:n
               Hp(i,j) = feval(f,x+ee(:,i)+ee(:,j),varargin{:});
               Hp(j,i)=Hp(i,j);
               Hm(i,j) = feval(f,x-ee(:,i)-ee(:,j),varargin{:});
               Hm(j,i)=Hm(i,j);
           end
       end
%Compute the hessian
       H = zeros(n);
       for i=1:n
           for j=i:n
               H(i,j) = (Hp(i,j)-gp(i)-gp(j)+fx+fx-gm(i)-gm(j)+Hm(i,j))/hh(i,j)/2;
               H(j,i) = H(i,j);
           end
       end
end
function h = myhessian(fun,c,varargin)
       del = 1e-6;
       h = zeros(numel(c));

       for i=1:numel(c)
           h_tmp = ones(1,numel(c));
           parfor j=1:i
           ca = c; ca(i) = ca(i)+del; ca(j) = ca(j)+del;
           cb = c; cb(i) = cb(i)-del; cb(j) = cb(j)+del;
           cc = c; cc(i) = cc(i)+del; cc(j) = cc(j)-del;
           cd = c; cd(i) = cd(i)-del; cd(j) = cd(j)-del;

           h_tmp(j) = (feval(fun,ca,varargin{:})+feval(fun,cd,varargin{:})-feval(fun,cb,varargin{:})-feval(fun,cc,varargin{:}))/(4*del^2);

           end
           h(i,:)=h_tmp;

       end
       h = h .* ((ones(numel(c))-eye(numel(c))).*h'+eye(numel(c)));
end
function hf = myhessian2(f,x0,varargin)
       %%variables

       epsilon = 1e-5; % delta
       l_x0=length(x0); % length of x0;

       for i=1:l_x0
           x1 = x0;
           x1(i) = x0(i) - epsilon ;
           df1 = NumJacob(f, x1,varargin{:});

           x2 = x0;
           x2(i) = x0(i) + epsilon ;
           df2 = NumJacob(f, x2,varargin{:});

           d2f = (df2-df1) / (2*epsilon );

           hf(i,:) = d2f';
       end
end