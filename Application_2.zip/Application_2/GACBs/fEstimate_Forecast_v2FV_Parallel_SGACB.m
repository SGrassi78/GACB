% ----------------------------------------------------------------------- %
%                Function that estimated the beta MGARCH
% ----------------------------------------------------------------------- %
function [mBeta_t, mu, H_2nd, H_1st, fval, exitflag, firstorderopt, M, V, eps, eta2, table, mBeta_Unc] ...
    = fEstimate_Forecast_v2FV_Parallel_SGACB(mReturns, mFactors, iSel, startparam, betatargeting, ...
    constr, noconst, SBEKK, filter, H1_0,  H2_0, MU_0, MUr_0, B_0, SIG_0)
    % ---------------------------------------------------------------- %
    %                     House keeping
    % ---------------------------------------------------------------- %
    iNrFactors = size(mFactors, 2);
    iNrReturns = size(mReturns, 2);
    M = mean(mReturns);
    V = cov(mReturns);
    % ---------------------------------------------------------------- %
    %                  Maximum likelihood set up
    % ---------------------------------------------------------------- %
    options = optimset('Algorithm', 'interior-point', 'Display','off', ...
       'MaxFunEvals', 10000,'MaxIter', 10000, 'TolFun', 1e-4, 'TolX', 1e-10,...
       'LargeScale', 'off', 'UseParallel', false);
    % ---------------------------------------------------------------- %
    %              Calculate S_rf S_f and S_r|f
    % ---------------------------------------------------------------- %
    if isempty(SIG_0)
        mSigma_rf = cov([mFactors mReturns]); % covariances between factors and returns
    else
        mSigma_rf = SIG_0;
    end
    mSigma_f = mSigma_rf(1:iNrFactors, 1:iNrFactors);  % variance of the factors
    mSigma_r_f = mSigma_rf(iNrFactors + 1:end, iNrFactors + 1:end) - mSigma_rf(iNrFactors + 1:end, 1:iNrFactors) *...
        inv(mSigma_rf(1:iNrFactors, 1:iNrFactors)) * mSigma_rf(iNrFactors + 1:end, 1:iNrFactors)'; % variance of the returns conditional on the factors
    mBeta_Unc = mSigma_rf(iNrFactors + 1:end, 1:iNrFactors)/(mSigma_f);
    % ---------------------------------------------------------------- %
    %                      Equartion 13
    % ---------------------------------------------------------------- %
    % ------------------- Mgarch parameters ----------------------- %
    startingVals_Mgarch = [0.04; 0.94];
    LB_Mgarch = [0.0; 0.8];
    UB_Mgarch = [0.5; 1.0];
    % ------------------- Beta equation parameters   -------------- %
    startingVals_BetaUnc = mBeta_Unc;
    LB_BetaUnc = -5 *ones(iNrReturns * iNrFactors, 1);
    UB_BetaUnc = 5 *ones(iNrReturns * iNrFactors, 1);
    
    if iSel==0
        startingVals_Omega = [];
        LB_Omega = [];
        UB_Omega = [];
    elseif iSel == 1
        startingVals_Omega = 0.01 .* ones(iNrReturns * iNrFactors, 1);
        LB_Omega = -0.5* ones(iNrFactors * iNrReturns, 1);
        %LB_Omega = 0.00001* ones(iNrFactors * iNrReturns, 1);
        UB_Omega = 0.5 * ones(iNrFactors * iNrReturns, 1);
    elseif iSel == 2
        LB_Omega = [];
        UB_Omega = [];
        mTemp_LB = -0.01* ones(iNrFactors); %-0.5
        mTemp_UB = 0.01* ones(iNrFactors);  
        mTemp_UB(logical(eye(size(mTemp_UB)))) = 0.25;
        mTemp_LB(logical(eye(size(mTemp_LB)))) = -0.25;
        startingVals_Omega = 0.001 .* ones(iNrReturns * iNrFactors^2, 1);
        for i = 1:iNrReturns
            LB_Omega = [LB_Omega; mTemp_LB(:)];
            UB_Omega = [UB_Omega; mTemp_UB(:)];
        end
        startingVals_Omega = startingVals_Omega .* (LB_Omega>=0);
    elseif iSel == 3
        LB_Omega = [];
        UB_Omega = [];
        mTemp_LB = -1.0 * ones(iNrReturns);
        mTemp_LB(logical(eye(size(mTemp_LB)))) = 0.00001;
        mTemp_UB = 1.0* ones(iNrReturns);
        mTemp_UB(logical(eye(size(mTemp_LB)))) = 0.5;
        startingVals_Omega = 0.001 .* ones(iNrReturns^2 * iNrFactors, 1);
        for i = 1:iNrFactors
            LB_Omega = [LB_Omega; mTemp_LB(:)];
            UB_Omega = [UB_Omega; mTemp_UB(:)];
        end
        startingVals_Omega = startingVals_Omega .* (LB_Omega>=0);
    elseif iSel == 4    
        mTemp_LB = -kron(eye(iNrReturns),ones(iNrFactors)) - kron(ones(iNrReturns),eye(iNrFactors))+eye(iNrFactors*iNrReturns);
        mTemp_LB = mTemp_LB * 0.1;
        mTemp_LB(logical(eye(size(mTemp_LB)))) = 0.00001;
        mTemp_UB = kron(eye(iNrReturns), ones(iNrFactors)) + kron(ones(iNrReturns), eye(iNrFactors))-eye(iNrFactors*iNrReturns);
        mTemp_UB(logical(eye(size(mTemp_LB)))) = 0.5;
        mTemp_idx = find(mTemp_UB~=0);
        LB_Omega = mTemp_LB(mTemp_idx);
        UB_Omega = mTemp_UB(mTemp_idx);
        %startingVals_Omega = 0.01 .* ones(size(mTemp_idx,1), 1); 
        startingVals_Omega = 0.001 .* ones(size(mTemp_idx,1), 1); 
        startingVals_Omega = startingVals_Omega .* (LB_Omega>=0);   
    end
    if iSel==0
        startingVals_Gamma = [];
        LB_Gamma = [];
        UB_Gamma = [];
    else
        startingVals_Gamma = 0.995.* ones(iNrReturns, iNrFactors); 
        mTemp = 0.9*ones(iNrReturns, iNrFactors);  
        LB_Gamma = mTemp(:);
        mTemp = 0.9999.*ones(iNrReturns, iNrFactors);
        UB_Gamma = mTemp(:);    
        if constr==1
            startingVals_Gamma = 0.985;
            LB_Gamma = 0.98;
            UB_Gamma = 0.99999;
        end
    end
    startingVals_Sigma_r_fUnc = diag(mSigma_r_f);
    LB_Sigma_r_fUnc = zeros(iNrReturns, 1);
    UB_Sigma_r_fUnc = startingVals_Sigma_r_fUnc*3;
    % ------------------- Risk premia parameters ------------------ %
    if noconst==1
        startingVals_premia = [];
        LB_premia = [];
        UB_premia = [];
    else
        startingVals_premia = 0.5 * ones(iNrReturns, 1);
        LB_premia = -2*ones(iNrReturns, 1);
        UB_premia = 2*ones(iNrReturns, 1);
    end
    startingVals_f = [startingVals_BetaUnc(:); startingVals_Sigma_r_fUnc; startingVals_Mgarch; ...
        startingVals_Omega(:); startingVals_Gamma(:); startingVals_premia];
    LB_f = [LB_BetaUnc; LB_Sigma_r_fUnc; LB_Mgarch; LB_Omega; LB_Gamma; LB_premia];
    UB_f = [UB_BetaUnc; UB_Sigma_r_fUnc; UB_Mgarch; UB_Omega; UB_Gamma; UB_premia];
    if betatargeting == 1
        startingVals_f(1:iNrFactors*iNrReturns) = [];
        LB_f(1:iNrFactors*iNrReturns) = [];
        UB_f(1:iNrFactors*iNrReturns) = [];
    end
    if SBEKK==1
        if ~isempty(startparam) && size(startparam,1)==size(startingVals_f,1)+2
            startingVals_Mgarch  = startparam(1:2); 
            startingVals_f = startparam(3:end);
        end
    elseif SBEKK==0
        startingVals_Mgarch = kron(ones(iNrFactors,1),startingVals_Mgarch);
        if ~isempty(startparam) && size(startparam,1)==size(startingVals_f,1)+2*iNrFactors
            startingVals_Mgarch  = startparam(1:2*iNrFactors); 
            startingVals_f = startparam(2*iNrFactors+1:end);
        end
    end

    % ---------------------------------------------------------------- %
    %              Estimate the S_f using the BEKK
    % ---------------------------------------------------------------- %
    %    disp('estimating the parameters of S_f,t ... 1st step ...');
    % Scalar BEKK joint    
    if SBEKK==1
        if filter==0
            A = [1 1];
            b = 0.9999;
            [param_bekk, ~, ~, ~, ~, ~, ~] = ...
                  fmincon(@scalar_bekk_likelihood, startingVals_Mgarch, A, b,...
                  [],[], LB_Mgarch, UB_Mgarch, [], options, mFactors, diag(mSigma_f), H1_0, MU_0);
            [~, ~, ~, H_1st, ~, fOrt_Inn] = scalar_bekk_likelihood(param_bekk, mFactors, diag(mSigma_f), H1_0, MU_0); 
        else
            [~, ~, ~, H_1st, ~, fOrt_Inn] = scalar_bekk_likelihood(startingVals_Mgarch, mFactors, diag(mSigma_f), H1_0, MU_0); 
        end
    elseif SBEKK==0
    % Univ GARCH individual
          fOrt_Inn = [];
          param_bekk = [];
          H_1st = zeros(iNrFactors,iNrFactors,size(mFactors,1));
          for s=1:iNrFactors
              if filter==0
                  if isempty(H1_0)
                      [param_bekk_tmp, ~, ~, ~, ~, ~, ~] = ...
                          fmincon(@scalar_bekk_likelihood, startingVals_Mgarch(2*s-1:2*s), [], [],...
                          [],[], LB_Mgarch, UB_Mgarch, [], options, mFactors(:,s), mSigma_f(s,s), H1_0, MU_0);
                      [~, ~, ~, H_1st_tmp, ~, fOrt_Inn_tmp] = scalar_bekk_likelihood(param_bekk_tmp, mFactors(:,s), mSigma_f(s,s), H1_0, MU_0);      
                  else
                      [param_bekk_tmp, ~, ~, ~, ~, ~, ~] = ...
                          fmincon(@scalar_bekk_likelihood, startingVals_Mgarch(2*s-1:2*s), [], [],...
                          [],[], LB_Mgarch, UB_Mgarch, [], options, mFactors(:,s), mSigma_f(s,s), H1_0(s,s), MU_0(s));
                      [~, ~, ~, H_1st_tmp, ~, fOrt_Inn_tmp] = scalar_bekk_likelihood(param_bekk_tmp, mFactors(:,s), mSigma_f(s,s), H1_0(s,s), MU_0(s));      
                  end
                  fOrt_Inn = [fOrt_Inn fOrt_Inn_tmp];
                  param_bekk = [param_bekk; param_bekk_tmp];
                  for m = 1:size(mFactors,1)
                      H_1st(s,s,m) = H_1st_tmp(1,1,m);
                  end
              else
                  if isempty(H1_0)
                    [~, ~, ~, H_1st_tmp, ~, fOrt_Inn_tmp] = scalar_bekk_likelihood(startingVals_Mgarch(2*s-1:2*s), mFactors(:,s), mSigma_f(s,s), H1_0, MU_0);      
                  else
                    [~, ~, ~, H_1st_tmp, ~, fOrt_Inn_tmp] = scalar_bekk_likelihood(startingVals_Mgarch(2*s-1:2*s), mFactors(:,s), mSigma_f(s,s), H1_0(s,s), MU_0(s));      
                  end
                  fOrt_Inn = [fOrt_Inn fOrt_Inn_tmp];
                  for m = 1:size(mFactors,1)
                      H_1st(s,s,m) = H_1st_tmp(1,1,m);
                  end
              end
          end
    end
    % ---------------------------------------------------------------- %
    %                   Estimate the B_t
    % ---------------------------------------------------------------- %
    %    disp('estimating parameters 2nd step');   
    if filter==0 
          [param, ~, exitflag, output, ~, ~, ~] = fmincon(@beta_garch_likelihood,...
            startingVals_f, [], [], [], [], LB_f, UB_f, [], options, ...
            mReturns, mFactors, fOrt_Inn, mBeta_Unc, diag(mSigma_r_f), iSel, betatargeting, H2_0, B_0, MU_0, MUr_0, constr, noconst);
          [fval, ~, mu, H_2nd, eps, eta2, mBeta_t] = beta_garch_likelihood(param, ...
            mReturns, mFactors, fOrt_Inn, mBeta_Unc, diag(mSigma_r_f), iSel, betatargeting, H2_0, B_0, MU_0, MUr_0, constr, noconst);
          
          firstorderopt = output.firstorderopt;
    else
          [fval, ~, mu, H_2nd, eps, eta2, mBeta_t] = beta_garch_likelihood(startingVals_f, ...
            mReturns, mFactors, fOrt_Inn, mBeta_Unc, diag(mSigma_r_f), iSel, betatargeting, H2_0, B_0, MU_0, MUr_0, constr, noconst);
          exitflag = [];
          firstorderopt = [];
    end
    % ---------------------------------------------------------------- %
    %         Compute variance covariance of the parameters
    % ---------------------------------------------------------------- %
    if filter==0
        table = [param_bekk; param];% sqrt(diag(VCV)) [param_bekk; param]./sqrt(diag(VCV))];
    else
        table = [startingVals_Mgarch; startingVals_f];
    end
end
% ----------------------------------------------------------------------- %
%     Estimate the scalar BEKK for the factors  S_f,t in the paper 
% ----------------------------------------------------------------------- %
function [ll, lls, mu, mH, eps, devol] = scalar_bekk_likelihood(vPar, mFactors, mSigma_f, H1_0, MU_0)
    [cT, iNrFactors] = size(mFactors);
    A = vPar(1);
    B = vPar(2);
    %filtered time series
    eta2 = zeros(cT, 1);
    eps = zeros(cT, iNrFactors);
    devol = zeros(cT, iNrFactors);    
    
    if isempty(H1_0)
        mH(:, :, 1) = diag(mSigma_f);
        mH(:, :, cT + 1) = diag(mSigma_f);
        mu = repmat(mean(mFactors), cT + 1, 1);
        eps(1, :) = mFactors(1, :) - mean(mFactors);
    else
        mH(:, :, 1) = H1_0;
        mH(:, :, cT + 1) = H1_0;
        mu = repmat(MU_0, cT + 1, 1);
        eps(1, :) = mFactors(1, :) - mu(1, :);
        devol(1, :) = eps(1, :)./sqrt(diag(mH(:, :, 1)))';
    end
    
    lls = zeros(cT, 1);
    for i = 2:cT + 1
        %variance
        mH(:, :, i) = diag(mSigma_f) * (1 - A - B) + A * diag(eps(i - 1, :)' .* eps(i - 1, :)') + B * mH(:, :, i - 1);
        if i == cT + 1  
            break;
        end
        eps(i, :) = mFactors(i, :) - mu(i, :);
        devol(i, :) = eps(i, :)./sqrt(diag(mH(:, :, i)))';
        eta2(i) = eps(i,:)*(eps(i,:)'./diag(mH(:,:,i))); %diag
        lls(i) = -0.5*(iNrFactors * log(2*pi) + sum(log(diag(mH(:,:,i)))) + eta2(i));
    end
    ll = - mean(lls(100:end));
 end
% ----------------------------------------------------------------------- %
%             Estimation of the conditional beta
% ----------------------------------------------------------------------- %
function [ll, lls, mu, mH, eps, eta2, mBeta_t] = beta_garch_likelihood(vPar, ...
    mReturns, mFactors, fOrt_Inn, mBeta_Unc, mSigma_r_f, iSel, betatargeting, H2_0, B_0, MU_0, MUr_0, constr, noconst)

    [cT, iNrReturs] = size(mReturns);
    iNrFactors = size(mFactors, 2);
    % -------- Center mFactors --------- %
    %mFactors = mFactors - mean(mFactors);
    eta2 = zeros(cT, 1);
    eps = zeros(cT, iNrReturs);
    lls = zeros(cT, 1);
    % -- Unconditional beta Parameters -- %
    iIdx__= 0;
    if betatargeting == 1
        iIdx__= iNrReturs;
        H0 = diag(vPar(1:iIdx__, 1));
    elseif betatargeting == 0
        iIndx0__ = iNrFactors * iNrReturs;
        mBeta_Unc = reshape(vPar(1:iIndx0__, 1), iNrReturs, iNrFactors);
        iIdx__ = iNrFactors * iNrReturs + iNrReturs;
        H0 = diag(vPar(iIndx0__+1:iIdx__, 1));
    end
    % -- MGarch parameters -- %
    A = vPar(iIdx__ + 1);
    B = vPar(iIdx__ + 2);    
    % ---------------------------------------------------------------- %
    %  B_t =\Psi+(\Omega.*\Xi_r_t-1*\Xi_f_t-1)+(\Gamma.*B_t-1) Eq 13
    % ---------------------------------------------------------------- %
    if iSel == 0
        iIdx___ = iIdx__ + 2;
        mOmega = 0;
        mGamma = 0;
    else
        if iSel == 1
            % -------- mOmega ------- %
            iIdx_ = iIdx__ +  3;
            iIdx__ = iIdx__ + 3 + iNrReturs * iNrFactors - 1;
            mOmega = reshape(vPar(iIdx_:iIdx__ ), iNrReturs, iNrFactors);
        elseif iSel == 2
            mOmega = [];
            for i = 1:iNrReturs
                iIdx_ = (iIdx__ +  3 + (i - 1) * iNrFactors^2);
                iIdx___ = (iIdx__ + 3 + i * iNrFactors^2 - 1);
                mTemp = reshape(vPar(iIdx_:iIdx___), iNrFactors, iNrFactors);
                mOmega =  blkdiag(mOmega, mTemp);
            end
            iIdx__ = iIdx___;
        elseif iSel == 3
            mOmega = [];
            for i = 1:iNrFactors
                iIdx_ = (iIdx__ + 3 + (i - 1) * iNrReturs^2);
                iIdx___ = (iIdx__ + 3 + i * iNrReturs^2 - 1);
                mTemp = reshape(vPar(iIdx_:iIdx___), iNrReturs, iNrReturs);
                mOmega =  blkdiag(mOmega, mTemp);
            end
            iIdx__ = iIdx___;
        elseif iSel == 4    
            iIdx_ = iIdx__ +  3;
            iIdx___ = iIdx__ +  3 + (iNrFactors^2+iNrFactors*(iNrReturs-1))*iNrReturs - 1;
            mOmega = kron(eye(iNrReturs),ones(iNrFactors)) + kron(ones(iNrReturs),eye(iNrFactors))-eye(iNrFactors*iNrReturs);
            mOmega_idx = find(mOmega==1);
            mOmega(mOmega_idx) = vPar(iIdx_:iIdx___); 
            iIdx__ = iIdx___;
        end
        
        % -------- mGamma ------- %
        if constr==1
            iIdx__  = iIdx__  + 1;
            iIdx___ = iIdx__;
            mGamma = repmat(vPar(iIdx__), iNrReturs, iNrFactors);
        else
            iIdx__  = iIdx__  + 1;
            iIdx___ = iIdx__ + iNrReturs*iNrFactors - 1;
            mGamma = reshape(vPar(iIdx__: iIdx___), iNrReturs, iNrFactors);
        end
    end
    % ------ Risk premia ---- %
    if noconst ==1
        L = zeros(iNrReturs,1);
    else
        L = vPar(iIdx___ + 1:end);
    end
    mPsi = mBeta_Unc .*(ones(iNrReturs, iNrFactors) - mGamma);
    if isempty(B_0)
        mH(:, :, 1) = diag(mSigma_r_f);
        mH(:, :, cT + 1) = diag(mSigma_r_f);
        mBeta_t(:, :, 1) = mBeta_Unc;
        mBeta_t(:, :, cT + 1) = mBeta_Unc;
        mu = repmat(median(mReturns(1:20, :)), cT + 1, 1);
        mu_returns = mean(mReturns);
        mu_factors = mean(mFactors);
        eps(1, :) = mReturns(1, :) - mu_returns;
        if noconst ==1
            mReturns = mReturns-mu_returns;
            mFactors = mFactors-mu_factors;
        end
    else
        mH(:, :, 1) = H2_0;
        mH(:, :, cT + 1) = H2_0;
        mBeta_t(:, :, 1) = B_0;
        mBeta_t(:, :, cT + 1) = B_0;
        mu_factors = MU_0;
        mu_returns = MUr_0;
        if noconst ==1
            mReturns = mReturns-mu_returns;
            mFactors = mFactors-mu_factors;
            mu(1, :) = ((mBeta_t(:, :, 1) * mFactors(1, :)'))';
        else
            mu(1, :) = (L + (mBeta_t(:, :, 1) * mFactors(1, :)')-((mBeta_t(:, :, 1)-mBeta_Unc)*mu_factors') )';
        end
        eps(1, :) = mReturns(1, :) - mu(1, :);
    end    
    % ---------------------------------------------------------------- %
    %                   Estimation of the beta TV                      %
    % ---------------------------------------------------------------- %
    for i = 2:cT + 1
        % ------------------------------------------------------------- %
        %B_t=B.*[e_n*(e_k-\gamma_k)]+e_n w_k.*(\Xi_r_t*\Xi_f_t)+e\gamma.*B_t-1
        % ------------------------------------------------------------- %
        % without standardizzation 
        Xi_r = eps(i - 1, :)';
        Xi_f = mFactors(i - 1, :)- mean(mFactors);
        % with standardizzation
        %Xi_r = (eps(i - 1, :)'./sqrt(diag(mH(:, :, i - 1))));
        %Xi_f = fOrt_Inn(i - 1, :);  
        mBeta_t(:, :, i) = fBetas(Xi_r, Xi_f, mBeta_t(:, :, i - 1), ...
                 mPsi, mOmega, mGamma, iNrReturs, iNrFactors, iSel);
        % ------------------------------------------------------------ %
        % S_r|f,t = S_r|f(1-a-v) + a * (S^1/2*eta*eta*S^1/2) + vSr|f,t-1
        % ------------------------------------------------------------ %
        mH(:, :, i) = H0 * (1 - A - B) + A * diag(eps(i - 1, :)' .* eps(i - 1, :)') ...
                  + B * mH(:, :, i - 1); 
        if i == cT + 1 % this is to have the last iteration as 1-step forecast
           break;
        end
        if noconst==1
           mu(i, :) = ((mBeta_t(:, :, i) * mFactors(i, :)'))';
        else
           mu(i, :) = (L + (mBeta_t(:, :, i) * mFactors(i, :)')-((mBeta_t(:, :, i)-mBeta_Unc)*mu_factors') )';
        end
        eps(i, :) = mReturns(i, :) - mu(i, :);
        eta2(i,1) = eps(i ,:) * (eps(i,:)'./diag(mH(:,:,i))); %diag
        lls(i) = -0.5*(iNrReturs*log(2*pi) + sum(log(diag(mH(:,:,i)))) + eta2(i, 1));
    end
    ll = -mean(lls(10:end));
end
% ----------------------------------------------------------------------- %
%             Function that calculate different TV Betas
% ----------------------------------------------------------------------- %
function [mBeta_t] = fBetas(Xi_r, Xi_f, Beta_t1, mPsi, mOmega, mGamma, iNrReturs, iNrFactors, iSel)
   % -------------------------------------------------------------------- %
   %    B_t= \Gamma + (\Omega .*(\Xi_r_t*\Xi_f_t))+ (\Gamma.*B_t-1) Eq 13
   % -------------------------------------------------------------------- %
   if iSel == 0
       mBeta_t = mPsi;
   elseif iSel == 1   
       mBeta_t = mPsi + (mOmega .* (Xi_r * Xi_f)) + (mGamma .* Beta_t1); %13, 14 e 15 provare solo con 3 asse 
   % -------------------------------------------------------------------- %
   % B_t= \Psi + vec^-1[\Omega .*(\Xi_r_t Kron \Xi_f_t)+ \Gamma* Vec(B_t-1)
   % -------------------------------------------------------------------- %
   elseif iSel == 2 || iSel == 4 
       mBeta_t = mPsi + reshape(mOmega * kron(Xi_r, Xi_f'), iNrFactors, iNrReturs)' + (mGamma .* Beta_t1);
   % -------------------------------------------------------------------- %
   % B_t= \Psi + vec^-1[\Omega .*(\Xi_r_t Kron \Xi_f_t)+ \Gamma* Vec(B_t-1)]
   % -------------------------------------------------------------------- %       
   elseif iSel == 3
       mBeta_t = mPsi + reshape(mOmega * kron(Xi_f', Xi_r), iNrReturs, iNrFactors) + (mGamma .* Beta_t1);
   % -------------------------------------------------------------------- %
   % B_t= \Psi + vec^-1[\Omega .*(\Xi_f_t Kron \Xi_r_t)+ \Gamma* Vec(B_t-1)]'
   % -------------------------------------------------------------------- %              
   end
end