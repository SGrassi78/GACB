% ----------------------------------------------------------------------- %
%  Program that estimates and forecast the GACB for Application 2
% this program requires the mfe-toolbox-main of Kevin Sheppard available
% at https://www.mathworks.com/matlabcentral/fileexchange/170381-mfe-toolbox-kevin-sheppard
% ----------------------------------------------------------------------- 
clear all;
clc;
% ----------------------------------------------------------------------- %
%      Load here the data for your experiment 
%      The data used in the paper are available at 
%      https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html)
% ----------------------------------------------------------------------- %
mFactors = []; % Here load your factors
mReturns = []; % Here load your returns 
% ----------------------------------------------------------------------- %
%                      Management of the program
% ----------------------------------------------------------------------- %
% gcab case
iSel = 2; % This is the model speciation 0) OLS 1) H-GACB 2) F-GACB 
% 3) R-GACB not in paper 4) S-GACB  not in paper
betatargeting = 1; % 1) To impose Beta targeting 
constrgamma = 0; % 1) To constrain smoothing parameters to be common for all betas 
noconst = 1;
SBEKK = 1;
if SBEKK==1
    nPar = 17;
else
    nPar = 21;
end

if betatargeting == 0
    nPar = nPar + 3;
end
[cT, cN] = size(mReturns);
gap = 22; % Interval between estimation 
startparam = [];
t1 = 20254; % Start date of the out of sample forecast
iEstimationSize = 3000; % Size of the estimation sample
t0 = t1 - iEstimationSize + 1; % Start date of the estimation sample
count = 0;
[~, iStep] = size(t1:gap:cT - gap);
mHedge = zeros(cN, iStep,  gap, 2);
mTrackError = zeros(cN, iStep, gap, 2);
mBfor = zeros(cN, iStep, gap, 4);
mHFor = zeros(cN, iStep, gap, 2);
mexitflag = zeros(cN, iStep, 4);
mParameters = zeros(cN, iStep, nPar);
%end
% ----------------------------------------------------------------------- %
parfor i = 1:cN
    mReturns__ = mReturns(:, i); 
    startparam = [];
    Hedge = zeros(iStep, gap, 2);
    TrackErr = zeros(iStep, gap, 2);
    Bfor = zeros(iStep, gap, 4);
    Hfor = zeros(iStep, gap, 2);
    vExit = zeros(iStep, 4);
    vParameters = zeros(iStep, nPar);
    swap_to_filter = 0;
    swap_to_idyo = 0;
    for s = 1:iStep
        disp(['stock ' num2str(i) ' Step ' num2str(s)])
        mR = mReturns__(t0+gap*(s-1):t1+gap*s, :);
        mF = mFactors(t0+gap*(s-1):t1+gap*s, 2:4);
        % --------------------------------------------------------------- %
        %                      Estimation part
        % --------------------------------------------------------------- %
        startparam = [];
        H1_0 = [];
        H2_0 = [];
        MU_0 = [];
        MUr_0 = [];
        B_0 = [];
        SIG_0 = [];
        [Beta_t, ~, H_2nd, H_1st, ~, exitflag, firstorderopt, ~, ~, ~, ~, table, ~] = ...
            fEstimate_Forecast_v2FV_Parallel_SGACB(mR(1:end-gap), mF(1:end-gap,:), ...
            iSel, startparam, betatargeting, constrgamma, noconst, SBEKK, 0, H1_0,  H2_0, MU_0, MUr_0, B_0, SIG_0);

        vExit(s, :) = [exitflag, firstorderopt mFactors(t0+gap*(s-1), 1) mFactors(t1+gap*s, 1)];
        % --------------------------------------------------------------- %
        %                      Forecasting part
        % --------------------------------------------------------------- %
        tol = 8.5e-4;
        switchmod = 0; 
        startparam = table(1:end, 1);
        vParameters(s, :) = table';
        H1_0 = H_1st(:, :, end);
        H2_0 = H_2nd(:, :, end);
        MU_0 = mean(mF(1:end-gap,:));
        MUr_0 = mean(mR(1:end-gap));
        B_0 = Beta_t(:, :, end);
        SIG_0 = cov([mF(1:end-gap,:) mR(1:end-gap)]);
        [Beta_FOR, ~, H_2ndFOR, H_1stFOR, ~, ~, ~, ~, ~, ~, ~, ~, ~] = ...
             fEstimate_Forecast_v2FV_Parallel_SGACB(mR(end-gap:end-1), mF(end-gap:end-1,:), ...
             iSel, startparam, betatargeting, constrgamma, noconst, SBEKK, 1, H1_0,  H2_0, MU_0, MUr_0, B_0, SIG_0);
        mDateFOR = mFactors(t1+gap*(s-1)+1:t1+gap*s, 1); 
        mFactorsFOR = mFactors(t1+gap*(s-1)+1:t1+gap*s, 2:4);
        mReturnsFOR = mReturns__(t1+gap*(s-1)+1:t1+gap*s, :);
        for k = 1:gap
            Hedge(s, k, :) = [mDateFOR(k, :) (Beta_FOR(:,:,k) * mFactorsFOR(k,:)')'];
            TrackErr(s, k, :) = [mDateFOR(k, :) mReturnsFOR(k,:) - Hedge(s, k, 2:end)];
            Bfor(s, k, :) = [mDateFOR(k, :) reshape(Beta_FOR(:,:,k), size(Beta_FOR, 1) * size(Beta_FOR, 2), 1)'];
            Hfor(s, k, :) = [mDateFOR(k, :) H_2ndFOR(:, :, k)];
        end
    end 
    % --------------------------    
    mexitflag(i, :, :) = vExit;
    mHedge(i, :, :, :) = Hedge;
    mTrackError(i, :,  :, :) = TrackErr;
    mBfor(i, :, :, :) = Bfor;
    mHFor(i, :, :, :) = Hfor;
    mParameters(i, :, :) = vParameters;
end
% --------------------------------------------- %
%           Print and save your results here 
% --------------------------------------------- %